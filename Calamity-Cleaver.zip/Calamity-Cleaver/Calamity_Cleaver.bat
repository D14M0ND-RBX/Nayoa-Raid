@goto :cc_start
r"""
:cc_start
@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Calamity Cleaver

rem ===========================================================================
rem  CALAMITY CLEAVER - Jujutsu Zero / Nayoa Calamity raid macro.
rem  One file, launcher plus macro. Double-click it.
rem  It finds or installs Python, installs any missing libraries, then runs the macro
rem  code stored further down in this same file.
rem  The PNG images and the saved settings live in the same folder as this file.
rem ===========================================================================

rem --- what to install when no usable Python is found - edit here to change it
set "PY_WINGET_ID=Python.Python.3.12"
set "PY_URL=https://www.python.org/ftp/python/3.12.7/python-3.12.7-amd64.exe"
set "PY_PACKAGES=mss opencv-python numpy pyautogui pydirectinput"

rem --- 1. look for a Python that really works (the Microsoft Store stub does not count)
set "PYEXE="
call :try_python py -3
call :try_python python
if not defined PYEXE call :find_installed
if defined PYEXE goto :have_python

rem --- 2. none found: install one
echo.
echo [INFO] No usable Python 3.9 or newer with tkinter was found. Installing Python...
where winget >nul 2>&1
if not errorlevel 1 (
    echo [INFO] Installing %PY_WINGET_ID% with winget - this can take a minute...
    winget install --id %PY_WINGET_ID% --exact --source winget --silent --accept-source-agreements --accept-package-agreements
)
call :find_installed
if not defined PYEXE call :try_python py -3
if defined PYEXE goto :have_python

echo [INFO] Downloading the Python installer from python.org...
set "PY_SETUP=%TEMP%\cc_python_setup.exe"
powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; $ProgressPreference = 'SilentlyContinue'; Invoke-WebRequest -UseBasicParsing -Uri '%PY_URL%' -OutFile '%PY_SETUP%'"
if exist "%PY_SETUP%" (
    echo [INFO] Installing Python - please wait...
    start /wait "" "%PY_SETUP%" /quiet InstallAllUsers=0 PrependPath=1 Include_launcher=1 Include_tcltk=1 Include_test=0 Shortcuts=0
    del "%PY_SETUP%" >nul 2>&1
)
call :find_installed
if not defined PYEXE call :try_python py -3
if defined PYEXE goto :have_python

echo.
echo [ERROR] Python could not be installed automatically.
echo         Install Python 3.12 from https://www.python.org/downloads/windows/
echo         and tick "Add python.exe to PATH", then run this file again.
pause
exit /b 1

rem --- 3. install any missing libraries (nothing is upgraded), then start the macro
:have_python
echo [INFO] Using Python: %PYEXE%
%PYEXE% -c "import mss, cv2, numpy, pyautogui, pydirectinput" >nul 2>&1
if not errorlevel 1 goto :start_macro
echo [INFO] Installing the required libraries - first run only, this can take a minute...
%PYEXE% -m pip install --disable-pip-version-check --quiet --retries 1 --timeout 15 %PY_PACKAGES%
%PYEXE% -c "import mss, cv2, numpy, pyautogui, pydirectinput" >nul 2>&1
if errorlevel 1 (
    echo.
    echo [ERROR] A required library is missing and could not be installed.
    echo         Check your internet connection and run this file again.
    pause
    exit /b 1
)

:start_macro
echo [INFO] Starting Calamity Cleaver...
echo.
%PYEXE% -x "%~f0" %*
set "CC_EXIT=%errorlevel%"
echo.
if not "%CC_EXIT%"=="0" echo [ERROR] The macro stopped with error code %CC_EXIT%.
pause
exit /b %CC_EXIT%

rem ---------------------------------------------------------------------------
rem  subroutine: test one way of starting Python. Keeps it only if it runs, is
rem  version 3.9 or newer, and has tkinter for the settings window.
rem ---------------------------------------------------------------------------
:try_python
if defined PYEXE exit /b 0
%* -c "import sys, tkinter; sys.exit(0 if sys.version_info >= (3, 9) else 1)" >nul 2>&1
if not errorlevel 1 set "PYEXE=%*"
exit /b 0

rem --- subroutine: look in the usual install folders, because a Python that was
rem     just installed is not on PATH yet in this window
:find_installed
for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do call :try_python "%%D\python.exe"
for /d %%D in ("%ProgramFiles%\Python3*") do call :try_python "%%D\python.exe"
for /d %%D in ("%LOCALAPPDATA%\Python\pythoncore-3*") do call :try_python "%%D\python.exe"
exit /b 0
"""
# ============================================================================
#  Everything below is the macro itself (Python). The batch launcher above is
#  wrapped in a string so Python ignores it, and Python's -x flag skips line 1.
# ============================================================================
"""CALAMITY CLEAVER - Jujutsu Zero / Nayoa Calamity raid macro.

Every scan tick (0.05s, non-stop) these images are searched inside their own rectangle:
  Ready              -> raid starting: glide to it and click 3x
  Lv. 13,000 Zen'in  -> raid started: attack rotation begins
  Chase took too long-> phase 2 started
  Raid Summary: Successful -> raid beaten: Loops +1, then Retry is searched
  Raid Summary: Failure    -> you died: Loops unchanged, then Retry is searched
  Retry              -> only searched after a win or a fail: glide to it and click 5x
The stop key pauses the macro; pressing it again restarts it.
"""

import base64
import gc
import concurrent.futures
import ctypes
import json
import math
import os
import queue
import random
import sys
import threading
import time
import traceback
from ctypes import wintypes
from pathlib import Path

import cv2
import mss
import numpy as np
import pyautogui  # unused directly, but importing it makes the process DPI-aware (correct coordinates)
import pydirectinput

try:
    import tkinter as tk
except Exception:  # pragma: no cover
    tk = None

APP_NAME = "CALAMITY CLEAVER"
ROOT = Path(__file__).resolve().parent
SETTINGS_PATH = ROOT / "calamity_settings.json"
SCAN_DELAY = 0.05
RETRY_TIMEOUT = 180.0     # give up waiting for Retry after this many seconds
RESULT_COOLDOWN = 6.0     # ignore win/fail banners this long after Retry was clicked
READY_COOLDOWN = 4.0      # ignore Ready this long after it was clicked
KEY_GAP = 0.08            # pause between rotation key presses
COARSE_GATE = 0.55        # half-size pass must score this before the full-size check runs

pydirectinput.PAUSE = 0
pydirectinput.FAILSAFE = False
try:
    ctypes.windll.user32.SetProcessDPIAware()
    ctypes.windll.winmm.timeBeginPeriod(1)  # 1 ms timer so the mouse glide is smooth
except Exception:
    pass
user32 = ctypes.windll.user32 if os.name == "nt" else None

# image key -> (file, label used in settings/log, match threshold)
IMAGES = {
    "ready":   ("Ready.png",            "Ready",                   0.80),
    "retry":   ("Retry.png",            "Retry",                   0.80),
    "success": ("RaidSuccessful.png",   "Raid Summary Successful", 0.85),
    "failed":  ("RaidFailed.png",       "Raid Summary Failure",    0.85),
    "chase":   ("ChaseTookTooLong.png", "Chase Took Too Long",     0.78),
    "zenin":   ("ZeninElite.png",       "Lv. 13,000 Zenin Elite",  0.80),
}
SCAN_KEYS = ("ready", "zenin", "chase", "success", "failed")

ROTATION_KEYS = list("cfxrtvzy")
SHR = "Sorcerer Heavenly Restriction"
PHR = "Physical Heavenly Restriction"
CURSED_TECHNIQUES = ["awk projection", "awk limitless", "awk star-rage", "awk blood-manipulation",
                     "ten shadows", "shrine", "copy", "love train", "beast amber",
                     "projection sorcery", "limitless", "cursed energy discharge", "summer blade"]
WEAPONS = ["Light Katana", "True Inverted Spear of Heaven", "Inverted Spear of Heaven", "Dragon Bone",
           "Festering Life Sword", "Nyoi Staff", "Playful Cloud", "Soul Split Katana", "Kamutoke",
           "Summer Blade", "Autumn Blade", "Zenith Spear", "Celestto Spear", "Honoy Yagi", "Shattered Cloud"]
SLOT_KEYS = ["1", "2"]
SLOT_SWAP_DELAY = 0.20    # wait after pressing a slot key so the item can be equipped
SELECT_CAP = 2
STOP_KEYS = [f"f{i}" for i in range(1, 13)]
LOG_CLEAR_MINUTES = [5, 10, 15, 20, 25, 30]
SCREEN_MODES = ["Half-Screen", "Corner Screen", "Full Screen"]
CORNERS = ["Top Left", "Top Right", "Bottom Left", "Bottom Right"]
RESOLUTIONS = ["640x480", "800x600", "1024x768", "1152x864", "1280x720", "1280x800", "1280x960",
               "1280x1024", "1360x768", "1366x768", "1440x900", "1600x900", "1600x1200", "1680x1050",
               "1768x992", "1920x1080", "1920x1200", "2048x1152", "2560x1080", "2560x1440", "2560x1600",
               "2880x1620", "3000x2000", "3200x1800", "3440x1440", "3840x1080", "3840x1600", "3840x2160",
               "5120x1440", "5120x2160", "5120x2880", "7680x4320"]
# template scales tried for each screen mode (Roblox UI shrinks in smaller windows)
SCALES = {"Full Screen": [1.0, 1.1, 1.2, 1.3, 1.4, 1.5, 0.9],
          "Half-Screen": [1.0, 1.1, 1.2, 1.3, 1.4, 1.5, 0.9],
          "Corner Screen": [1.0, 0.9, 0.8, 0.6, 0.5, 1.1, 1.2, 1.3]}
DEBUG_SCORES = True        # log the best match score per image every few seconds (set False when it works)
DEBUG_EVERY = 8.0
BEST = {}                  # key -> best score seen since last debug print

EMBEDDED = {
    "Ready.png": (
        "iVBORw0KGgoAAAANSUhEUgAAAHsAAAAhCAIAAAB2sEO5AAAQlUlEQVR42o1abVBU1Ru/L7vswsLuwu7yuuCMbIBYukIMMg2D5Whg"
        "NZM4jr1I5fRimpNj0dQHqmHSLHJq1KmcLEfHYUowm3IyIyvDkVBzCCkVRkBgYVkW2GUXln279/4/PPyfTufeXTsfGO7Zc+8553ee"
        "53eeN7ayspJlWUmSGIaRJEkURYZhVCoVy7KRSAT6WZaFv/AITZIkSZJYlsXB0M/+vzFEI1/kOI5lWZiI/Djz74ZLgq/BdPgK+Sv5"
        "E64KvymKItUDf/EL5HQcx3EchzjgduQrxBd5nuc4jmEYQRBi7YhcoQqfsfE8zzBMNBoVRZF6TQ43z/Msy0ajUYQmFtwwAOFGFGJt"
        "Rj4d1SP/iRyAJ0Gek/xd8hHghrVRcOP6yRdhO3hCiEAsuOB4VDgr9sInBEEg56AQISVCEAQ4m1iDFeGOjzWeKACHEqeIOPU31iyo"
        "EKSKkJoXB25Svym44RUKbkXphvELiONMarUaBPyOcIOAB4NBn88nSRJoFm6P47iEhASNRgPnB8fLsix5PJT2UdKqCDdJCIpwwwBU"
        "cPL7kUhkdnZ2QbVVquTkZJwI1BqFjNq4ItxAJrAd6njk0gPb53leEAQVYo1iGIlEKJmi6BLpOxgMXrlyhZQUqrEsazAYMjMzLRYL"
        "eZDU+vDUKSIWRRH3I5+Fghu/qQh3OBzu6uoiP5KVlZWbm4u0QM5LXV1yrkfiJY+ZWiGpLiqViuO4cDgsiiJHgYibjKPFSN9+v1+K"
        "0QRBcLlcZ8+era2t7e/v7+vri0ajsWQBeZDkd1gJxcXkFJRAxFEISZLm5ubId+vr6+fm5kBOcSJEWX7NYgNRlSQJ4VakbFw5miEA"
        "tyRJHKkpeAfGMh7IkahQio3juPT09LVr137xxRdXrlxRq9V9fX2KZC0SDZdOPcqvUDn0sV6hyJRq1CvU1UddvHhCwD+xgCaPEI4H"
        "aGPBDkS1xW9R3EqpDIyklBfa8PCw0+mE//V6fUFBAWjf8uXLv//++7KyssnJSbPZrIg7ecyknile/fKeWGevKIYU3NQNqfgFvPZB"
        "zuSwyA8J4aa0YcE6BJYAAxxJU/GjeAHKr9aDBw/u27cPH9PT0w8cOLBp0yaGYZYtW/bcc881NzebTCYSblEUA4FAOBzmOE6r1Wo0"
        "GpK75VeIIAjBYDAajXIcp9Fo1Gq1oqkO787Pz4fDYZZlNRqN4mGIogjECD0ajQavU+gJhUKBQADNkqSkJDQQFO1LCm5BEAAo8ixV"
        "eMiUZCnevOQ5K1oyKSkpRUVFYBi4XK66urrS0lKbzcYwzKZNmz755JNIJKJSqSRJCgaDo6Oj09PTpK5otdqMjAyz2Qy3GXnkHo9n"
        "fHx8dnaWlIDExMT09HQcj/1ut9vpdAaDQSZuGx0dHRsbI3sKCwvT0tLg/2Aw2N3dTWqPwWBYsmSJ3IEi9RWORw73PzYiCricT+Qk"
        "CGoS3zjheV6lUul0uvz8fJZlv/32W/hp2bJlsA1RFD0eT09PT3Z29uHDhwcGBsLhcCAQuHr1an19vdfrvXnzZjgcJsmxv79/cHBw"
        "48aNbW1tk5OTgiB4vd6Ojo6dO3d6vd7e3l70eEVRvH379tjY2Pbt27u6ukBI29vbH3jgAflSBUGorKxEKnjssccmJiZw3qmpqUWL"
        "FuGvr732GvADdfGQjyiUkUgEXEg5eaqQweN7GSR9x0GcbIIgJCQkuN1uZHaQfY/H09fX19DQ0NjYiEqqVqtLSkpKSkpefPHFRx55"
        "pLe3t6ioCH69ffu2SqXq7OwsLS0lxa2ioqKiomLHjh1r1qwZHBy86667GIZxOByCIFy4cKGsrAwHV1ZW/vTTT+vXr6dWmJqaevHi"
        "RafTmZWVxTDMunXrWlpaBEGAeT0ez1NPPYWDW1paUlNT5cSNgALzoLsuvwkWeALENhaOlMuE90ac6wiORxTFSCQSCoWys7Oh3+v1"
        "wsSDg4OvvPLKO++8A+sLh8Pd3d39/f0wLCcnp62tTa/XO51OSZL8fv/U1FRrayvCPTMzc/XqVbyic3JyTp48OTs76/f7A4HAxMTE"
        "sWPHEO5QKNTd3e1wODiOO3z4MLVUg8HAcdzXX38Nj9XV1QzD+Hw+0JXZ2dmamhr46dKlS0NDQ4C43MoiJTISiSBK8rCEJEkLjINn"
        "Inf6kcFJmz9W8/l8Xq93ampqfHy8r69Po9Fs3LgRfvrjjz9YlvV6vVlZWXv27IHOH3/8cdGiRXa73WazVVVVTU5OMgxjNpt37949"
        "MTERjUbdbnd1dXVlZSWM//DDD9PT0++9916r1drU1ASdxcXFlZWVHo9nYmKiqqrq4Ycfhv729vbc3Fy73Z6Xl/fss8+CF0YRS2pq"
        "aktLCzxaLJaSkhKv18uyrMfj0Wg0999/Pwp4UlKSRqMhsSZR4nkehIxkEkU8/4nCUMEaMpQI3AQujKJxRrbe3t7e3t7JycmysrJf"
        "fvkFFJZhmGPHjun1eo/H8/zzz2u1WoZhnE7nhg0bJicnrVZrZmZme3v7yy+/DIOffPJJrVbr8/lYlr106VJVVdWWLVtef/31+vp6"
        "i8VSVFRkMBj27t2Lky5dujQcDnu9XuSBUCj0+OOPC4Jwzz335OfnHz169PPPP5ero8lkAmKBnoceemhmZkYQhOnp6aqqqqSkJOhv"
        "bW2lBJwEB6SWJO44NyJHCrhipFDRnZM7fgzDfPDBB9jv8/nOnTuH2t3W1vbll1+mpaUFg8G1a9dC51dffTU3NxeNRh0Ox/j4OMMw"
        "p0+fRqOlvLx8dnbWarXqdLrr168fPXq0qalJkqSxsbGbN296PJ7i4mLSaIHLqqKiAmd0Op15eXkajcZoNJpMpuPHj8sJMzk5mSKW"
        "+fn5QCAwMzODlPL777+PjIwYjUbKzSFlUa79itFNnuc5ykSRm5loEcZ3teO05ubm2tpak8kEdnFhYSH079q1i5Iav9+Pby1evDgS"
        "iUDswev16nS62tra999/v7W1tbOz0+VyXbx4Ub7m3NxceOzu7tZqteCCsSybnJzc3d2teEsZjUYklvLycrPZ7HQ6o9EoIn7ixImk"
        "pKSEhARyqUDc4ODEioZSEEGEQCUPTlJeLxkho7xQCnGHwzE6Ogr/l5WVAfV3dnZu3rzZaDRarVa4lMBouWPT6/WCIPh8vsHBwVdf"
        "ffWtt96iXpyamgJ/ikQcecDv94PVC6vleR4Dh5SnSlosLMs++OCDzc3N+fn5BQUF8NmTJ0+CgFOwkJZbrNAuOR64XqXo2pLHQhK9"
        "YhwS2/79+9HnPHTo0NatWxmGWbly5erVqy9fvoy5Dr/fD9iNjo46HI5YU7tcLkmSRkdHX3rpJfzs9evXT5061dPTc+PGjRs3bqAZ"
        "ji0QCOh0OrBDotEobk0QBIPBIJdxjuPQYtmxYwfDMDU1Nc3NzevWrYMxHR0do6OjwGDg9yF2ZNInVuqGlG7QBlX8pBfwCTIP6XMr"
        "sopWq7XZbE6ns7Gxsa6uDiRu79695eXlfr8/MTGRYZiBgQG73c4wzJkzZ1544YU4Yp6VleV0Onfu3AmP586dq6mp4Xlep9PNz8/L"
        "Y2cMwwwNDQE6drs9GAxGIhGI+Pv9fpiUghs2aDAYWlpaAPHq6mqO40hKSUxMVKvVCDeZhLmjpsLxQAx8gaXl2T8yxUPGyeRxSHlT"
        "qVQ8z2dnZ7vd7o8++ggZZv369ePj45Cj+Pnnn6F/w4YNqampKSkpNputoKDAbDbzPL9169ZHH33UbrdrtVqwjhYvXgzjf/31V57n"
        "CwoKwM5D0w33plKpOjo64HHNmjW5ubnDw8OhUGh6enpqamrLli3yPAPIndFovHjxInj8JpNp1apV8HGSUjBGLYc7lrxiJJ3MGHOK"
        "gVC06uOY6nFw53k+IyOjqalpamoKevbs2RMKhWZmZoxG42effQZQpqWlnT592mQy3bp1q6+vLxgMHjhw4NChQ998883Vq1fRfAbX"
        "CSIzer2+p6ent7f37rvvPnLkCDWv0Whsbm5GJ7a1tVWtVl+7dm1gYGDbtm11dXUUKLg7sFhOnjwJP+3btw/s1wsXLjidToPBgHki"
        "eUBYEW4kH9K7XMiOxQk642iyhzqVWNpkMpmCweDu3bvhsaio6Omnnx4bG0tLSxsYGEAP6L777hsYGLh+/XpXV9fExMT27dvxGnA4"
        "HBaLheO4trY2jMyMjIx0dXXdunXr8uXL8nCxxWI5f/78Dz/8gIbH8PDwn3/+OTw8/PHHH//1119xskh6vb61tRX6V6xYQTk+mJaj"
        "YiH/BW4yLceyLCcHES1NylulvFvFRCjpSWVkZHz66adDQ0Pw09tvvw32X05OTmNj47vvvosnv2TJErvdDiwP1uSuXbtycnISEhLS"
        "0tLeeOMNjPBpNBq73Z6fnx8Oh5955hlq6sTERIvFUldXd+3aNehMSEhYvny51Wr1+/1PPPGEYgADbcSOjg4ylCiKIlAKGeaOde1R"
        "9Q2QTSMTp/gKJ4cbr0cqlC5nEvnEeBkAObIs++abb8JPeXl527dvd7vdBoPBarU2NDSUlpYeOXKkv78fYhEjIyMnTpxYvXr15s2b"
        "zWaz2WxmWdZqtU5OTpaWlh48eHBoaAgi2mfOnKmoqDh//rx821arVZKkioqKhoaGmzdvRiIRv9//3XffrVy5sqenJ07KQqfTsSyL"
        "xMIwzG+//eZyuVJTU0nbQbF8hbTQ4SaLRqPyVxYgWrFihby0A0LY4IDEWiWEq/7++2/yDCwWS3Z2Nn7K7/ffvn2bMmYKCgpYlg2F"
        "Qi6Xa2ZmhtRTnudTUlIyMzO1Wi2uVRTF8fFxt9uNYQaWZZOSkubm5sgvZ2RkZGdnw17cbrfL5SKLlnQ6HWWPWywWjEBgDqusrAxJ"
        "bNu2bcePH7fZbFSZFJUtQUDABETyobKmOCxmhRAckTzSQiWDCgsL5+fnsWIiOTmZ1NaUlJTCwsJwOIyLTkpKgsEajSYvLw/OFaBR"
        "q9XglJJrBSXNzs7OysoKhUKQLUpMTOR5HqLquFtM30C0xGQyzc/PRyIRnufB+QyHw2hTchwHZjvsNBAI8DwfCATQghQE4dSpUwaD"
        "gXJwFEWQJG55CRgdNYE5SEZTq9VAKXEyjQCEPA1NFd+QKTowfmN9E46ZcoBjVVEpOhqKKRQspMF7Xr6GwcHBQCAgCEJeXl5nZycI"
        "/tmzZ9etW1dUVASJvVh5MRQ1ylWMtdN/8pxU1UesWhkyzQr3J/VpeUDmv8gIWYmouL1YEflY+QEqyIz2GZWlhPiz3+9va2srLi62"
        "WCwJCQnQ/9577+n1eniMtXKMH8hd0DjZbRVpbkuSBJesvEjsXzF1pVy+3FIkSybjFEtiLVmcZEgs0Zb7BIolXWQWhlIdn8+XkpKy"
        "atUqcE3Re2hvb4eIWxzihigbGHVkQJCqUKRKxlQUuFSBABW3QnKgBFyuBPKaizhVCWQ9FKaQ7lj+oBjqiVWOIq+4g3/m5+dtNpvD"
        "4cjLy4O6rf3797e2tkKYNw6tAdzyHFscsQBLRkV1kTqoWBSJJSVyG5EqnKSqUGKRCSWYipEyxfqQOIhT1lccNQcnFgMJYCbabDa8"
        "4eNES+6Y9aX4DdBWUQFfslJU8U2yPiTWmshTiVV8Qxp/ioKMZYjyC1mesZVzt1y9FHFPTk5eunQpWEFgvELRmmJhKRWqjV+/RtVJ"
        "g8EtCML/AOR9K5mBz9H/AAAAAElFTkSuQmCC"
    ),
    "Retry.png": (
        "iVBORw0KGgoAAAANSUhEUgAAAHUAAAAnCAIAAAC+IJAXAAATjUlEQVR42qVbaUxUV/u/986dfYBhFhaHTTZBLaCAQioUlxJpNamh"
        "xsZGU1trqza2lpr4RUlc+FDbGrSttrYmJtioiEnXiNRabcSiKLWgWHEsy7AMDLNvd2buzPvh8T0e770DvP//+TSce9bnPOf3/J7n"
        "PJBlZWU0TZMkSRAEQRDhcJhl2XA4TP63UBQViURQAyiRSIQgCLwS1UBjfhcoqBLaR/5bCIKgKIqmadQSlgFdUOEMzp8L1fBnjLby"
        "aIUzDmd3M+xCg3BhvnA4HA6HI5EIRVFoS2g1aEsgC/5CYXSKovAG+KzRdgW90DFzhI5m56wHiRXV4wLlzAVrgC7Trifa2eA1glLm"
        "1zwjXI7mooXCyoLBoM/no2laKpWCLJAO4rojOBP/GHAVJkkS11xQXiQLvkyjqQ/nZuBTcwTKuXl4G8F7GW0WwZuBy4FGqwfl5dxH"
        "1DkYDFosFr/fHwwGk5OT1Wo1rj6Cl4gzNy56XEPhEiEUgmOeVrjTQpDgXeZ04UiWrzEcUEKVoIX880Y/UIMnty8UCrEsC2hLPlug"
        "tdvtJgji2LFjmZmZXq8XXyhf2TnqwN88LmKxWIzAJBKJwDELCncmysU5RdAYNBcff/ARoDFHTGgctDZ8TISo+IDwAz5RcBlDoRBu"
        "0HDljUQiDocjFArt3r27oqKipKQkHA57PB632+3xeLxer8/nC4VCHMXhiIOzbfSDA/T8O4Ra4r85colEKfwzQBLHh+KMgItP8Lbh"
        "EuerC6exKDU1lWVZCisc4brdboZhVq1a9eabb2o0GpfL1d3d7fF4wI6xLMswjMvlcrlcoVBIcBDcBOGLE4lEIpEI/8SyLLJpglg5"
        "LewKXn++pnOEPoVB41vpmSzjqX0D1RNsEYlEAoGAzWarrKx8++23ExMTCYIoLi7etGkTRVEJCQlSqdTn842Njf3zzz89PT3j4+NW"
        "q1Uul8tkMqlUyt8thxggbgCVoVAoHA7DseHSAbgQhAJBMUWT3RSywC1ttMZI8aPREmH+gNqhjaF1syw7Pj6ekZGxefPmvLw8+JqT"
        "k5OTk8Of2+Px3Lp168KFC21tbU6nMyEhQSKRCNo0WA1oLkzEMIzT6cQV8IlxoCiJRCKVSkUiEd+4RbPgghwjGvGYQq9nzhkEL8GT"
        "pZaVlSHGiq8gFArZ7XaWZY8cOVJZWSmXy6e9F8FgkGGYW7duffXVV7/99ltKSopSqYTBOegGhAGWwjDMzZs3p9gYSZJxcXFJSUka"
        "jSbaVmd4eaeV10zGwYkTshZR+S+6pJzT8Pl8brd7z549xcXFMpkM7+Pz+axW68TERDAYlEqlarVaq9UqlUqJRCKRSBYtWpSQkJCZ"
        "mdnU1MSybExMDNADwFzcZYCJQHMFb184HLZYLH/99dfZs2ebmpomJyczMzNBlzmeW7TLi2+qv7/f5XIhRpiamqpUKvk8ksPVBEWP"
        "qOQUeg0j04IcNhKJMAwjlUrj4uLcbrdSqcT112azffPNN9euXQsEAlKpVKfTZWZmlpSULFq0SK/Xq1Sq3Nzcbdu2RSKRlpaWSCSi"
        "UqlwPw00F5lpsGmCBVC+urq6urp6x44dq1evNhqNOTk5HPeET2A5ZIMgCKfTOTY2Vl9fD3+2tbX19vbCUIKYi6MqZ6gp2CffwRGl"
        "paVFg3Obzdbd3T00NITEIZFIKIpyOBxtbW2//vorTdNOp3NgYOD27dvt7e1mszkxMVGlUimVSpVKNW/evHv37v3777+I4eIoj2ya"
        "3++3Wq1o54ODgw8ePBgeHh4eHna5XBqNBrokJSUtX778888/l0gkcrmcD3xTI6nP55ucnLxy5UpVVVVVVVVvb++tW7f0ev3/hAzR"
        "lD2aMSBJkuavD0aRy+Wpqalut7ulpaWlpSU/P3/FihWrV682GAwKhWLBggVNTU1KpZKmadBBj8fT1NT0999/19XVrVixQiqVGgyG"
        "HTt2mM1mo9Go0+koioKrjQuXv6yjR49++umn6M+EhITGxsZ169YRBFFQUPDWW2+dPn1arVZzvABwLEmSlEqlUqmUY+gCgYDVauVM"
        "5HK5bDabSCSKiYkJBAJerxdBh0qlCoVCwOthgwgK4HRxp45hGJ/Ph0SnUqlEIhESKc3fIRoL5lapVMFgcGho6Isvvvjyyy+XLFlS"
        "U1MjFoslEglsCbRSqVRmZGQ8evTok08+kclky5cvJwiiqKiopqbm8OHDgUAAIQwIF8U6+GqiUqmAogSDwfHx8Y0bNxYXF2dnZxME"
        "sW7dumPHjoVCIdgDwzCjo6M2mw0HGZlMlpiYqNfrQfEZhunu7hbUzb6+PoIgdDrd5OSkINqKxeJgMMjplZ2dHR8fD78Zhunp6cH7"
        "xsTEzJkz52m0K8wrHCJFkqRYLI6Li9Pr9XFxcZ2dnQ0NDQcPHgSvBIcqmqa1Wm1/f39jY+PQ0BDLslKptLKyMisrC7QDUQgUe4x2"
        "DcH1kMvlaWlpJEl+//338KmgoAB2RRCEw+G4f/++wWD4+uuvjUYjwzAej6ezs7Ours5ut/f29gYCgXA4DN488gyhHDp0CGrq6+td"
        "Lhfu+9bV1eXm5v78888+nw8mqqioQF9fe+01i8WCjIfVas3IyEBfP/roIwiePHVQcebEkTL6gaioQqGIiYmhaZplWb1eDzYU707T"
        "tFwuf/DgwcWLFwOBAEmS6enpy5YtczgcIFMQLlrE1IYCBpdIJBMTE1ATGxsLem232/v6+nbv3n379u1NmzbNnj1bLBbL5fKFCxfu"
        "37+/p6cnNzf34cOHUxjPaEWr1V67dm3lypXgIhEEcf369dHRUfhdU1MDhAeKw+GoqalBfZubmxF2PZEvEiXHBeCENlChaVqhUKjV"
        "amAFnBgHIBTLss3NzaA4Go2mvLwcKSwKj00b/UOzMwwza9YsqLfb7aDgAwMDO3fu3L9/P9yhQCBw9+5do9EIzQwGQ2tra2xs7MjI"
        "CEzR0dHR0dGBxjeZTFBjMpk4GLVly5aEhAS73d7V1TU4OAjTtbS0wNeVK1cCG0FWB8m3o6NjYGAA5PuM/iLNwrWYI2uOnuLBeE5L"
        "kUgkFou7u7vNZnMoFBKLxXq9PiEhIRgMQpQOXS5OwAW3PHa73W63W61Wo9EolUrXrl0Lnzo7O0mSdDqdycnJBw8ehMrW1taMjIwF"
        "Cxbk5ORUVVVZLBZA1f3791ssFnDWy8vLy8vL0RSNjY1Qc/LkSUQfoWg0mqNHj86aNau4uDgjI4MkyZiYmObmZviq1+sXLlzodDoB"
        "oKRS6dKlS+HTuXPnIDaAC4QSJBnTxuKQ38LpgqJikUikt7fX7/cjg8MwDEQYpvB2UDEajUajcXJysrS09PLly8nJyVB/6tSp2NhY"
        "u92+efNm8HpGR0dfffVVi8WSkpKSlJR07dq1999/Hxq//vrrMpnM7XbPmzcvPT2dM4VMJps/f35BQQFgDipdXV0ffPCBRqOZP39+"
        "Xl7e3LlztVotDhEvvfSS0+kkSdLhcLzwwgsKhQLqz58/j+ze0zALh6VPHd8TDKkIRj8pipqcnAT4A0gB2J3WQ0WWJxwOA9EuLS2F"
        "T5cuXTpz5kx8fLzf76+urobKM2fOeDyeUChkMpnGxsYIgvjxxx+RBBcvXgwwhTgT/jIGxJxT/9NPP4nF4sTERAB0iUQSGxtLURQO"
        "EX6/3+fzOZ1OgAuCIG7cuDE0NITk+9Sf4kuHE+icOlrKLwhe8aXjbGQm+ssvp0+frq2t1Wq1YHaAAxEEsXPnTo5lhssLZfbs2fwA"
        "4dTF6XRKJBJ+AARBxOLFi3U63djYWCgUQuB79uxZhUIBa3smTMg3KRDc8fv9ED4PBoOIReB2jNMRbQ+9qYAKgLl3u9142IF/ZnzL"
        "09HRgaD5zz//3LBhg1gsNhgMQEg5lzpaiY2NhacD4v9RIpGIWq1GEEGSZHV1tdVqzcrKys3NhQYtLS0c5QW3gOaTapZlnU6n1+tV"
        "KpVer1csFqvVaolEgmMrJ5iNgwxFUWDl8vPzwZXy+Xzj4+PoMuLxJ76IGxsbkf927Nixd955hyCIsrKy5cuX37x5E72EulwuEPHw"
        "8LDJZIomGrPZPO1FiSZ9PH6EIOK9994Dlvbdd98h5W1vbx8eHp4/fz4HP0UiEc2PZYBk6+rq1q5d++DBg7q6uomJCY1Gg79sc14D"
        "kZiAGgcCgdLSUp1OR9N0MBg0m81msxk8Bf5bA397MpksKytrbGxs3759GzZsAAPS0NBQVlbmdrvhDj5+/LioqIggiF9++QXOIFrh"
        "W7aZFH5iglqtbm5uBvmuXLmSoihBcODE0ylOwAlCIXPmzHnxxRcTEhIWLVpUW1srkUh8Pl80WMBtGhyPWCxev349OMQTExNXr16F"
        "wJBgBEQgZkrTYrF41qxZExMThw8fhsrS0tI1a9aMjIyIxWKpVHr58mWor62tjY+Pj4mJyc7OzsnJ0el0IpFoy5Ytr7zySlFREbAl"
        "jvOGlCMQCMzcAQGIGBkZAR+kqqoKmBmAA8SmcVV7EjngvBgCAsCbG0VRCoWitra2pKTE4/GAu8lnGiglhaIoiLOUl5dXVFQA+Pb1"
        "9V29ejUmJobzpMZ5HuYXkUiUmJh46NChyclJqDlw4ADDMA6HQ61WnzhxAgyXRqP54YcftFrto0eP+vr6/H5/Y2Pj8ePHL1y40NnZ"
        "qdfrwd4Cqng8HhiqoqLC5/Pdu3evu7sbSCRffzmLBIg4f/484jlAEP/444/R0VEcfNHrDJefQZHL5f39/b///jvDMJFIJCsra9Om"
        "TampqS6XC4mYg5sAyn6/3+12P/fcc9u3b09KSqIoym63X7lyxWQyKRQKwTylqcFRp9P5/f4DBw7An3l5eRs3bhwdHdXr9Y8fP0b+"
        "xfPPP280Gu/du3fnzh2z2bxt2zaoP378uMlkUqvVFEXJZDKSJK9fvw6fIJTc1dW1ZMkSFHSfOm2Hoii1Wo3ku2DBAuRWwNsCJwvg"
        "ibLyrzy8Wp45c8ZoNLIsS9N0ZWVlQ0NDSkqKw+GAqB16oEMOiNfrnZycLCws3LVrV0lJCXy9c+fOpUuX4L5Hy3CZGv6SkpKOHz8+"
        "MDAA9fX19ZFIxOVypaam7tu3r6GhAY2Zn59fVFSEonSnT5/+8MMPDQYDTE3TtFqt3rVrF2Jv6enphYWFVVVVgvorGO2Nj49vb28H"
        "iEARkpaWFsi2QfTpmfgDP1xPUZRKpTKZTA0NDTabLRwOy2Sy8vLypqam9evXUxQ1MjIyMTFhtVpdLpfT6bRYLACL27dvb2xsLCsr"
        "I0mSZdnh4eHPPvtscHBQkEvx743gDiG+vmfPHqhJS0vbunWr2WxWq9Wpqal79+4tKSk5efKk0WgMBoMsyw4NDZ09e3bFihUbNmzQ"
        "6XRarRZpX3p6+sOHD0tKSk6dOjU8PAxMWaFQ8COQ0VIsVCoVDhEEQVy9etVsNsfHxyPk5ASnSIj48Z/EGYbxer1r1qzZuXNnWloa"
        "RVGhUGhiYmJoaKizs7Ozs9NkMjEMo1Ao0tPTi4uLS0pKDAZDfHy8RCIJBAKjo6P19fVXrlxRKBRwN6MJMRgM3r9/H19cYmIiCugA"
        "FXv06BHeRS6X5+fnQ2x7bGzMbrfj5kskEsXGxiYlJcEDNjLlJEkGg8GRkRGr1YqbNa1Wa7VaOQtISUkRhK/+/v7i4uLW1lb4c+vW"
        "rU1NTdnZ2fyELmC6z8iXI36fzxcMBletWvXGG2/k5+crlUq49W6322azud3uUCgkkUhUKpVarUZKCmHZEydOtLW1KZVKmUzGZw6c"
        "2weZg4jhwUR4M7/fD6FYqFEqlfynEEAtmqbB7OB5QByCBKYiGAyKRCKpVApBdDB9cBj4gyEKrXg8HpFI1N/fv2PHjo8//hhEYTAY"
        "IOqN+nLSaKLKF07A4/H4fL6FCxe+++678+bN0+l0MpmM78ujFAiLxdLR0fHtt9/evXtXp9MhWib4HMvPXp26Da4aeOAJ7DXusEAu"
        "HYeuzMSi4qQeN1OPHz/2eDwsy6alpd24cQPiTRcvXnz55Zfz8vKAnOAOKmIBZGFhIf7Wzc8bYxjGZrOJxeJly5atW7eusLAQYAjl"
        "S0BI1+v1tre3nzt37saNG6FQSKPRSKVSTp6h4OP5FNm4/L6oPT9HGDVGbBcdLV9/Z5JHjSpZlu3p6WltbZ07d65er0fRiaVLl3Z1"
        "daWmpoLm4inPT1NAQX+ntuYsy0I4IhQKJScnFxYWzpkzBzJ0/H4/5Ed1dXVZrVaxWKxSqQAT+MnlgueHpz8JpqHjUuZn5wkKF893"
        "R/kS/GxUfmYUP0sI8hHsdrvFYgEqAuXgwYN79+7Nzs4GlMezc/D4LVlQUCDo+PITPQHjELShYAIi8GKxmKZpeDrju93R0j6mTa7h"
        "tMeVF9F4TkIq33mZOmt26qjpyMhIWlra+fPn09LSAoFAV1fXkSNHmpubU1JSwG9CwuWkURMEQRYWFkZL8uZEeME0A/fivM6BTPH7"
        "KJjTGC0XkZ/YPEXEmf+vAwjyBHNb/6dDFZSyx+MZHBzEKYdCoUhKSgJDyklHepL2i/6toaioKJpV4QsXZwIAu/wwDQc0+ZdRMJU8"
        "Wt5jtMXAejiJvYgk/R+S0qb9zwN4fyFJEo+lIPIngAwk+Ux+ieDpITONMvLQQPgzJUePZpInKhj85Ss+Gg1/q+YYk2jpa4KpM4KT"
        "zsTZQZkrnFwp/OARcqL6/wAuHqk+hsdbtwAAAABJRU5ErkJggg=="
    ),
    "RaidSuccessful.png": (
        "iVBORw0KGgoAAAANSUhEUgAAAmwAAAA+CAIAAAAZLtCnAABMkElEQVR42u29d5wT1fo4PEkmvWd3k+1shaVJEZAuKLCogFLtBVGw"
        "4BWvnWtBpalX7BcVUa9dBKQIggX4AkoTQTq7C9mSZNN7r+8fj46zM5PJpOyC9/2dj3/g7OQ5Z855ztMLq1+/fiwWC0kyEokEksUg"
        "Q6YHSLOSCzvwCyN/AuWysdfwf8X+TbkPzLeL4UZRroH+lDsPGVIChKlTfnI2y6A/uwwgk3c4h7vEENPSvVz0O5zZ+unxubMxJ637"
        "yPyCYw8pP4T+gjOcOuVFTpeEpgstrV8xPOVOJePk3U55KJ3HAuAhSrM12aM+gTpf/ByUsAZYMP3Ckv015a/Iu5FIJJhzx5RvEnAr"
        "2fuEZcCbOad6TCgL/aQ5WRgBAmFPMoCP/aQz9i0tgCnfTLnCjBef8oddvDNkbM+A8hCIJnnGZPyS/Jwe69K66V3PQZnjNrzTlWSc"
        "TLu6jE3gvxRN9tkMF8SEzdATTfht5209pXzNcLqUtyvnC0trP1PyRbyQmCU5ZkhBuuDOZCmbpyUSMdGVsYcMrQtpLTstZpAS0zpP"
        "I0ypxWav5pIlHhqA6SrxOcTtZHw0S5qQmamJCbaTGXy6Am42tJH5GrIR4zpV3UKzRLh0jV0X6lPxkhRzMpoTuY9+XnoRr2uUwosE"
        "Ly/CQYk2zA/lIjSu5PC2UtKNzuPTXazlZHDBmRuKKH/bqRbItP7aZWTnYlhD9gPNWGhiwhiSeQvIOmhmCJQW+6eUZLuACGbg9sjJ"
        "Ggibn3OMzIkI2anaT875KI14wdDcl/PFXECme8EH863oVP6UwaHkSiCgsaAypyrZIFWWX0FefGdTra5golluCsEVn0y2Jf8vk6CS"
        "bFhm9lamLiPZ9JQaYeaCSpf+kjlTuhZvGt6WK+WenoZ2nlCfEjlzYstJGbyGiZ6dpALS0OJkW01jbsGsx9m44pBMXRL038Vc3GFo"
        "m6X0eubcA80w+imDDckyOIgh+iULBEFozdEZeD1ysmzmMFE2m50WaciYk9HE7DDEAybOsMzwg4Z15VbIyJWhg7kxLQNzcbqBD/R7"
        "mH3wTsoZkSThURfqmLLkoCmJcgYkO4dfl4HVN4MNydW3MCEa9HEhhL+mRe5zeChMMOQCKuUM40azid3rymWntUtoWh7pHAbaJLPl"
        "ppWEkNZ6UrJDmtuegS6Vbnw/k5CWlEtN94CSyRO5Qtzc3lgaoTWbAMjOs0dlbItjLv0wN391nnGMYRx49riUAf3NLQ5nEHLfqQLc"
        "3zFwIRs+enH6GtB0LaLZW1CZS1gpzSbpTp1urFrKNXSeY7WTHKX00gwTfTfliaSMdE83ljvlbtNEb2ag2WTg38qVAppsb5njfGbX"
        "h+FWMIwazTi2MyUWpbV+hlHcuY2iyAkidSrJzf5u5upw05q0U9M3spRFOphzc6t8pLVNeJKdTVBZNhvHPM8py2isLIV9hNbvSPMw"
        "rU/D/yS3GgA9YhAslilPhPmRMfmKzJJr02XwzFeVwf5nk8NDg0s5KSuR1m9zm2CWZaZANsmdKbGC5pQ7g7B0klaXVu5ZF+iUOY93"
        "SbZvKB6tOyMco7OtLhmL/zl0LNHf9lyJJgxDCbIkPWlZuXP4LZSmG4YFBBjyZiZXJV0zA0PCnbHZ9n/MLvc3/eouK8HzPzb+vgbn"
        "tO4y2mUVajrJLJDZRJR5Cxc5NndNQRDC5mQcdJfNt+AjhOnjNdJN/6XfQObMO1dEJF3luAvIXDInazL7apaa5cVP0DOIU80sq62L"
        "6XBuiQk9qHg8Hg6Ho9EogiAcDofH46EoerExFJr9pweFIl2VVp9B6RaGsTb0rzmdTpfLFY1GURSVy+UKhQKhLcqTQUB8p9aUYG7o"
        "prdOZFBbKi3/E0PTDRN9mmzsoq/VhzCOR0srWofmRjHJCu08L2xObGsMgzUo0a9ryqXmPE6KPu8uGw6a0riCMLPWprwLncFm0vK1"
        "paW3xWIxh8PhcrkCgQDhCnO5XIlEUlRUxOFwulIOI1TvYuL2TrmwDMWBWCxmNpt9Ph+TRbPZbC6Xy+fzxWKxWCzOiWhDQ4IxhI5E"
        "IufOnfN4PNgumM1mqVRaXV3N5XIzu8wsFstsNrtcLsI7YrFYrVZnL14Fg0Gv1xsMBsPhcDweZ7FYILgJhUKJRJLxsjMo+5IrOS6D"
        "0HwmR59WbAJDnwXB5EtDO3IixV9A80+6zotkTILFYoXDYb/fHwwGo9EoYCx230UiUcY3gkkGQpaqG/O6QtkvFcnOU3Ax2MmY7za8"
        "5vF49Hp9JBJRyXgTxpbXVSqUMn40lnB6Qs16z9EztsZWWyKRKCsrQ9KpMptyH+LxuNVq9fv9hMVLJJL8/Px0ATJZGJrunYcpzWaz"
        "Xq9PN1KOxWKhKJqXl1dQUMDn85OtlYnvKqXlLZFINDY2er1eQnCE2+1ubGysq6ujzK5JiShOp7O5uZn8jsPhQBCkqKgIYVAAk3xs"
        "0WjUbDbbbLZgMEgOyMSWCniQn5+fWbHizjZ/dU3Vnmy+jkzIKBGPuTkupaqUTWGz7PvVJFtnNoGj8FGxWMxutzudzlAolMwSwGKx"
        "hEKhQqFQKBS5DW29qJwvGSyma35yAW+cx+NpbW0VC9nP3jNo2rhKoQDlsP9YfiKBxOKJSDQ+YMZaQJ6cmDOxYbVajUYjebUul4vH"
        "48lkspx/MprZdfJ6vfF4PIPVxGIxo9FosVgKCws1Gk1m6jOTWBKbzeb1ehEEufvuu++5557S0lK9Xr9q1ap33nnH6/Xa7fa8vLx0"
        "iQuLxUr24YlEAqZDGDReIJAkk8lkNBojkUiymizYQ7fb7fV6jUZjWVkZ2KU7VcXJIEskG7GOIZnIbXu+DCyTDA3sTPyvadnZmJe/"
        "yaasK5PlWa1Wq9UajUZpqgjBc5/P5/f7bTabRqORSqU55BYp2yQwB8I8BjtdU2cGO5wuRlF+clq1eBimkDH/kGAwqNPpCpS8j5de"
        "0aNSLuRTqGq/n7V5/dH8fEXOW3v5/f5kJNrv92NImE1XBgLaZKiJwr/tdjtDE6XFYjl79uzBgwe3bNly+vTpeDxuMBh8Pl+3bt0w"
        "mzhz2sekMojb7U4kEk888cRjjz0GTyoqKpYsWSKXy5cvX+52u1UqFcKsigK58Nju3bv79OmDf0elUsFfmfRhwABGo1GtVutyuWKx"
        "GIIgarV60qRJI0eO7NWrV1FRkUQiicfjHo9Hp9MdP3589+7dW7du9Xg8fr+/qalJo9GAJeQitOdkfBW7Utxm6CFLaabLrD0npqem"
        "xRqZNNih+ahkRg7mJxWLxXQ6nc/n+wNjVcJrRpePGFDYs1pZXCASC7nxRMLji+hMvhON9j2H27/b2+rxRYLBYFtbW15enkajYYIk"
        "mdXNyDhUMBusyznGMvQ40HxyxrV4cvUtJpMpFou89vjoPrVKlENdEe+Xo8ZEIiGRSLLhoDTE1rLndvzDk032MbM357akFLZdaLrh"
        "DxlstEAgKCsrKysrGzdu3MKFC/fs2fPss88ePXrU6XQmEonKysqcuJcIQEAYmTdvHuHNefPmLV++PB6PZ5YSTk/y0gruisViTU1N"
        "Ho8nHo9XVVUtXLjw2muvJYgUHA4HrGF9+vS58cYbA4HARx999Morr9jtdqPRGI/Hy8vL05WBLogr7m/dE6ZT6U6WqVBpLYBh1hAN"
        "B21tbfX5fIlEorJU+uRdA6aMreCwO8zOYbEUUp5CyutTo7zhqupAKPrxxoZXPj7mcIVsNls8HgeXR9fgw8Vg9WWYW8X8Jwwzpy/U"
        "jQuHw263++pR5SMGFCbjoAiC7P3NyGKxmIfIXJx0CbYapdR86e1IWU48atSoH374YdGiRW+//bbL5TKZTCnlU4bWM/z/CoVCJHmk"
        "nFAohCAIJgiXVlwrkya68LClpQXU5blz5z733HMEJzHlEAqF995778yZM+fOnbtr1y6z2SwQCMjechpJ7YLUxmNO5rqyTWmuSvim"
        "ZUGhsZiRc0voTc3pmnwRUlptuub69vZ24KB3Te/53P2X8ripbUhCPjpvVq/p46vufWHPrkMGh8MhEAhoPBHZ5J5dtFmJOTT2MmST"
        "aXUsz63YAQ6v666o4PM6oMfxRvvrnxw/r3NzUXZFifTgcbNIJGJohuyMK5wrVEkkEihBf6KXgHK1Ag6H88ILL3A4nDfeeMNkMsnl"
        "ch6Px5AMMZxCoVCYzeZ333330UcfxT9/7733eDyeQqFgkshBtmAztEmmZMMul8vhcCQSiUWLFv3jH/9Ia/fy8/PXrFkze/bsLVu2"
        "GAwGqVRKjtqlZ59I7nqPZKbMkTf2gnT57qQ7xtDnlEFuSUr2mVKDobf00uyDx+NxuVyJROKZey994KY+6WGsUvDFy1fOefr/tu5p"
        "NZvNEomEJmqXvLAM6m1l8FuabyfLedljZs5b3NCcI5PK25Sh6RmMQCCAIMiAnh0k+3gisfC1g8ebHAgLRRCkocUdDMfLyzVdv29M"
        "8CfdwyVqogxzJSmH0+n87rvv8E/YbLZYLK6oqOjVqxe5Xcwzzzyzf//+gwcP2my2wsLC3G4HiqJlZWWvvfaa3W6/++67y8rKDAbD"
        "e++999FHH5WVlaEoStYak31ysrI45PdBu2UCx2g0xmKxW2+9lZKDGgyGEydOOJ1OLpdbXl7et29fgpCBouh77703ZsyYxsZGu92u"
        "VqsZ3jGGFynnlk9KYzKB7mdc7fZiU1LpNaQMOh+kLPpIZrqZmW1pVmK1WuPx+C2Taik5qMHiP9lkd3rCXA67rEjctzaPx+1w31EO"
        "+51nRl1517eNLS6XywVhfV1mm+3UqlsXHMGy35AcrgcqKhTmC/EPjdbAb6ctIrEMKBUwHTAWXiQHmg1jRnO4xTqd7v7775dIJPgw"
        "vFgsFg6H+Xz+nDlzFixYgJdA2Wz24sWLJ0yY4HQ6kzHRbHYqFotxudx333333XffxR4WFBSIRCL6w4hGo36/PxQKAUKgKMrlcsVi"
        "cVppmpRbB9MFAgG/35+Xl7d48WLC+/v27Vu0aNHp06fB1hGPxyFq99Zbb33sscfwKxcKhUuWLJk1a5bD4SAz0ZTGA5ooFYZHn67u"
        "SJm3moFuhOSi30CnmrWzicvN8n0msRiUAlayhBx4HgwG/X6/Ss5/fv5gwgv7fzc9985vp7U+gUAAGBuNRlnx0C2Tqh+Z3U8k+Ou+"
        "CwXoC/MH3/Doj06nMwMm2nmVTOj3qjNaQeTc8kwDkEkqdvYNH4PBoNvtjsfjkKTA7Wjqd3nC4Ugc8fuxDHs+n0/PROkD/TqppHBm"
        "YFEkHecKk2lEIhH+hoB+FolEXn/99V9//fWLL77AQxg0aFCfPn1OnjwZCoXITkFMuIZA+UgkAlH1HA6Hy+WKRCKxWJzMLuT3+41G"
        "I3BB/HC73SKRSKlUUn5pKBSy2+0+nw8yx0FiYrPZkOEqFovJADMQ9sFtcNtttxGC/rdu3TpnzhyNRlNaWoqiKJvNxnbvk08+2b17"
        "97fffovno+PGjSsvL9fpdNFolMPhxGIxq9WKr4ABGyiVSimzjK1WK74SBXZ8BQUF4KuAtGVwg+FFH7lcLpPJOBxOMBj0+XyBQAC2"
        "BTsUHo9HwJNIJOL1euEQE4kEiqICgUAqlQoEAjIViMViFovF7/dTzouiaCAQAJSAeXk8nkgkkkgkhHkTiUQ4HIZ5w+FwIpHgcrkw"
        "L/4CpzTRe71er9eLRz8ofyGVSpOhXyKRgIIkWOIT9plyubygoCAej7tcLq/XC1U1YOej0Wg4HCaA4vP5RUVF5IngS30+n9lshlhZ"
        "/J9kMhn+0D0ej9PpjEQiXC5XoVBAVCRBbSUX+cPfpkQicevk7lJxBznyu71tdz3zfwXqwuLiYg6Hw2KxIGQvEol8vKVt9+H2TW9N"
        "xPPRK4eWlBVK9GZ/LBZjs9nxeNxut4MBED8kEgmEuxPokt1uJ+wnSJN5eXnJ+iJj6BcIBKAiRCwWg+sM5SAwDKQn5fiMiEgkQqgv"
        "gaIoj8cTi8X00CghRyIRn8+HQWOz2bC2DIqrwC0LhUKRSAQr1YLdSiato8mrAlDIn+X6hEIhGVQikTAYDJDjDleSwCQAQjgcttls"
        "8AQojFKppKyNgCCITCajlLRsNpvb7SYznYKCAnocYCK+ZCDQI50RnQtIQEkIfvjhh88///zmm2/G/6m+vv7EiRPBYJDARFksVigU"
        "MplMTqczWU4q1B9Qq9XkFFrAAPJPQqGQx+PBM1Hs6+x2u91uxxRQ8g9DoVDGAfcEqQ1BkPHjxxPw7JFHHoHkdMzfDtPx+XwURY8f"
        "P/7KK688/fTT+F+NGjXqs88+AyZqsVja29spzexcLpewRW63u62tjfwyiIoQ6mWxWCAGmAxQrVYHAgHKrFkURRUKRX5+PhCUQCBg"
        "sViwNB6ytR8yCPHbZTabKed1OBwajcbv9yebV6lUqtVqYJCBQMBoNDqdTsp5oeSYVCqlOdBQKGQwGOx2Ow36SaXSwsJCuVxO/qvJ"
        "ZNLr9eTnDofDbrdjEgB+V2l4QFVVFfl5PB5vbGykRFeHwwFVruLx+Pnz5/HAzWazUqmsrKwEKQ1JVQIQbiKCIOOHlXacPfHYK/uF"
        "IolCocDoF8CB4qjHG8+t+O+xp+YN7ICxlxZ+vqUpGo3yeDybzWY2m8kzut1uFEUJIqbH4zEYDJQvg4WJcus8Hg8ljcYGj8fLy8tT"
        "KpU0JBjbFrfbzQSaSqViQtA9Ho/FYqGp+wZhg0xKVbhcLpA7aciyQqEoKCigZPOEcA2z2ZwWKBBVp15ZMW1cJeVPyoukny6/Av/k"
        "lid2eL1epVIJRIbyi9KlWoWFhZ1a6zs9c25nGFXEYjGfz//qq68ITLRv375AJgjv6/V6q9WaSCSGDBkyadKkQYMGVVVVKZVKFEVd"
        "Lldzc/OxY8d+/PHH7du3nzt3TiqVVlRU4Jk3UBbKhE4yVYWKBw6HIxQKcTicq6++eurUqYMGDYLSjna7/cSJE+vWrVuzZg15nRls"
        "DqytZ8+e+Ifnzp0zGo0qlQofsYaJLKA/rVu3jsBEy8rKoNAaqAsIKXn3xIkTo0eP9vv9BHSElyn3B7s/oH/o9Xq83vbFF18sXbpU"
        "r9eLRKIpU6Zce+21AwcO1Gg08Xhcr9fv379/7dq1Bw4c8Pv9oG+ZTCYulztixIjp06dfdtllZWVlXC7XZrOdOHHi22+/XbdunVar"
        "VavV+AjtbOb1+XzwsL29nX7epqamwsLCwsJCSidlW1ubxWJhgn4NDQ0ymayqqgpFO3TnBeJIeRxut7usrGzevHkTJkzo1q0bKByQ"
        "uEw+kUmTJu3fvx90FDL/iEajixcvvu+++/DP//3vfy9duhR4P3DQadOmPf744zU1NU1NTcuWLduwYQOCINXV1cksTIQncGXqqhT4"
        "d87r3EarH/aErMICxq7/UUtgomWFEsBY8GsgSVL6AoEAMFFsJfDyrg8n965R4d8vGPVfsi4LlF2n0/n9fqEAnT6+cvyw0r7d80o1"
        "YpEADUViZlvgrNa5+3D7Nz81t7e3W63WkpISmrTFcDjc1tbGHFppaSkNtEgk0tbW5vP5+DzOtHGV44aV9uuRV6oRC/loKBwzWv0n"
        "muw7Dxo27WzW6XRms7m8vJxs/MS2Ra/X+/1+kQCdNq5yzODiS7qrSjQSsBm4POEWg+fwKeuW3S0/HzGCGJosGyIQCMCOpQsKzA81"
        "5fL6EdSZ61Ixl/wnQCoaHEhGtShxgIbrp8sU0+VxKHMDcZYRbqArHD9+nPAC5I3hhf14PK7Var1e7/Dhw5csWdKvXz/CTxQKRf/+"
        "/fv373/bbbcZjcYlS5Z8/vnnDQ0N1dXVZEMik2G1Wm02WyQSGTp06Guvvda9e/cOJ1RQMHbs2LFjx86dO/eOO+5obm7OcuvhTQJ+"
        "wCXxer1Wq1WpVJLrMhcUFJhMJgKFDYVCzGv25rA7W58+fV544YVhw4bhI56qq6urq6unTp36+eefv/322y0tLSAkLViwYMqUKXjh"
        "AK7fmDFj5s6du2DBgt9++43FYiXz7KY7r1arZT4vpnbjRZzz58+ni36nT5/u3r07kzwlBEEmT568cuVKvGUeG+vWrSMc8cSJE3/5"
        "5RePx0PWd0G/rK+vJzxfu3YtaHJut9vpdE6fPn3VqlXwp9ra2g8++ABBkA0bNng8HiD0KTNngH/LxB2i2wR8FGQFu90O5hPCbwFj"
        "L5n+TQeMDcfz8/MBY9Mq48wwjRuzcre0tLCQxN0zej5yRz+VvMO58LmcskJJWaFk3LDSp++59KONZ5evOtrc3FxUVEQwIQI0r9eb"
        "LjStVltcXExpkIS1JRLx2df1eOzO/vlKQcdd5VSUSCtKpJMu77b4gcHvfn36lf/+fu7cudLSUnxqECzM7Xa3traiHGTBrX3n39RH"
        "LiHmOKjkfJWcP6Bn/l3T634/a/vnS/uONRjD4TC5Tovb7W5packJqAs1chs9QAmW8lfsLLE2ra8C7ybZ0kvwPTQ3N3u93oceemjz"
        "5s1kEkYYhYWFb7755jvvvBOLxc6fP59BGSefz2exWCKRyM0337x582YCB8WPSy655Ntvv2VC6+kHaB4E0am0tHTEiBHhcNhsNoMa"
        "5PV68ZY6sECKRCIhbiiVSoaldFOmYzIftbW1r7766qhRoygTk0Qi0R133PHggw8WFRUNHTr0ueeemzp1KmVCGIfDqaur+/jjj/v3"
        "728ymaDQMc3xdfa8MECAywD9mpqaQCSn/4oBAwasXr2akoOy2ez169cTHk6YMAFv7MVK0oAVq7a2FlMoYRw/fryhoUGpVLJYLPgV"
        "VrQLG08++STAZHUcGHzC+ANjgx3MMKUa8fD+GsBYnU4Hdk5wxcEQi8VFRUUiaYFQki+U5AvEeQJxnkKlBhdmZ8RzYUSmublZJka/"
        "XjF+6YNDCDyPeBlR9t3Te+78cHJtN3l7ezsUwSZ4nTODZjAY8NAwXaq5uVks4Hzx8pUvPTyUwEGJ7l4BuuDWvj+smlSqEet0Oswf"
        "DAsLBoOtra1yKXfjmxP/NXcgme0RRr8eeVvfueqqkWV2u91kMhF00JaWlpyAyu3AY/uFZcw0K2Fn9mEZcNBoNBoKhch51qDOA7Fj"
        "sVgmk8nj8cyfP//pp59mvn0zZ85ctGhRMBikNK/TL9JsNofD4YkTJ77xxhspk3+Li4vfeeedLA8GlM6GhgbC89WrVw8cODAUCjmd"
        "TrPZbDAY2tra9Hq9zWbz+XzxeFwsFss6DqlUSpNi20lo/cgjj9TV1dF4fVAUra+vv++++6677roxY8bQQ8vPz1+xYgX4dLt+Xjab"
        "bTKZMM5nNBozRr9AIGAwGOiZKJvNfu6555JZDrhcbltb28GDB/EPu3fvXllZSW4c5PP5IpEIpRqKGYfB+1BTU0N4BzysZN8EgVJg"
        "7BBYfmMLMaBj1XOXD+yZj2Fse3u7TqcDRzLY5JNhbEriiOfraY1oNNrW1iYWoutfqx91aRHDX5UXSTa+UV+iFhsMBojtgqkjkUhr"
        "a2vG0PR6PT5SLBqNtrS0CPnsNSvGXTGkhCG0ukrFxjfr1SpBa2trOBzG9kSn07FZiU+XXTGodwFDUHwu5/3nx/TrkWcymfA28CxB"
        "wTcazL5fT1rgP8LLwVAM+xPlC3/rgWLWYeb22wzK44XDYahYPXgwMUS+tbUVPChgJTeZTD179nzmmWfIMBsaGs6cOROJRMrKygYN"
        "GkQgpvfcc8+nn37a0NCg0WiYePUxSuTxePLz899++23y9/p8PkhjzcvLGzx4MNi+xowZwyRGl8bsLpFIOBzO9u3bBwwYgH+uVqt/"
        "+OGHtWvXfvjhhwcPHgTUhMZSPB4PC42jVGKYW7qyHBMnToRk+UAgcPz4cYPBUFRUVFdXRzA2FhUV3XnnneD2CIVCra2tp06d4vF4"
        "vXr16tatG0EvrK6unjRp0saNG8PhcDKZoFPnDYVCPB4ve/RrbGzE0I/y9Hv16oX922QyHTlyxO12y2Qy0CZ5PF4oFFq3bt2QIUMI"
        "375y5UqfzycWizGwoGVOnDiRcMrr16/n8XjgUAQNsqmpqba2Fv9aY2Mj9lcmtxt2fvvPbf3rOtgn1SrhtnevWffD+Y82nj10wkKJ"
        "sRKJBCsfRp8ZTCmsM+x7ig2IyX/9mcv7dlcRnXDxxOGTljajV8BHB/Uu0OR18DIWqIQrnxl17QPbTCYTVk0ze2hGo5EA7a2Foy7t"
        "ReRV/mD00AmLxR6QS3kDe+XnyTtoqGWFkpVPj5r+0PfY2vx+v9/vv3Vy9yF9yTniyLEGm1bnSSCJmjI5YeU8Lvv1J4ZfMedbk8lU"
        "UVGRE1B2u53L5e49YtSZ/jA0fr2iQ9SkyR54cfVRsuko5/J9bhOHyM2LqJkoQlXPPpsKHW63G385IW8MYmJZLNbcuXMJ7//6668Q"
        "0o0gCERCPvnkkwRR/dy5c/fee++vv/6Kt+x9+umneNLAZrNnz579+OOPU3qPkg2Y8eGHHybH6/7nP/95+eWXIR8jFovBa1AbgVKT"
        "SFkACHuBy+UqlcrVq1ffe++9hKWyWKyZM2fOnDnTarXu3r177969e/fubWpqgvBIHo8nEAhAus8ABXPCR8GWsGvXrsWLFx87dgzk"
        "if79+z/55JNjx47F7wyQzjNnzrz55ptr164FvScvL++GG2548skn8evncrkTJkzYsGGDz+dLxkQ7e14ul5sT9HO5XCnRz2azPfbY"
        "Yxs3biTE/YpEonA4vGHDhqVLl+KNIvX19StXrnS5XLB4OESXy6VUKi+77DI8hH379un1eixaCup2vfjii++//z7+tWXLliEIAjjP"
        "5GrzeDylUvnBN2fuub4XwdbHYiEzJlTNmFBldQb3HG7/+Yjx5yOmplYXhrEejwfDWOY1cSD4KF2aGAwGXS5X/YiyKWMrCH/auqf1"
        "yVcPGCx/+FA4bNZtU7oveXAIF/1LGBrWTzN2SMnOgwbIBQoGg06nM3to0WgUoDkcjiuHlkwfX0Vgxq99fOyNz074g3+I5iiHdfOk"
        "2ufnD8ZnB426tGjymIpNO5vVarVAIPB4PAiC3HBVNWFhB4+bH1j683ndXzaDvrWqd54d3b3bXzjZu0Y1dkjxjgOGWCzG4XByAqq4"
        "uNgTDB47F6TsSuL1hXcdMkAjbkxhYEKl0+3AmvI1+l6NNDScpvoVynBNzJm83+/Hh7/G43HgQGw2e9GiRZdffjn+5Xg8vmXLFtDM"
        "QLgWiURDhw7Fv2M2mydNmmQymVQqFaQo+Xy+xsbGefPm7dixA//m8OHDYQEMmSj0SJFKpbfddhvhTytWrFi+fLlGo8GKHvh8vsWL"
        "F/t8PvAnZcCl8HtYUFDQ0tJy//33f/zxx5R6c35+/rRp06ZNm4YgSHt7++7du7/77rvt27e73W5IkYTC9Mx17hzy0aNHjz711FNn"
        "z55VKpVCodDv9588efKNN94QiUQjRozAv6nX6z/77LM1a9aIRCKNRhOLxVwu15o1a6RSKd5Rx+Fw+vTpA0n9TOZVKBRCoTAQCDCZ"
        "V61WQ1Jmynnp0U+pVIpEIjab7ff76dEPQsaS3Re3233NNdc0NDRIJBKFQgEiWjAYZLPZ0BzQaDTu3r177Nixf5HjYcNkMpnL5cKq"
        "t0Mr7KuvvprggPj6669BYoD/lcvlCoUC/KwQndvY2Lh06dLNmzerVCqJRMKcS6nVaq3W98CSvR8tGctmU6BQvkIw9crKqVdWIgjS"
        "bvXvOdy+bW/b97/oIB3W5/OpVCrAWCaaKNmWywRvIQ3xiTn9Cc/XbD83f8leFosNmVexWMzhcHy44Ww0lljx2DD8mzdfU7PjgN7j"
        "8ahUKibQhEJhNBp1Op0poVmtVgRBnrxrAEHVu+f53Rt+aubxeBqNBswhTqfzvxsbzja7vnl9Ar6G+4O39Nm0sxlCf0Hp713TQfT3"
        "BSI3PvqTNxDNz88Hecvn851oss986Pu9n1yHz/G9ZnT5T/v1Xq9XLpeDuJMlKC6XK5fLod1YslsM+WyY5wUSiy+sJZZhNTp6EoqS"
        "SXz2H4a1WgVvSllZ2bBhw+644w7IZiH4b4xGI1gVIH7B6XR2795dLpeXl5eXl5dXVFQ0NDSYTKaysjKMNCiVymg0evToUYPBUFxc"
        "jEEDOPRZKAS5NRKJTJkyhRA+fu7cuRdffFGlUuEjIIRCYSQSWbFixfTp02mCjxgKQQKBoLCwcOfOnbfffvvKlSvpWwIVFRVdf/31"
        "119/vcPh+Oijj9566y3IxonFYgyjinI7PvjgA51OV1xcDNl1eXl5RqPx8OHDp06dGjp0KJ6sHz9+fMeOHVKptKSkBOwTEomkra3t"
        "xx9/XLBgAaZ0slgsYA/k7CPKeTHpwWg0/vrrr8nmlUgkMC/kE9PMixWLcLlclOhXUlICXsbs0W/JkiXgdKCs0iWXy41G4/r16/FM"
        "lMvlXnHFFRs2bAiHw6Alg4uUYMuNRCKbN28WCAQCgQDTcSsrK7Va7fr16/EhS0qlslu3bmnpeUKhsLi4eNdh/eyndr391EiJiK4O"
        "QFG+aFZ99az6aqc79NHGhv98edLhckEGdn5+PkPJj1DogInt1+1296/L61PbwerYbvE/+u/9KMqtqqri8Xjw1SqVSqvVfrK5YfZ1"
        "PfBWyuH9C0ESUiqVTqeTBlp1dTVmcsvLyzt//jw9NJfLdUn3vH49OtjDP9/SuOGnZqlUWl5ejm1Lfn6+Tqfb/7vpww1n757+VyLc"
        "Jd3zarvJtXo3RkwIrToNZr/bF1YqlSUlJdhB83g8Q3v7kvd+61mlNFh8BrO/3eI7r/MgHQNIswcFF43P5ydjonw+Hx++fvG0VU+m"
        "KJJ7QiQ15zL8qpR23T59+jDsMIqJjYsWLZLL5RKJBICXlZWJRKJgMBgKhc6cOYPlw8jlcqVSGQwGw+FwJBIJhULgFSfE+kJjHcoC"
        "tpQDgIwePZpMrIE/4ekym83Oz8+3Wq3vv//+Sy+9lBn7xC8MiuDv2bNn9OjRixcvvvrqq1PCUSqVDz300B133PHoo4+uX7/eZDIB"
        "D2NOkjJrQtvBMuP1Hjt2LBaLgVqGXQ8Wi2WxWNxuN94wbrFYdDodvmIi1Cry+Xx4XxGLxcKc4snODptXKBRi8woEApp5RSIRw3mB"
        "5ZSWlgL6hcNhPPrJZDKlUgmFYJigH83uRaPRL774QiAQaDQaykKMfD5fIBBs3rz5lVdewVu2wezsdDpVKhWE3aIoOm7cODyEn376"
        "yW63FxcXE4Lyq6qqoGIR2BXlcjmWgpns7lOeAmDsz8esY2ZvfuGBwVeNTJ3boJDxF9za9/Zruz++4sA3P2mNRiPcIybUBgbD9Hk2"
        "mw0lOK4aSWwO+P660/5gtLy8HPYTm1etVjc3N7+79tSs+g6WTD6PAzWJmEDDFqDRaLRaLSW0cDgcCARisdhE0o69/eVJwBlCDQHA"
        "oi+3nsMzUQRBRg8qamw5Ew6HgTQZLP5SzV/dxKrLZL1rlCebHNB9GuInCgoKHA7H6vVn8KSMy+Xm5+eDxQ7EspyAYk5b0uWguXJ2"
        "ZpMhmoyEorldRFq0+Oabb/Z4PKWlpRhN5HA4+AQSSJoMBAKBQODYsWMEoeaOO+4ghx2mtd1/mER69yY83759u0AgIOf8AYH74Ycf"
        "cnX8INw5HI65c+fW1tbeeeed1157Lbn6EvlX77//fl1d3dKlS00mEyS9dIZcRvncYrFA+A9enwB9Hez2hB0Oh8OEL4J6b+T6dvQD"
        "5uVyudi8QDrZbHayeaEQEvYhNPPCGRHQz+fzAfoFg8ETJ07kBP1aW1u9Xm9eXh4hmg8f36dQKIxG4/fffz9p0iTsh+PHj+dwOOAH"
        "jcViHo9n5MiRhI2FuFy5XI7tBvbtEokEb+2gtznRkBKlUsnlch0Oxz0v7K8t+332dT0mj+kmS5URoZTx31s0uq5Ssez9I0ajUSwW"
        "M8FYvALKJAoJFKBLSfGlW3a3QhUtwrdDxNNX35376rtzhJ/I5EKQk1JCwwbUkqSEJleIANrgPh2gme2BxhYXWRrDxhmtk6ioVKvA"
        "hCYSiWw22+5fDTddg3fMs755vX7Ff499/f15q9UKBmQoSSiRSCA0msvlElwAYK1lDkosFoMcRgbVSRy0szXOLH+OXpDPOHXq1N13"
        "393W1qbRaMjXKZFIOBwOk8kEZmE+n9+7d++ampry8vLi4uKSkpLy8nKwzGS5DDDiEZKF/X6/Vqslxxlhqk9LS4vX66U0wCarmkZD"
        "s6DepsfjaW9vf+qppxYuXDhgwIDLL7981KhRAwcOpKmi8Mgjj5hMptWrV1ssFuatubOXgWKxGHPHavaKb07mTav3J4Z+wG5zi36Q"
        "HEwuSoXvUyaTycCii2eieXl5gwYNOnToEDjyE4kEIbnF7/d/9913IpEIs1im6xCiaTVKxlixWNzu8D6z8sRTbx3p30Mx+tLCEQML"
        "B/bMp+nD/M/bLzHZ/B98c9ZsNhMipbMnuywWC86rprxjjZtg9LzOLZPJyeEdLBarsrLS4/EQnAhQbQ5KDCaDRrkGPDRsOhRF5XI5"
        "QKsu6wBNrRISKvWkHGVFErDbg0fjrS9OzphQjW+Yo5TxX3hg8PPzB59tdh45bf3tlPXIGeupc45INO71eiE0gSB7yWSydEH5fD5K"
        "UBc/B8257zIFE81AUGUyHnnkkY8//pjL5RYXFxPKYwJjg2ILKpVq7ty5kyZNGjBgAMOKPOkeJAjshCik9vZ2iMil3i8URRDEZDKR"
        "mSh9lATNYjgcjkKhkMlkfr8/EAicPXv2+PHjr776Ko/HGzJkyBVXXDF58mRw3RHG888/v2XLFovFUlRURF+rGm8Zy6Av4993kIPr"
        "UrJqDP1uvvnmTkI/yn3GlgeF0bdv3+73+/GxxPX19QcOHPB6vRBOSWCiW7duDQQCeFsu84ZoBE9Nyt5tbDZbqVTK5fI/MLYtcPzc"
        "+dc+O8tDE4N75429rHjS6G5FBRTR44vuG7R1T5vV6SwuLs6gJxI9egP3IpQvMFr9iQQChhOCVwXceMnEZRpo2MoJ2wsXmXLTAFqB"
        "MluLEUT0xGIxFEXVanVji/GhF395c+EIQqgXi4XUVSrqKhU3Xl2DIEgwFNv3u2nTzub1P2q1Wq1MJisvL8ckOTDA5ATU35EyZK+M"
        "ojkkl263e8uWLQSr19SpUwlT8Pn8aDRK6JiGeQKampqCweDcuXOfeuop+nAbeJ8cpMA8TRsrlo1/COpvMgjwEIucylgDJmeaQm6f"
        "VCqNx+OhUCgYDAaDwcOHD0NztDFjxjz11FP4LEMEQYRC4ezZs5ctWwalnLvMFI/f54uZ6aa7qpygX06GQqEwGAxbt26dMWMG9nDi"
        "xInPP/+8x+Nxu91Q6RD/k6+//hpaxKRsr02pfFMiCfbXWCwWjUYJ+wn9AcETjGHsbw2B/SdOP7/y98sHqRfOHdCrqgNaCgXoHdd2"
        "X776KEOMTff4EAThoR0IejAcAz5BuNF4AwDlRv1BHKig0eQB069NwM+W2fBxmqJarfb7/Wu2n9OZvC89PLRHhSLZrwR8ztghxWOH"
        "FD91z8AX3vnts28bm5qaampqMOaXJaja2tp0+ShzbzdyEbRfpactuRSxW1tb77//fg6HAxZaqL8VDodvuOEG/GsPP/zwJ5984vV6"
        "g8EgoaUA9NNZtGgRZatqsFmdP3++sbHxxIkTu3btev311wmFRtMacBkICf6w+GTlFOB5Nj5I6LZGZsNCoRBqirLZbAiwhLsHzVJ+"
        "+eWXcePGffDBB4SAzPHjxy9btow+M+R/aXQqt+5i9KMZcrm8vb197dq1eCZaV1dXXl4OxUkIaGC323ft2iUWi/EFbMlFNzOz8YbD"
        "YYgGJ/BXgUCQl5cHahkEXoI7FhrV7TvumnD31tXPjyZUHh83rHT56qMQsJpbxPjjOkdjfFwzSxEfRaiCDQkm9KTEgQoaZrBNN44m"
        "HIkTepVnNrAjrqio0Ov1vxw1jb590xWXlVw7tmLUpYUlanGyH+bJBa89Pry6TPb8ysMGgwHzZGUJSq/XM/co/e8NNAPiRY86UDAT"
        "EFen0y1btmzq1Kn4IB2VSnXfffe99NJLNputuLgYgxyLxWw22/Dhw8kkbN++fZ9++umePXt0Ol0uPx5FkT8be2EPi4qK2Gx2Ml0T"
        "SEmyNgg0tkTsocPhoGxYBpQIKAt2P6FZGHjym5ub58+ff/r0abwdDGJbIpFIxs2B/x8fxdDPbrd3JfrRY6ZYLN65c6fD4cAzm4kT"
        "J7733ntkJrphw4ZIJEJT1ZlGPaVUxfCo63A4klXT5PF4BAMmZLWJRCKpVNrS0vLAsp9PbpiFL0EAfkFoK5vb04frbHOGinGW5MIC"
        "EZvNoowmY7FY0WiU3KQPAphpoEWjUTAOE6giBHxRelhBUbM5g3gr97k299CbvslgEzAjP4vFKi0tValUJpPpp/36H/fpEATR5AkH"
        "9swf0DO/f13+oN4FhBawCII8cFOfvb8ZdxzQQ2ZqTkAVFhZ2Uv3RlEVsLgommu6a6N+HK/QHzhUWtrS0vP/++/fffz/+nfnz569a"
        "tcrhcGBdJ4GZJRIJckmjV155ZcmSJRiPAZnX6XS6XC7KlaSsAI4ZduDUdTodnvoIBILa2tqmpiaoWoL/FbT2raqqYlItKFnVJ9Aa"
        "N27ciLcEtre3z5071+l0YhSTYMeAUA6LxdLc3IwvlAPGNBpnJ9Zem1KlprdYXrQsFh9rTk+LGRqcWSyWy+VKiX4KhYLH4/H5fJfL"
        "5Xa7M94fsmmR0qKr0+k2bdp0++1/xZ7U19e/9957CoWCUBFi3bp1LBYL33gy3T7BNAY0wNhvXq9ns5E/2y0n2i3+e57f43Q6IbSE"
        "rJZBp3Sr1dqs99TiatyIhVzkz+ZZNCpgMowVJ89PBUn9fJsbz/YEPE73bvLGVg/lNzY1NVFGxhYVFdFDo0y/0Wq1lA251Go1kJpm"
        "gwfPREvUYg6bFYsnkoXnhMPhYDCIoiiXywVaBEHFmCMMeozHYjGFQiEQCMLhMJvNdvn8237Wfbe3DUEQlMOqH1H23PzB3Yo63PR5"
        "s3ruOKB3uVzQhxWaaecEVMaskRIHyAXYaXAgg3q0ORHj0HQbeKW1DrlcLhaLV6xYccstt+DjdyQSyUMPPfTMM89YLJbS0lK8o5FQ"
        "xsxut7/44osCgaCqqgpv+8X3js54gFX25MmTAwd2aHk4ceLE119/3W63q9VqfAaC3W6PxWLQVYPJXlHGa4CE26dPH7yGEYvFHn30"
        "Ua/X6/f7hUIh+VAg1QwhhUFBR2KsfD+QPPxGga5PVqy9Xq9UKi0tLf1fUlKzEf7o0a9bt254awpse5boRzAtEh7KZDIWi7Vu3To8"
        "Ex0xYoREIhk3bhzeBaXT6fbv3w8xlsmm8Pl80HwURVGZTAayFxNzLoZdvWuUStlfOxCLJx5fccDn8/l8PkqMjUajf2CstIOC4vaF"
        "Ma3xD4wNxwS8vz6nWC1isRBqjBVz8bmMlNf50AnzyIEdqlhcNar8zMfHMJ0eWyosflZ99fUdK97d9NhPPp8PzGnJoIG8i7/gUIGW"
        "Ehr01kUQ5Mhp67B+f+GMgM8Z0le9/5gZK0VC8B2cO3cO+TOEAuOmgC16vd5ut5PRpqSkpKysLB6PQ8yX2+3esrv1WIP9wBdT8fYA"
        "KN4bDAYZgvL7/R6PhwYUZUtX5r6DXOFAFwyy8Sbt6pTp9mxTq9Uul+vVV18l/Omuu+4qLCwEXws8gVIvkIiNDYvFEo1G5XI5njG4"
        "3W6XyzV8+HDCyxlYRTgczs8//0x4fuedd/L5fLPZ7Ha7obxDOBz2eDxms5nH482ZMyebSYEWnz17lqAv3nXXXdBG2OPxQCmlaDQK"
        "qf0+n89sNnu93mHDhhFMdgAHyAcQJkK9C7lcfskll7hcLjxGWq3WYDA4ffr0v2NYXcZsnh51adBPKpVCVQfsJrvd7uzRj35hHA5H"
        "KpX+8ssv+FZTPB5v7NixhLjcdevWQXYpJfB4PN7a2qrVam02m8vlstlsWq22ra2NpigEYT2AsQ3NHdrIcNisO6fVRSIRo9EI8Q1w"
        "UwBj/X6/xWLx+XxD+2nUqg4BBGebnQATC8uyuzrQSrmE17c2z+VyAYmHYTabA4HAtHGVHHbSQ5dIJGw2+4d9RJP7XdPrJCKuTqeD"
        "KwBfB73cEQSZM71u9KVF2H89KhShcAwSK2mgQXsWfEUISGKhgcZiscjQ7r+xdyKRaG1tJRiBY7FYW1sbh428/sTwZ++9dM70uqtG"
        "lvWqkqGsqE6nczqdNpvtku6qmyfVLri179IFQ1Ytunzjm/VFBSKz2QwbK5FICgoKampqVCpVm9Gr1XfQxaWiP+wBXq+XCSi1Wl1d"
        "XU0PKgMlj8ViAQmixAG3202mWvQ4cMHMuSn9ItkowjKZTCKRvPfee/PmzcPnaQgEgscee+yf//yn2WwuKyvD5opGo3jKXlFRkZeX"
        "Z7VaWSyWUCiMx+PQZ1gikbz88stZfjyHwxGLxdu2bQsEAvhYobKysmeffXbhwoUtLS0KhYLL5UJ5zEgk8uyzz0IbqbSII17VgOv0"
        "008/ESxyjz766JEjR3bs2AElQvh8PtTsDYfDPp8vFAoVFxe/9dZbhCl++ukn8Jvi2TO+Fh2CIE888cRNN90EpeZQFHW73Xa7vbS0"
        "9F//+hcTY+OF5Xxp2UWzF/4o0c9ms2Ho5/V6maAf/aoY5tvI5XK3271u3br77rsPezhz5syRI0fiX1u7di1wXEqLpU6nc7vd06ZN"
        "g9q5TU1Ny5cv/+abbxKJBE0wCH55UDj+pwP6yy7pIMA9cke/o2esOw8aIPefz+eDpxDK/YTD4eIC0ZtPjiBA3nHAgG3mn+zZWdwx"
        "H+bxOf1veeKnhoYGaDjv8XjsdnupRvzk3QPo91yhUBw6YTmjddZV/iVSqFXClx4eev/iPadPny4oKBAKhbFYzGKxBAKBWfXVA3t2"
        "kIR+PmIELwkTaFALngk0Docjk8l+OWpqaffizaH1I8runNrjg2/OQiVqUBWCwSAYvf55+yX4AggIgix48ZfPvm0EFJ0wvPSxO/vj"
        "//rATX0Wvn6woaFBpVJBGV6/3+9wOIoKRBXFHdDD5gwCAcwhqJS3jPK2wicnw4GmpibAAbfb7XA4UuJAxrSIeSo5uRI9mxJErppy"
        "w9BoNJFIZOnSpYTnt9xyS2VlpcPhAKcLGDRaWloIUvCHH35YVFRkNBq1Wm1LS4vD4Rg8ePC2bdt69uyZ/dry8vI8Hs+XX35JeH7P"
        "Pfe8/PLLQqHQarW2t7dbLBY+n7906dIHH3wwXZJNqPwpFApFItEnn3xCMIDweLyvvvpq+fLlJSUlTqfTZDIZDAaj0QhthubMmbNr"
        "167Kykr8TwKBwMcffwzduZE//aN79+4lLKa+vn7FihUoiup0uubmZrvdPmrUqC1btjCsF9j1DK8zLDAp36FBv+LiYrPZ3NLS0tbW"
        "xgT9mNR6ZSiAktt0T5o0Ca90njlz5uTJk2D7TWbFnTFjxvvvv19bW8tisWpra1evXj1t2jToZMBkGRAr/tm3jcFQB22Jx2V/8fK4"
        "pQuGFBcIPR6P1Wo1m80Wi8XpdPLQxJ1Te+z4YHJFSQeCGwzFPt3cIBQK+Xx+IpEAArr3N2LU0oThpf9+ZBjKSej1+paWFrvdPnJg"
        "4aa3JhIahFF6HxEEeemDo4TnMydUfbRkrFrFBzLS2toaCQfnTK977YnhhDe/2NoEmUJMoLW3tzOBBoUR1Gp1PJ545aPfCe+8+M+h"
        "Lz08NF/Bs1gsbW1tbW1tFotFLkGXLhhCqFbvC0Q272wRCARSqZTD4Wzb20YAdfeMnk/eNYDNirW3t7e0tOh0Orvdfkl31Vf/Hk+I"
        "Ct73uwlokVAozBWojM2BTHDA4XAwxIHMpHnm2fNktyZKVj0ZNlFjPqDi1Jdffjl//vwePXr8pQWj6BNPPDFv3jyz2VxeXg48YMeO"
        "HYTy7iNHjjxy5MihQ4daW1sFAkHv3r0hQw5k3ixDwsBQ/NJLL82YMYMgy8+ZM+fGG2/cv3+/1WotKCgYMmQIrBAi/ZjPS95DtVrd"
        "0tKyZMmSxYsXEzTjuXPnzp07t6mpqbGx0ePxCASC0tLS3r17k2sQIgiybNkyi8WCFX+BUrFr1qxZuHAhwU57++23T5kyZf/+/X6/"
        "v3fv3nV1deAFjEajNO6xzvYlXDwcFLvMXYx+9IPNZstkst9++02r1RLkJ7wtF/mzTxx5gO8W37jmDzH/8cfXr1/vdrsZnn5+fr5e"
        "r1+66rfn5w8mGHXvnt7z7uk9m1rdTa0ujz8i4HFKNOLeNUp8Zgg2lq8+YnGESkpK4FAEAgGKomu/P//k3QMINrrbpnSfPKbbgWNm"
        "fzDaq1oJumAoEotG4xCaRHnKIpFIoVBs3tWy/ec2QmrN1aPKJwwvPXzSqjN5RULukD4FeQoiOf75iHHXIQOUNgTClRNogCTQk/zL"
        "75pm1VcT/Kyzr+tx+5TuxxrsWr07Hk+UFUkG1OXj/Y4wXv34uNsXhiAShUJxvNG2+3D76I6twv95+yXzZvX89aTVbA8IeJwelQp8"
        "5zJsrFp3hsVigeyVK1AZM9Fc4cCFch6xU1qZcqKPQgjGc889R3g+Y8aMuro6UEYhEPydd94h+6g5HM7QoUNnzZo1ZcoULMd87dq1"
        "DQ0N2dOpwsJCq9W6YMECygO+4oorZs2aNXbsWIzcvPDCC0zmJcgi+P9VKpUymeydd9759NNPKX9bU1Nz1VVXwfcOHDiQkoN+9dVX"
        "//nPf6A0P3bMQOw+/PBD8vtKpfKqq66aPn06cFAEQVatWqXVai9CfnZBZswh+uXQkAMqEUEZxY+vv/4a8mGSWacRBCGUZUAQBFwS"
        "THrLY8uQSCTvfn368y2N1BhbLps4smzmhKrJY7oN7JlPyUHXbD+38qtTIFJjGKtUKvVm30cbzlJgrIw/cWTZtHGVmDX1/bVnmjs6"
        "5LANj/85SkpKOBzO/Yv3kgvPohz2ZZeop4+vumpkGZnnWR3B+17Yw2azS0pKMIpZXl6OomiW0PB+IhaLffei/yN/BZvN6l+XN/XK"
        "yunjq4b0UZM56M6Dhrc+PyEQCOC+FxQUsFisR/69z+0lZu+IhdzLBxXBWVCyvXfXnNr/u0mlUoGsAOGTOQGVGXPKz8/PHgeypAwM"
        "g/wpVVI2w/nwI933wW6jUCi2bdu2b98+wmqefvrpRCIB0ROFhYWtra0PPfRQylnOnTv3xBNP0JgNmSs9SqVSqVRu3LjxX//6V8p5"
        "t23btnLlSubnlAxgeXm5UChcsGDBsmXLmNMyGLFYbPny5fPnzxcKhYTCv2q1msvlLlq06NSpU/RADh8+DJkb9Mf3P8BHmYtTGo0m"
        "e/RjeCcZttIEwx1UliePgwcPtra2UjbQgOODWLOmpibCD+EJE8KHYUJRURGfL3jopX3LVx+NxuLpYWw88dIHR/+x7BeBQEgoYAkF"
        "Rp5fefjUeUcKjD1lWfb+kWSLBA4Kn9ytWze3L3LtA9sOHDMzXKHe7Jv64HaDxV9eXo6PYeTxeJWVlVlCwyiSUCisrKy0OoKT7v/u"
        "15MW5hu4dU/r7f/aibDYFRUV0OyBz+eXlJRodZ7rH/kRvJIMx6p1p595+1cej4cdBI/HyxWozAZQrSxxIDNalFaaXLKH7C4jUmq1"
        "msPhkJXRq6666tJLL3U6ncFgUK1WK5XKNWvW3HbbbRZLUiTbs2fPNddc43A4crW20tJSmUz27rvvXn/99TQJ9V9++eXs2bPpe10x"
        "JKwoilZVVUkkkhUrVowePXrjxo1MWGk8Hv/2228vv/zyV155RSwWV1VVEcq6cjicioqKQCAwZcoUQsto/Ni0adPUqVOzLF54UfHI"
        "nMxbUFCgUCi6Hv3oZV6ZTHb27FlKqYjelgs8GEEQcgwUBCikNMERMLa8vFwkEr/68fGxszdv2tnMhJXG44ktu1vHzt78yn+PCwTC"
        "srIyAsaCrhYIxa77x/YdB/XJ4Gze1TLjoR9C4RjN1cBYqUQiqaiocHoi1/1j23P/Oez0hOkZ/CebG8bO3nxG6ywtLSVHXMvl8urq"
        "6pxAY7FYKpWqpqbGbA9Ovv+7Z946ZHOlYFptRu/8JXvv+NfOaIxVU1ODN0rl5eVpNJpfT1ouv2PT+h+18XiKK3DqnOOGR39c+NpB"
        "aIaK9/jkEFRm8mu3bt2yx4EutuL+dTUyI1gZFFvn8/kqlergwYObN2+ePHky/k9PP/30ddddZ7fbhUIhePi2bNmya9euWbNm1dfX"
        "9+3bF1pPm83mQ4cOffXVV9u3b09JNNNyv7HZ7IqKCoPBsHPnziFDhkydOnXy5Mn9+vVTq9XxeNxoNB46dOiDDz7Yv39/Bl69ZNvF"
        "5XKrq6tNJtP58+fnzJmTl5c3bty4YcOG9erVq7S0FPL6I5GI2+02GAynT58+cODAtm3bTCYTiqIajUaj0VCClUqlVVVVWq125syZ"
        "9fX1N9544+DBg9VqdSwW0+v1+/fv//zzz8nBR/9vYBYCFouVPfplxvWTdfF0OBzr1q0jVE6OxWIbNmzg8XhYTAc5rAES89euXZtI"
        "JB577LGamprGxsZly5Zt3rxZLpfT1wwhrxD4qM1mO6ez371oj0rOv3Jo8fB+mp5VylKNWC7l87jsSDTu9oXbzf7TWufBY+btv+hM"
        "tgCHw8nPz4cW9+SJJBJJaWmpXq+/4ZEfJwwvu+Gq6kG9C9QqYSyeMJh9+4+Zv9jaBGGuTLYU4iclEkltbW1ra+tbX5z44Jszky7v"
        "duXQkr61qhKNWCRAw5G4zRk8o3X+fMS49vvzerMPhFqFQkHZjVgul/fs2VOr1TKHVlNTk0y4USgUvXr10mq1K7869cE3ZyeOLLvy"
        "spJ+dXmlarFUzIvG4m5fuNXgPXLG+v0vuv87ZIjGEnK5vKysjGA5APOAQCDQ6/Xzntu9+N3fpoztNrx/Yfduck2eUMBHw9GYwxXS"
        "6j2/nbJ+t7f14HFzIoEoFIrS0lIy2yssLOTz+QaDIXtQCIIEgh1UAqg5TEM8JRJJZWVlc3NzljiAZNEIJHNG279//2Tz0VAKs9ls"
        "NBopCzJVVlaSK8tjHpqzZ88mU7k0Gk1h4R/+do/HYzAYkiXwKhQKsVgMaV7kUVxcrNFo3G63VqulXGFRUVGyAmler9doNPr9foKO"
        "D5U5lUqlRCJpaWlJBjaz7PtIJAI5fJAYhyQpIgM2HIVCgXULp8lBCoVCer0eSlKQlwofAlVYyQP7EJPJZDKZKDXv4uLivLw8TKsI"
        "BAIGgwHCWAgDWiZhNSKi0ajNZqMsfAgGVY1GQzNvUVGRSqXCz9ve3g5dTcjzqtVqLGwV5qUsXwfz4lEC0C9ZRWKFQiESiSAvkDwK"
        "CwsBFNwRyncqKirIdyTZacbj8ZMnT44cOXLTpk34F3bs2DFjxgy1Wk1T7Q/5s+EzYYvkcnlJSQm+kDqTfDaMJsRiMYfDgaXx0QgE"
        "PB5PLpcrFIqUnXBCoZDJZKI8SgiXFQqFyeplqtVqrFwO4UNcLhc0hU02L5fLzcvLKygowK8wWeim3W43m800Uc08Hq+goACsbuSf"
        "EzYKOu55vV4a4V4mkxUWFuJ93uQef7FYzGw22+12mh69YNJQq9UikYimRQ+k69jtdkibTgmKzCySoT09a8BwwGAw0FAtsVhM6F5O"
        "plr0vEkmk6Vb6iDlC9RMNGVxong8brVaCTWuoCQVfeKE3++32Wxk+sjj8QoLCwml8kKhEFbuAARhoVAok8lAIrNardBYkUA6CwoK"
        "/qhUabOR76RIJMrPz6dvvhEKhaDiQSwWY7FYXC4XimtDLwiYl/AToVCIzZuxRhKNRiElNBKJQKNpYN5Qak4sFkOYH+UdoDypcDgM"
        "vBlacKAoCkVN/6gLarMl20Cs7BacMvkdrPI4Xv5wOp2Ea4yiqFQqBU6GLTUSidjtdkAefCqtWCzOy8uD7Nhk82KRk/h5XS4X4c7D"
        "vFKpFB8CEIlEHA4HuTAbzEtGiXA4TEY/6EVMs3sYdsXjcUgfJJsKVCpVyruKQbbb7Xq9funSpffccw/+hfvuu+/LL7/s3r07kwhh"
        "aKBGrlhEaNjCREvG/zUSiQSDQQjzxhq+stlsLpcLKnJa8SYQ8OzxeEKhEFw9FEUFAoFEIoGb5XA4yCxHKBTC8SWTBqCGPjRXx64V"
        "h8OBO4Uvt0Qu1YmQokiALnm93kAgEIlEoBwBh8OBdZI3NuUlhU/GoMFXQ7AY9uE0HBT/D5/P5/f7sc8E/w6fz4eiocmaz1DyCSh4"
        "BAeBgYIzxUBRfh1cXkq0Z5hTB/cuEAhgOICnWpTkl5JqkXkTZl1Pt3MA/V+TaqIXxMpM38Uwh9Ol26WZIb1Dsiijk3KdlFeRYaug"
        "ZC9k02mIRndJazqyuTuDApOdh0s0cDLe9pQoajabw+GwUChks9nt7e0ikej333/HV3wMBAI9evSIxWI1NTVZ2pYZaqL0qJKTI0tL"
        "Labh/UwaIScrqsyEj9L8OyeUih516cNKk0WGkzluugvL4OgvwtKh6VI8Jpoo2mWrxztsMuA0GZ8H5W8ZtjGifIf+h8wbXzO/Kvgy"
        "GZmR6bTWwLxnVsbTkZtWdjbupZTe0j0yhi8kA0sDymq14g1iPB7v9ddfJ9RM3rRpk9frhdJUadEFMtdJFnyYVg5ArgLKUkZC5oQE"
        "IR0dqEzeoWxUnpKgUVIehuwwsx0jN0lN9qXMT5ChTHzxsEwaUpbzyMdEIoEm24JkbrnMOqli8lEGfJTw207io9mI0uTfJsPjzDgo"
        "kmbzwnTRmlIY77w4W7Jcn9lc6X4mPapnXwsiLUmcfKDYtjscDrlcvnPnztOnT/t8vssuu4yQyBSPx9966y1w0qeFz5QEl4YmXrT5"
        "SGlhF6UexhzJKduO0iQpMVeOc7LDNHwaT3bwTcgpjUY0zzNT0XJr92IIkB7DO2mFaLpSScpl4W0g9NLNBddHO+MC0xtS/vdao2SG"
        "JJ1BTbJHhiwRLCcLg3Z7V199dUVFRUVFBeVrq1atOnnypFqtTubaz0af+5vyznQ/ilLMzUBaJWsFzBXTzFIMKK04KWs1pzx9hp+Q"
        "scpx8ZM+hpyLgomS1X8aqRZJv4sLwSTC/P2/EQOgN6dkMEu6xrSUC0v3o3IiIDPP4sjYkJUZ28u5Vz4n6wcgEOFM6LmNH3v37l20"
        "aBGfzycH5VLuOc0uZYlUyEVWOgP/+WnRNPpdot+6ZHyU3sjEvFIrwxdSph3i5yWwYcKSKOu/Up54F5MUJsJBMtmok8j4X5poBqiT"
        "GR/NocCS0nRGYyNliJ0pHelZfgK+szSS3KaaPaVLi/ylvP/Z8NHsYebKpsQcx1IK3Wm5kOmxNJFIuN1uLpc7fvx4SiCfffbZo48+"
        "GovFKisrmV/bnGx7utptBhQ2g5tFg2A0AWsMgadknwRqS747zFUImqYFTO5Ryj2kid1LZtUnCCVMaGP2d5n+S5PZ+fCfk3E0X8aE"
        "oisCi7rGQIRH05wossnk+i62MV48h5LlTy4Ge05Kq1cn6aApTfrYC9A9d9u2bQMGDCgpKREKhYFAQKvV7tu379NPPz127BiXy62s"
        "rMSXprtQe5jSrdN5EWoXajDUw2jMeAxZNZm5Mt/MtGQFeg6KhTR2TZxESopxcfoaOiXFhaHkm4HSyTCcmrmkRi++5YqJ0sySknB3"
        "HtLQ5wjmVslg/oHZBxyldXbM/VKZaaLpytcOhyNZ4UkOh6NSqWhcoVna1ii/lIC66Z5OzqNIMtj8zqZjCIMqOWmloqbUTXNoSEuJ"
        "1eScGZpsmYyZHMOgcSb3mnnoa64G2hmsnrwLKQWZdPWwXNnxmEhtnRFBx1zvSbYG5rHymW0szYxphRVQxgp2jXKfGUHMEjITZzbN"
        "1EqlUiqVejyecDgMFQw4HA6XyxWJRBKJhCGvoncUIckTdsl/zSAhMpkykS7N7VRbfUqDU/aGwWQBsWQ6iX+HPronJbdOuWwmUiM9"
        "wlAuNYc0M12rO3PCmK6RiWEFQTQb00GuTIi5yjHoPPrbGdlF2awhrUju3G4s5XVK68O7/pSZz5gTEpDlz7lcrkqlYp5/RekoIvwk"
        "g2xpepTLwPxIk2pJY3PqAsE62cKyUXPx257MCEz2PiaTP1LGzeZW506m/xDYJ2VI80Uba4ak76ZhuNsocjGNzErbdwGlzjgQ9CJR"
        "qv7/k11Dvj/pctAuFo8uwtF5uWT0h5LZkWUcz8/QQd55FIOJJIpXZ2nsCp2n+ZH5fZZI0sUXJOcqEPmr/z9cU6m9Xz6DcgAAAABJ"
        "RU5ErkJggg=="
    ),
    "RaidFailed.png": (
        "iVBORw0KGgoAAAANSUhEUgAAAQoAAAAoCAIAAACJuiMXAAAbcUlEQVR42sU9aXQUVbq3u6u70+l9SWcBkiZRTEQMHjcOw2N4LuPz"
        "IWpwZQkTCSOCPmGQjB4jRpDjAg4DA4zGCXrCw4gwhoNGjowyLiAKCh7hkQwBkk7TSeh0eku6O73U8n7coSxquXW7k5mpHznVlbvV"
        "d7/9++5XisrKSsC5FAoFGKMLDsUwjHBkhmHgT6k27BOpJbEjcJ8IG3PHQVzcvrzFoEfgrVOqsej4OMOiXyejBWMuFd1Rao94s7Ob"
        "C3+yD3k4gEA8qVlEcUzqX6KvnBGGE2NLG8IR4LKkXl4W6RGUIAo42V1HNOD9CweBeECXQjv4HB8jMdeAv2Dhv/AphNcSH19FuR4+"
        "JmSBbLKvnCn8iSw6i7bkkQGC/YuSUEacWJa1SM2eBYLKzoVgezyGioAJJodG4zeaO2YKZFmUyBRhWKbGVRyELEaK63GnE4U5D+AZ"
        "LVVqDYRKpWJbcOGFlqE4OCS7VlFZgdY0hPeiyIfDdDFVHeGwmGghSg/oV0YrS7L8nodAovDBWYYoSGV3XFR5FiUDfEHBWy0a99Dq"
        "k+jsXCiJQu8K8hDdG0zej0MeWStvonuA4M1oDiTkoAgJI7p+NOpIqYgZYTZvLkydBB+YOIQ6VnIjO70ODQEpMYKvIMi+I8MwBEJm"
        "iaKjrGDCGQHzNURNOhykFDVOcLQ1YV/hDUK0ouflvogUu0JIHkz7lWUBokKSx0RERajUdPgKGILZi8KHp7ngKORSa8A0a6WcH7xJ"
        "CUzKw0dQTB199PSNz4AzmoXbl2EYpVLJQ3pZIhxzEzxTDwFa0o6VJyYLhMHUjrKA3hh6XK8wzdHGNM8tI6t+CFm41M+soS/UqjGx"
        "TdSyQnAglqth+gB4BMP+i6Zp2eVlhBZCkIpqX0L4Z201IVie6C7g6FRoks4U4xEQQKC0rKFFiHI7fN1d+IaymMR6OWma7u3tjUaj"
        "ZrO5sLAQoWxk7fKT5ZejcQTj8Egof2Q1PVG6QtzjU1qm/Bg9oBRLQttvPKbm8/ni8bjRaHQ4HMKNFsVjWUUOYhSmDSn7kx2HoGka"
        "x3UAAPD5fIFAgEchSqVSrVbr9Xq73a5WqxEMg2dIMAzj9XqffPLJ2traDRs2tLa25ufnI5hBf39/IBCA9wUFBQ6HA2FiptPpUCg0"
        "PDycSqUYhoErtNlsWq0W4TPNImwka31JeTiktoe5fOFzbhxPd0auOeG7DA4ORiIRxCBKpXLChAkEQchy94GBgSW5ufNdrm29vR8H"
        "g3a7fXBwMBwOw2Z2u91ms2FaiaL+8bHVsgiKojDDKIFAwOv18tpQFDUwMPDdd9/9+c9/vnjxIkRxnjEqJeOGh4eXLFmi0Whqamqa"
        "m5tZjBcadgzDDA4Owtn9fv8tt9xitVqlLLlLly7Z7fYVK1bMmDFj/PjxKpXK5/MdO3Zs586dHR0dxcXFPNOTNZmyjpBkxLB5AUTR"
        "mICUVwARD+VxUBwLEO1z5y4mEon8dP31iJfa2tv70ciI0WjkoalwMbFYbIHLpVEo5uXnf9Ddbbfbw+EwHHwwnb7r3Dmr1YrwMot6"
        "vRH7OMpLyUhcXE6GMDdVKlVhYWFVVdWBAwceeuihS5cu8UaA0kn00uv177zzTjKZbG5u1uv1vP/SnEs4Oy1xud3u+fPnHzp0aNGi"
        "RaWlpRqNRqVSFRUVVVVV7du3b82aNV1dXWxjiqIoioI37E/2IW8BUqDgPcxUW+PJCvbi/YSXUnCpVCqVSsV7CFsKu4+hMyBrL0tu"
        "bu77Pl+Spnf7fLm5uVe0ycpPw2N2Y5v5QeCYVryf4XD44YcfhvcWi2XWrFmPP/44QRAvvvjiDz/8EAqFhFqWKIoUFBRs2bLllVde"
        "MRqNBQUFsg5HKYxkW0aj0TvvvPO5556DMuSPf/zj6dOnNRrNjBkzli9frtVqFyxYcOHChf3795vNZrQmKQV0fE9ARvoMfgRASi0U"
        "AkTooZYKtKN9Fdx/RUjyN2fPClc4QJL6CRO4C5ayGfLz89/2+Ta3txsMhry8vKyV2DEMBCHGIRCJg1JXOp3u7OycOHEiNAm2bt3q"
        "8Xhee+01AMDixYtfeOEFp9MJW6ZSqVAoFIvFSJJUqVQajcZoNFosFlajHR4ehrJbo9HY7XZ2imQyGQwG4/E4SZJqtdpisYg6y3l7"
        "HAwGn3rqKShb7rvvPpIkoVDasWPHqVOn3n33XbjCxsZGn88HuzgcDqvVyqrFoVAIjgyf+/1+Vi222WwAgOHhYZIktVqt3W43GAwk"
        "SQYCAfiCWq3WZrOZTCY4wsDAQDAYZGcBAAwNDcFmDofDaDSSJDk4OBiNRtm+QqJNpVLBYBC2YQEIF8wwzMDAALTHFAqF1WqlaToa"
        "jUIOHYvFoNqsVCqLi4u1Wi2E0vDwcH9/P7zXaDTjx4/3+/2xWMxoNHLhL0W3JMNcUCiKi4t5z20cLTqdTkciEbh3SqVSo9EYDAaT"
        "yQRd5IFAAC5yaGhIrVbzVCkWMXjWCLznbkdeXh7coFAoBCFgNpsZhonFYgxFGUwmqOdTFAUxMJ1OK5XK3Nxcm82m0WhwApEAAOVo"
        "6EyhUKjV6sLCwn379sGHlZWViUQC3vf19VkslldeeeXbb7/t6enp6OjYu3fv3LlzvV7vyMgIACAUCnm9Xq/X++OPP7KvDaGQm5u7"
        "cePGH3/80e12f/HFFw888EA6nZbV5lOp1KRJkwAAIyMj/f39ZrOZIAi1Wu10Or/66qsVK1asWLFiw4YNqVRKdN5gMOj1ent7e+Fz"
        "hmHYFZ48eTIQCDz55JPHjx93u91tbW1Tpkzp6uoaHh5eu3btyZMn3W73J598csstt3g8HqinwdFgX7/fv2zZsmPHjnV3d3/88ceT"
        "J08+f/58JBJpaGg4ceJEd3d3W1vbzTff3NPTw+X9vb29RqNx/fr1R48edbvd7e3te/bsqaqq8ng8EIDQGvR6vSdOnEgmk+vWrTtz"
        "5ozb7Q6FQjNnzoT/eueddwKBAFTDlEql3+8/cuRIb29vb29vQUGB3+9/+umnz50798gjj4RCIVF9TNRE4ep7XKzy+Xzm/v7njcYD"
        "V111csqUbyoqmoqKZlNU34ULEDGgpfHT9dcfqqgQNfcVCgW3zdDQEAsT7nO4caFQCD75vLw8NTj4rMFwuLz85JQpkGYikUiiq2tF"
        "Tk5baekPkycfmjSpwWzWeb0DAwOYyhuBE22QNXeSySS80Wg0sHtfX19NTQ3Uc+Cl0+kqKysrKyurq6vnzJmj1WpFl+j3+2fNmrVl"
        "yxZ2xpKSkvr6eiHHEgpupVIZCAScTqder1+1atXmzZuNRqPBYNDpdMXFxcePH2cXmZFSC69t27ZVVVXB+/Ly8qampieeeGLt2rWs"
        "w+2aa67Ztm3bb3/72y+//BJysiz6Hj58GErX3t7eX//611IAvPfee7lvoVKpmpubp02bxsLh8OHDwWDQZrPNnDmTJEn4LhRFlZSU"
        "uFwuAMCJEyf8fn8qlYLekccee6y5uRmKfa6qJhuq4/730qVLj2g0T5eW/rxmpfI6vf46vf7hvLyFnZ2Ey8W1NGTzIRQSGKgQTK1S"
        "KLZdffWNl30DCoUiEomURSJbrrtOc7mjhSDusFpvt1rXut1fDQ5CkS7qe2TvlTx+kEW0IRqN3njjjfDe7XZrNJp0Ol1WVga3NhqN"
        "vvTSS3PmzJk3b94333wDACguLv7d737HKh5XyG6SNBqNmzZtgqt89913q6qqHnzwwT179lRXV8t6YEwm065du+D9ypUrjx8//uyz"
        "z1ZWVkJGTtO0TqfT6XRZ6KlOp/OGG26oqal58MEHjxw5Ah++9dZb0Wi0pqamqqrq008/hQ9XrVoFWVd2fQOBAEVRIyMjpaWlCADW"
        "1dUNDg6yU9jt9smTJzc0NMyePXvevHlardZisezduxfyglmzZsXjcchN77nnHtilpaXF4XAYDIampqZEIvH2228bjUaexc9e3NeJ"
        "x+MXrry6u7tJkkylUiWJxNPjxwMAYhS10eNZ2NGx9OzZ40NDAIBxWu1TBQVcWZ2d/S310EoQ1+TmbvB45re3Lz17Vq1WUwMDm666"
        "SqNQpBhm08WL89vb67u7QySpAGBNSYkpEmF9tgibnpASGujs4qGhoc7OTqjm3nrrra+//jr81969e81mcyqVikQiq1evnjBhwt/+"
        "9reenh6r1RoKhZYsWdLR0QEAmD59eiwWE44cCoVWr14N3efbt2/fvHlzUVERAOC5556jafrRRx/lWX48GeJwOLZu3Zqfn79gwQKI"
        "lwsXLly4cCEA4NSpU42NjQcPHhw3bhymT5337osWLUomkyqVqra29syZM3CRS5cuhTr0448/fvr0abPZPGHChJycHN7gixYtSiQS"
        "BEEI+xIEwe2r1Wopikomk1wAut1ui8USCAQQAKytrT137pzFYonH46WlpTRNv//++0uXLgUAzJkz5+jRozqdLhwOQ/JIpVJtbW3F"
        "xcUGg2Hbtm2vvfaa2WxmvSOIYIJdre646SZRr65KpRqiqJfc7iKN5kgk4jWZzBMmDFHUqq6uI1OnAgBuNpniYjwxC4tZ9OHK8+e7"
        "jUaLyzVC0+ZIZJFKpVMqAQD1XV3HCMJRUnJ8ePh/zp3bVVGhUigWOp1/CoVgXBIRRSEQGSVSy3I6naK8/7PPPvv444+hyU6S5JEj"
        "RwKBwMjIiEajCYfDFotl5syZsKXBYGBplztXLBZj27z99ttsjKKkpKSxsZElDy5J81brcrnWr1+/a9euxYsX33HHHazld/3112/f"
        "vv3QoUNPPPEE5gZwn4RCIbfbXVZWBjXJcDgMRXNnZ2dZWRmMPHq9Xmhb8xx3oVCou7sb9k0kEmzfs2fPlpaWwvbcvgqFwmAwpNPp"
        "L7/8MhQKJRIJtVodDoetVisXgCRJsrs2PDz83XfflZWVcSMAHo+no6OjoqLizjvvXLlyJU3TDoejoqICAHDgwAFIogqFguUXmFmx"
        "UmFBo9FI6nTHEolgMJhIp9VDQ+Fg0AzAtMsKj16pFG561rTBQ9ooRZ0kyTKbDS4mFov9R3Ex9CVcTCYLEgkQjVoBSAGQoOkcpXKa"
        "ybTR7ebqV6ImBoHpQ5SF0bp165qbm1kLIRqNptPpxx577Be/+MWkSZPy8/NhboWsTwyKi0gkEg6HoeNPoVCoVKrz58/LpvFA0BQV"
        "FcVisZdffrmurs7lcs2YMeOee+6Bevntt9++YsWK9evX4/seWK2Pu352Uq6AltI/odNJ2IybiyXsG4/HaZqura2VAiC3SyKRUCgU"
        "cEBWVbBare+///66det0Ot2MGTNOnjzJuuNbWlrsdjv+SZKfHbsU9Zu//13o1bWUliqVypGRkeSlS/Os1lsLCkpzcvI0GuXYEQP6"
        "StI0Fz7pdLpYq4We2d3XXitsX6DRkCQpHzXPQudj4x4qlaqxsRGSRCgUslqtkCdFo9Hi4uL33ntPp9MBADwez1//+teurq7Tp0+/"
        "+eabmcIIMzJAUZTf74coQhCE0+l0Op00TX/66ae7d+/+5S9/uWPHDgDAI488snbt2jEU8bKSB58IuaHliRMnZgpAXtxDr9e3trY2"
        "NDSoVKrZs2e3tbXNmTMHOga///77iRMnsvSJeWQAAEDSdLdKBSUh27dIoWAYJhqNFgYCb06enKNUAgB6U6kvQ6GeZLI9Ftt4ub1Q"
        "e8HM90Pkp2a3lerL3ERUcv58WjCLOWDco6ysLBwOr1mzprm5GQBQX18/ffp0i8UCvU/Nzc1waxcsWPDNN9/o9fqcnJyLFy+iyUOt"
        "Vvf19ZWUlJhMJsje4NpIkrz66qvRq4rH49OmTZs/fz4AYNeuXWfOnIG2ptlsNpvNn332WSQSMZvNrBMdTseFkagz7d9yBQIBljYW"
        "LFhw5MgRnU6n1Wr7+/tx+Au7u8lk8tChQ7/61a/uuuuuiRMn3nDDDQCAPXv2QOVWGPrEOTghxQ78fv/mkhJIG8s6O3+gab1er9Vq"
        "PYHAxivJCc0auG3USuUVG4Sd6axWq/uSyeKcHJJhpv7wg+ryztI0Db2sKpWKm+MnqTTKHnlBMG+j0Xj48OHDhw9Ds3j58uXQo5xK"
        "pSCDiUajX3/9tcvlysvLS6fTd999N3o1BoPh66+/hvfLly/3eDwkSZIk6fF4li1bhl6nWq2mKOq222677bbbVq1aNTAwAMNwqVRq"
        "cHCwvLwcKvcXLlxQKpXQdrJYLKWlpTCC5vP57rvvvn9BVgUOhLkA/Oqrr8aPH2+z2UiSlAUgD2OsVmtLSwt80w0bNsCHu3fvNplM"
        "MDhDkmRfX9/58+cvXboEQc1LtME5vgLbpFIpV04OACBG08eSSZfL5XA4SJK8nQ38iYW6eW6xf/BsggiRJADApFKVXFbUfT7ff5lM"
        "mNDW6/VHh4agcvVgXp7ZbC4rK3O5XFqt9vGiopqCgulGo5BBiJCH1Cbx8oikYDRu3Lj6+nqogi9btowgiHQ6TRAETB80GAybNm2C"
        "8eDq6uq33noLDWWLxdLU1ARHW7JkyYsvvmi1Wh0OxxtvvDF37lw0Kmi1WhjwAgBcd911n3zyyfTp03Nzc/Py8hYuXNja2gqbNTU1"
        "GY1Glgh37tw5depUo9G4ePHiV199dWxRH0dnEO0LjXUIwD/84Q/5+fl5eXk1NTVoAAq3T6vVQvse2l0AgJ9++snr9bJq+sDAwMqV"
        "K8+fPz9v3rxAICCafkZRFE9t46Wi/cywUylogr9UWGhwu3Pd7rkM8wZHdPBeHtqKPAioVCq9Xv/t5YjhtquvnhyJ5Ho88wjihZIS"
        "zNe3WCw7BwbSDAMAWFNSskCt1ns8ef3965zO1RMmPF9S8p8Wi2zqEz9qnkWamkajCQQCMF9Dq9XW19fDhNnf//73sMFDDz3U2tq6"
        "f//+uro6qP2jLCGCCIVC9fX18Gd1dfW+ffv+8pe/zJ079/nnn5dFOIfDMX/+/L6+PgDAtddeu3nz5gMHDrS2ttbV1RkMBkgbra2t"
        "hYWFr7/+OkxtKC4ubmxsbGtre+aZZ7Zu3Zodlo+5nLFYLNkBULjI3NzcDz/8kP3Z0tICw44Qs0dGRmpra7VabU1NTSwWEyaDQmrh"
        "jc/SDDdZ02azvdXbCxvc63C8W16+s6LiyXHj3rucvyP6plf4Gy6H4R0Ox7b+/hhNAwDGaTRvlJW9d+21y8aNa+rvxwQgQRBJm+25"
        "CxcohlEpFEuLiv63oqLpmmv+224HAPxfLPYnv5+rZksuDzMsiEgrcDqdGzduhCzqgQceKCkpyc3N/fzzz6urq48ePQpVl87Ozrq6"
        "uoaGBtlNdTqdbW1t999//xdffBGNRimKOnv27FNPPcVlnLycYm5cOZlMzpo164UXXjh69GgoFKJpOpVK9fT0fPDBB7Nnz964cSM8"
        "lpBKpe6+++6DBw9Cwd3e3v7MM8/wpIeoRBWFQ9an/6TEsslkOnjwYKYAFPXRm83mDz74gNXZ9u/fDzkFXLlOp9uxY0cikWhqatLr"
        "9TxhyFLLz4Nflh5cHQxeRqPxa6VyeWfn98PDcZqmGObCyMhat3uDx8M1f3mDi5610mq1iqKiR9vbvwiHYxRFMkxnPN7Q3b3l8nkK"
        "IcgYAVTtdvuPOt39Z87sHxz0pVI0AAmaPh2LvdrTU9vdne9yybpSGYZRQHMNkanxs/9uYICNB+fl5bEZbNBr0dfXB/uqVCqXy6VW"
        "q2OxWDAYTCQSNE1rtVoYLuSOQJIk96fNZmPnTSQSMGZCURRM1xsZGeE1Rhz4HBoaGh4eTiaTUL+Ex6HMZjOUp7BlKpWCU9A0rdFo"
        "rFZrIpGAeUfgciYcN+ONzY0LBoNsxNpqtULv89DQkM/ngyPDBGQ2fw72hRGYUCjE9rVYLGyqIpsFBPvCcUZGRsLhMASgRqMxmUww"
        "3gpb2mw2iqK4P+EUXKczNL1uuummpqYmAMBHH320evVq3rEzNiURnrcRPVkVDAYjkQj8r81mY5NKufFm+BduUyKRYBgGQjWZTLIw"
        "zMvLoyiKTaPMy8tzOBzwmB184nQ6IV4pFIpkMgnXxg6VSCTYgBtMSWRxkrtBXJSAOBaPx9PpNCQ8k8kkmq8tLgamTp0KpI/eYhZ0"
        "wakcJVp3R/QwHTqhXba+RqYnLnDeAn1YSvRgtyxfF44vPAAoVegNcY6fZckXL16cPXs2wzANDQ2QJKqqqvr6+qTyVTHlEst00UUQ"
        "uYKCNTCEpwNwiqHxOgoPIwHBaWSpygGYeSH8uAfaysQ8YYxwUcu6CISVnWRpMuvCFjjV7vCNb8wQDc746MOAALvEjkKhSKfTU6ZM"
        "2b59O/vwww8/PHXqFIy6jsYDwT0JiD7Kz5Vj3DNePP1c1OGLdiILC8MhPEmjKVpAZMQ8RNeEphAcrw5bnCHTCIwQuXG4OMiw0g8+"
        "2QjP08sy49EcE0d0jMfj5eXl0Wg0Nze3p6enpaVlx44dRUVF+IU6EZSPLlsIxGodCYMqvHORQKLKI2KFQkuGfTv2hCm6uBRCuxFR"
        "rhBleLIIVeJXNpDCVFEEkq1aCeRKvsvOO3rMRhzrw5RsskVhEBWNGYaBOQTQblGr1azCLVpOEieBSLaAL1rBFm6WKKKzf1kVDrN+"
        "jZQQFh6ZzKgOGyGrT495IGyseOQ/r/hX1m8nVVQmI6iKylLemVjZEWANAJydxVfYMhKhiAailI8QIwgPIUIf45Xz40kS0foswnck"
        "EMJFqsweJrOXUk8RRZBESw4LK3sLcQW/chnmvqLrn+OUdsVxCsuadghvhOgry2YZol0vODUBZW1I0Y6iWCFau1X4Ilx5IkVFstas"
        "EKRSp/O5XYiMivjiF4kBY1G1QLbee0ZfMhi9Qp91zWZ8V0EWemAWlkx2haQyKoGOrsQnZW2K4jF71JFHG6JeMnyGKPSDCQmVyMhs"
        "xfkgU3akhUNmaO6F9oRmrZWhP9Q0ylrl+GTJMz1lv4qE+fWsjLzPWShgiKInmFY+V1nlrY1LJ8LkFNmlihoqcCKapv9RoR1dSRZH"
        "F5LlZwh/JWIodGl0HI9npud7pPApI0mSqXhEIIeoeoDpLxkTq4xn/eN/qUyWGMDoCk5zR+MiNMIVJssI4DiwnApLDgQ+MWCCI9N3"
        "Hr0P4F9ghWf0jcJ/4zXmC+CZs6OnuqwHQRc+F/qLRQ+Tyoo+ntFLIHR6KcsGXbB9lNQiq7zi+B+z46D4tjjaMYqvtGCWbcZXIxEV"
        "wbMov41TcRzhPEAYiohAB6IyHXrTef5invYFBIFInG0ixlBXzqI2eKYmtdTHEv55zBvtpsOcGp2ikoUoQCetSCHrKD+ziF4/+qsS"
        "WX99Bce2QSOksCIrvjubyA46CKgJTUNRlobgDbwvGyHchfg6T6ZuNMwvB2RtgWTnWcKnTCmCzOjbYvhfUJFyvvEkBq9WNI5PEtPo"
        "R7SRUr2AXAADAPD/xcsmP25PCU4AAAAASUVORK5CYII="
    ),
    "ChaseTookTooLong.png": (
        "iVBORw0KGgoAAAANSUhEUgAAAsoAAABQCAIAAACPlsQbAAAfkElEQVR42u2deVhTx/r4kwABRBZRAWVHRAi4gUXFpaK4lGoRL9QF"
        "N6xFXFqtcsVr7SPVa7VXq+JVtNQqdbve607rAoqIUBQRURCogShLEAgo+xJIwvePPA8/fnJmcnJyssH7+TPnzLxn5n3PmTcz77zD"
        "YAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACA6mHSWJeJiQmHw3F0dLSwsDAyMtLV1RUK"
        "hbW1tW/fvuVyuUVFRRKJBHocAAAAAABZ7gmTOWnSpJ9++ik3N1cikXSiaWxsTEhI+Prrr4cOHUpZHKryO3fugC4AAN4jAAwD0HrY"
        "bHZYWNhff/3VKSdisfjGjRsTJ04E6wcAGEUAMAwA+H/Mnz//9evXnYpx9epVe3t7sH4AgFEEAMMAehm68hYwMTE5ceLE4sWLFZcd"
        "GBjo5+e3bt26c+fOgSYACkRFRRH+XlRUBEYFWgYAQGtwcnJ69epVJ93s2bOHySQVZArONQD20Nf6DbQMXQ1oIyzyt7q4uKSlpbm4"
        "uND+ENu3bz9y5AgoAwAAAAD6lnthY2Nz//79IUOGKOk5NmzYEBkZCfoAAAAAgF4AqdgLfX3969evW1tby7xTKBRmZ2fn5+cLBIKO"
        "jg5jY2NbW9sxY8YMGzZMZtkffvjh8ePHKSkpoBUAAAAA6P3uxb59+7y8vPD3ZGRkREdHx8fHNzc397zq4OCwYsWKr776auDAgaga"
        "WCzW6dOn3d3dW1tbQTEAAAAA0JuZMGECPl+WQCAIDg4mU5WpqemJEyfwYZ6oKHEpEHkEgD30tX4DLUNXA9qIjNgLJpMZHR2N2dbx"
        "/PnzsWPHXrp0iYyw+vr68PDwNWvWdHZ2ou7ZvHmzqakpKAYAAAAAeq17ERAQ4O3tjbqal5c3ffr08vJyuUTGxsZu2bIFddXY2Hjl"
        "ypWgGAAAAADQXmTEXmzduhV1qb6+ft68ebW1tRSkHjp0aObMmZ988gnh1eXLl0dHRyvYMCsrq+DgYF9fXw8Pj6FDh/br16+jo6Om"
        "pobL5aalpV29ejU7O5uuTrSyspo1a9akSZM4HI69vf2gQYMMDAxEIlFjY2NVVVVhYeHz58/T0tJSU1Pb2toUF2dvbz9z5kxvb28O"
        "h2NnZycVJ5FIWlpaBALBmzdvpOISExNpjGJxcnLy9/efOHEih8OxsbExNTXV09NrbW0VCAQ8Hu/Zs2cpKSlJSUnKjpvBzHt1Z/bs"
        "2YR3kkyv0oWDg8Ps2bN9fHw4HI6tra2ZmRmbzW5vb6+trS0rK8vPz09PT09ISCgpKaG9pWoULRM7O7vHjx+j9pEJBIKJEye+fv0a"
        "tKzVWtb8BqLsJDg4+PLly91/cXV1/dvf/ib9RFtYWBgYGLS3t1dWVubn56empl6+fLmwsJCW9urp6c2cOdPf33/cuHFOTk7m5uYs"
        "FquxsbGkpOTZs2fx8fHx8fEikah7kaamJiMjo55VJSQkzJkzp9e6HiNHjsQESaxevVqRyl1dXTEhHTY2Nih7krk0aGZmFhMT097e"
        "jg/ySE1NpXbuSfevWGBg4L179/CxKV00NDT8/PPPlBOH6OrqLlu27PHjxySTlTU2NsbExMibdv3D2S0WKzg4OD09nWQDT5w44ezs"
        "rFT3QhHkanVaWhrJalNTU4ODg1ksluINVI1oRZbYzczMXr58iaqhubkZM98JWla7aOUZhuaYcVBQUNc97u7ut27dkvkAv//+u5ub"
        "myJdZ2houHXr1srKSrygoqKigICAD9yLvhjvsnfvXlQfPX/+XHFbx2g9JCSEmvWPHj26pKSEpE1LJJKoqCh5/+tI8fLyyszMpPDt"
        "E4vFR48eNTExkUvcrFmzuFwuBXGtra0RERHUlOXp6fn06VN5JXZ0dBw8eLBfv35a6l54e3tnZ2dTqDwrK2vcuHGKtE5loimPImw2"
        "+/79+6jiIpFo7ty5oGWNFa0a90LtZtzlXqxZs0YoFJKULhQKw8PDqfXblClTeDwe+ZbGxMTo6ur2afciPz8f1TuLFi1SvH5pjCch"
        "qMURvPVzOJz379/La9P//ve/5X3yr7/+uqOjQ5EvYFFREcl/+Uwmc8+ePQp+cC9duqSvry9XGzdu3KhIG/Py8oYPH6517sW2bdtE"
        "IhHl+kUiUUREBLWmqVI0tVGEyWSePXsW8wxr1qwBLWusaNW4F5pgxlL3YsuWLRQeYMeOHfJ2WlhYGIUm//bbb33XvRgyZAiqX969"
        "e6enp6e4CCcnpzgE33zzjbzWb2BgUFBQQM2mw8LCyD+24oO9FD6fj1oD6s6RI0doEXft2jXycxgHDx5UXKJAIBg5cqS2uBcsFuuX"
        "X36hpauPHTsm15SY6kVTG0V2796NPzkItKyZolXjXmiOGQcFBc2YMYPkmjV+bUWRP8ky2bRpUx91Lz7//HNUp8TFxanrqTDWv337"
        "dspqbmxsJJOTlMFghIeH03iWW2pqKn7IX7lyJY3ivvvuOzJt/P777+mSWFFRYWtrqxXuRXR0NI1dfeDAAfKNUr1oCqPI6tWrMULP"
        "nj1L44AHWqZXtGrcC80x40WLFily9GZNTQ0m/WN3pk2bpshUTVtbm4uLS190L3bt2oXqlGXLlmmae1FTU1NfX99zbCssLKypqSHp"
        "L8uUPnz48La2NplV1dbWFhUVvX79uqWlRebNq1atQokzMTEh8/BNTU08Ho/H46HMtHtUxIgRI/BtnD9/PpkJzJKSEi6XS2YpKi0t"
        "TUdHhy4D+Ov/ByW0paXlLyJQ1S5dupSMkVRVVXG53PLycjI3L1myhEyL1CJa3lFkzpw5mJWypKQkNptN42sOWqZRtGrcC40y4+Li"
        "4g9+kUgk5eXlRUVFdXV1ZET/61//ktlXxsbGZWVlMquSSCR8Pp/L5VZVVfW8yuVyxWJxn3MvLl++jOovZRyaSuPfmuzs7CVLlpiZ"
        "mXWVcnR03LFjR0NDA36Q7t+/P1769evXMTUUFhaGhYUNHTq0+2zhuHHj8MvVXC4X9bdv/fr1eCdm586drq6uXcWZTCaHw9m/fz/G"
        "Bzp//jymgYMGDaqursYIjY+Pnz17toGBQVcROzu7LVu28Pl8TKl169Zp7FIxg8EYOnRoT9/0gziS0NDQQYMGdRUZMGDA0qVLc3Jy"
        "MKXq6uqsrKw0U7Rc/TZmzJjGxkZUkZycHGXnwQMtUxatmq7WNDPuTkZGRlBQkLGxcVcpZ2fn3bt3Nzc340V3/8oRsn//frzoBw8e"
        "BAYGdhc9ePDgL774guTMSm92L1DbItrb22n8M0q7exEVFYV6PCcnJ3xwL37Jzc3NDVP2119/xcROrlq1ClN27NixhKUSExNRRTIz"
        "My0tLVHiPDw8UON9e3u7ubk5qmBMTAzmfZs/fz5mouXixYuYIAzCjd0aMvD89ttvGO0cPnwYFWmkq6uL/8ScOnVKM0WT7zdbW1uM"
        "70gyfgi0rC7RqulqTTPjLr799lvU6rObm1tpaSmm7GeffYYRbWlp2draipnfXb9+Paosm80+evRon3YvUNs7FcmWo2z3YteuXfji"
        "I0aMwNgEfgvJvn37UAXPnTsnc+H5woUL+ACfnqC2UAuFQpnfdE9PT9RsNmrTr7W1NSpZSENDg6enJ14ik8k8d+4cqo1r167VzIHH"
        "2dkZNTnZ2dn5008/yawB830Ui8VOTk4aKJpkv5mammJSXNTV1Xl4eKjxrQct40Wrpqs10IxJhpqNHj0akx7p0KFDmLI7d+7EiCaT"
        "ePr48eN9171ALSU8efJEM92LnJycrp3E1Ez54cOHmIKjRo1avnx5VFRUXFzcw4cP+Xy+NDL53bt3ZCaHp02bhpJ74sQJwiKooKHU"
        "1FQyfdXdfEUiUVlZ2aNHjy5duhQYGEh4P2ZHDMlQaiMjI5RX+uzZM80ceDB7ZB4/fkxmok5HR+fRo0cUItTUKJpMv+np6d29exd1"
        "Z3t7+4wZM9T71oOWaY/xpNDVGmjGnZ2dL168ICMaE46akpKCKYiZCO/acYqHzWZjUj/0cvcC5dYlJSVppntBMuDU3d0dVUNZWZlc"
        "D8Nms11dXUnuvTQxMUHJvXr1KmERVEKYR48ekZFob28fFBQ0YcIEGxsbmY4Xk8lETRUmJCSQ75O1a9eimung4KBpAw+LxcJk2SOf"
        "1NXHxwdVSWVlJeH0rBpFk+k3JpOJn/FWZXw3aJmallXQ1Zppxp2dnUuXLiUjd/To0RSGA8xCeVtbGypZfk8CAwP7qHuhmW3GzKF1"
        "j+XEg4pebGlpUd6T6+rqoh7+9u3bhEXevHmD2gDi6OhI7+NhXjPU0TCEmJubo2ZKMXtk1GWl3t7emD9ecj0JJlk7YZJsNYom029R"
        "UVGYD9/27du16FvUZ7Wsgq7WTDMWi8Ukw42ZTCZq+xtmOMDkurh48SL5JrNYLMwmml7gXiDd3o6ODsLfaUmoRTs8Hq+uro78zYS/"
        "ywwVVoQJEyZgTJzw96dPn6I8lRs3bgwbNozGx5s2bRrh721tbXLNV71//x51OJCy8xlT4OOPP0Zd+uBIJJlg7ieUokbRMgkNDd25"
        "cyfqamxs7A8//KBF3zjQcq/sW/wXvr6+nqQ7hfpeYYYDLy8v1KUrV66Qf06JRBIfH8/ovSDdC9TZnt232WgOFRUV5G9uaGiQa5hX"
        "ECsrq/DwcLnMTqaljhw5Mi8v79SpU9OnT6cl5QDqhSkoKGhvb5erqrdv3xL+zuFwNM1sUHt2GAzGvXv35KoKcz+hFDWKxjNz5szY"
        "2FjU1Zs3b2JC4jUT0HKv7Fu6hgOUI4IZDjCpGUgGxnWRlpbWi90L5JJ8bW0toSdBMp2ZipHrHHCJRKKMZzAzM3N2dra2tra2trax"
        "sbGzs3NwcHB0dOyeCUNe94LH46FmKfT19UNDQ0NDQ1tbW7OysjIyMjIzMzMyMoqLiynIQr0wY8eO7SR9BCUeetN30gKq1UKhMC8v"
        "T66q8vLyhEIh4eZkQilqFI1h9uzZs2fPRl3NzMz8/PPPPzhOWvMBLffKvlXjcGBnZ0f4e3V1dWVlpbyt7ovuhUAgIOxEGxsbFoul"
        "pBFauzAwMJg6deqUKVO8vb1Hjx6NSURBjY6Oji+++OLevXv4wExDQ8PJkydPnjy5S3GZmZnp6enJyckZGRkkNaWCsb97Uh0NAeX5"
        "8fl81OIgRll8Pp/QFySUokbRlMnPz1dqfBJoWRO0rC19q0ZQnzJ5NwdQK6JFIBdHSkpKCH9ns9m0xxVqHWPGjDl9+rRAIEhISNix"
        "Y8esWbNo9y2kpKSkrFixQiwWky9iYWHx6aef7tmzJz09vby8/ODBg2SiNAYMGKDsTlPSEe2KgMowJu9fEHwpQilqFE2ZFStWBAcH"
        "a93bClrulX2rRgwNDQl/Ry27Y2hqauqL7kVBQQHqEo2BylrH4MGDz58/n52dvXLlStWEoVy4cGHGjBlv3ryhUNbKyuqbb7559epV"
        "bGws/hVValirFDJZSVQMKmxFrslVmaUIpahRtCLExsaiZoY1FtByr+xbNYL6lFFYN5Trr2PvcS9yc3NRl1SWTkfTGD169IsXLyic"
        "JFRfX3/8+HFF5jDc3d23bNlCbSZNR0fnyy+/zMnJwURI9c3VLlSrqXlCqFKEXxA1ilYEMzOzs2fPqvFYANCyRg1Rvb6BhKDWfSgc"
        "fYCaCOkdII0AEwH72Wef6erqKh7hZWZmNmfOHMJLlZWVDx480Kiesre3v3v37uDBg8k4pKWlpVwu96+//srPz8/Kynr+/LlYLFYk"
        "MXZra+vBgwejo6OnTZs2b9686dOne3h4yLXVxdraOikpycfHh/BIyZaWFs3cE6RUmpubTUxMev5OrStQpQjjFdQoWkGmTp26ffv2"
        "3bt3g5Z7sZY1v2/VSGNjI+FkMIUYESWtqmu6e1FRUcHlcglDdgcPHjxv3rxr164pKNvf3x91gOcvv/yiae7F6dOnMb5FW1vbjRs3"
        "bt26lZGRwePxlBRdLxaLk5KSpIkoTExMvLy8vL29P/roI29vbzKxmQMGDDh//ry3t3fPfwPv3r0jfLcfPHjg6+vbW61fIBAQfhyp"
        "HdOFKiUQCDRKNBnOnTvn5+eHOq9y586dd+/elTdvEmhZ07Ss1X2rXosidC9sbGwMDQ3lWhgaPnx4L3YvcNlkr1+/jroUGRmpeJaI"
        "gIAA1CX1nmzSE19fX8woe/r0aTs7u0WLFp05c+bVq1eq2bnX0NCQnJz8448/BgUF2dnZDRkyJCAgIDo6GpV2Qoqnpydht6MiecnM"
        "1mgvqFZbWlrKuwF74MCBqD8ihFLUKFomly5dWrlyZWhoKOoGHR2dCxcuEI4roGVt0bK2960aQW3+19HR+eijj+SqCpNusZe7F6ip"
        "BQaDMX78+EWLFiki2M7ObsGCBair8qZkUTaYeItDhw6tWrWquroaX4OScnZ1UVlZGR8fv2nTJnt7+/Xr16OyojEYDELF5efno5xr"
        "TYurohHMpnMfHx+5qsLcTyhFjaLxJCQkLF26VCwW37lz58iRI6jbHB0djx07BlrWUi33gr5VIy9fvkRdQh0YiWLevHl91L3IycnB"
        "zH8eOXJEke3IBw4cQAXyZGVlUcsNpTxQPmZjY6PMY39VPA0gEoliYmIwzh+hf52VlUV4M5vN7sX+Nca8586dS9dnglCKGkVjKCws"
        "XLBgQVee1sjISMyXdOnSpRTCnEHLatdy7+hbNZKRkYG6FBISQn4Hvqenpxozrqof/JFuGRkZFGJlGQxGWFgYptrw8HBUQVpOf7lz"
        "5w6qHlSRxsZGwvvJp3RdsGCB4g/fv39/8ie3FRQUEIoTCoWEf0ZRj3fy5EmNtU8Fu9TS0lIikRDW8P79e/K2bWRkhDoYSSwWE075"
        "qlG0XP02cuTItrY21P319fUqyIIDWqamZRV0tbaYMb3Dgbm5uUgkQpWKiooiP1PYR09MlcJkMp8+fYrpgj///FPe/+UrV67E6EYg"
        "EGC8P3XZE+r+5ORkkkITExPlevjVq1dHRUXFxMRcvXo1PT2dx+M1NTV1dnbeunWLpMSkpCRCcajQkOfPnxPe397eLlf80Y8//lhY"
        "WHj//v24uLh//vOfa9as+eSTTzw8PJSxVI/q0sTERJI1PHz4EFVJZGQkyUoiIyMpWIgaRctlihs3bsR/AZSd0QS0TE20ajw5bTFj"
        "GocDfKmOjg4yuRs2b97ciaX3uxcMBmPSpEko/1RKWVkZyTO7TU1NY2Ji8H2KPzBJXfYkFAoJ76+pqSFzhGxISIi8ZvTy5UuUL+/q"
        "6ipTIpvNFggEhDWgYj8xo8jjx49J5t1ycXFpbW0lrOTbb7+l3ThRlola6+nJsmXLUK1ubm52c3OTWYObm1tzczOqEszygRpFy2WK"
        "TCYT88rI9XcNtKxK0apxL7TFjOl1L+bNm4d5I5qbm4OCglBlWSzWP/7xj05ZyGwFi8Xy8/OLjIyMjIz08/NjsVgkm6z6gjiOHj0q"
        "sy9SUlKCgoJQSUKcnJx27txZU1ODr+TZs2f4jD3qsqeSkhJUkU2bNuHFffrpp5jpZdTDR0dHo+7PzMzs378/Xui+fftQxW/fvk1Y"
        "xNjYGDU/KS0lU6itrS2Xy0XVMGLECNoHnoaGBtQCEMlVJD09veLiYtQzv3nzxsHBAVPc3t7+zZs3mOIY71ONouV9j4YMGVJdXY0q"
        "JRaLJ02apDz3ArRMTbRq3AstMmMa3QuZ8/rSmWZ/f//uk/Hm5uYhISFZWVmdJMC3wtnZOTs7+4PRk8z5D6ovKAMDA4MXL16Q6ZG2"
        "tra0tLSTJ0/u3bt3165dhw4dunz5Mo/HI1O2ublZ5v9yddnT77//jioiEom2bdtGuL3CwsLiyJEj+Lkf1MNPnDgRUyQnJwcVcWlp"
        "aXnq1Clq80P4+bqioqIFCxYQeqx6enrS7TOostJcHbSTk5ODCRkhuVtnyZIlmFYLBIKFCxf2rIrJZAYFBaGmiKTI3F2lLtEU3qOA"
        "gACMuOLiYlNTUyW5F6BlyqJV4F5olxnT5V4wGAwfHx+Z33ap811WVsblcisrKwmjlyi0wtLSks/n9yzC5/PxsQoqLkh2t6Sdnd2T"
        "J0+Ul2JMakn/+9//ZN5G+HtCQgIqASihPaFOnUZ9qtauXRsTE4Ops6qqKj4+Picn5/379wYGBra2thMmTPD19SU8X5jkw6empnad"
        "g0rIs2fPkpKSioqKGhsbDQwMbGxsxo8fP3PmTMxW0traWgcHB9TRO3p6ek+ePBkzZgxGKJ/PT0xMzM3NrampkZrdqFGj5syZY2Fh"
        "gdHa5MmT09PTaTeb2NjYL7/8EnU1MzPzypUr5eXl+vr6w4YN+89//kOY6p7JZN6+fRtzEDmDweDxeDdv3iwoKGhoaDAyMuJwOP7+"
        "/vhzom/evCkzeF5doqm9Rz///HNYWBjq6sWLFxcvXqyMjwNombJoCt9hCoahXWas+HDQxd69e7dt26ZIb/v4+Dx69EjeVhw7dmzd"
        "unWoSxs2bEBJVH1Bsri7u2P+nioIPuRC7e7qgAEDUDO0JKmoqEhNTZXr4T09PTs6Oujt5zVr1uA7x8XFpa6ujl6hhw8fVpJXOmvW"
        "LPKP8fe//x1Vj4WFBaFvTpnS0lKMv6V20dTeIyMjo1evXmFEL1++HLSsaaJVMHuhXWZM1+wFg8HQ0dG5du0a5TYePHiQWivKy8tR"
        "pcrLyzEPrPqCcjB8+PDCwkJ6xx6RSLR69WplW7/i9hQREaFIM5csWXLx4kV5H37Lli00dvXZs2fJzCT7+vq2tLTQJfTevXv0Lg9/"
        "8PciMzOT5JPcuHEDU9XIkSPfvXtHS5Orq6vd3d3Jt0L1oim/R15eXu3t7ajiDQ0NNKzFgpbpFq0C90K7zJgu94LBYLDZbNSHHU9C"
        "QoL0w0ihFZhFGXzOaNUXlA8zM7MrV67QNfa8fft22rRpqrF+Be2JxWL98ccf1JopTR1Bwb1gMBi7du2ipasvXrxIfpifMmUKLV+K"
        "27dvU8uMQp5Ro0ah9qr0/GbhvSsPD4/S0lIFm1xcXMzhcORthYpFK/Iebdu2DfMMGRkZyvAmQcsKilbNB1aLzJgu90Lq/n711VeY"
        "zS89uXz5ctc2CAqtwEwU4ROoq74gFYKCgjCbKcggFotPnDhBeDCMxtqToaEhJsYTxX//+19pYgBq7gWDwQgJCcFEAMmktbV18+bN"
        "8mYlt7Ozu3//PmWhHR0d33//vWpO7p47dy5+b04XMnevDBw48Pr165RbffXqVXlNWi2iFXmPWCxWcnIy5kn27NkDWtZA0ar5wGqL"
        "GdPoXkixtrY+duyYTCejrKxs+fLl3b/GFFpx/Phx/IKL5hSkiL6+/vr16ymslQiFwjNnzlBzwNVuTywWa+PGjSQH+5aWloiIiK6t"
        "FpTdC6ntnjx5Ut5QjI6Ojri4OMp5FZlM5qJFi1DZP1FIJJIrV66Q2e9OI15eXqhMId1ZtWoVmdoCAgLI1Nad3NxcWo4PUI1oBd8j"
        "W1vb2tpazD8HuaYkQcuqFK2CD6y2mDG97oUUY2PjxYsXnzx58unTpzU1NSKRSCKR1NfX5+bmnjlzZuHChT2D/Sm0wtLSkjAYorS0"
        "FH+SnOoLKros+vHHHx8+fDgvLw+/S6e+vv6PP/4IDw9X5Gk0xJ7Mzc23bt2KSnMpXfTZv3//B2eyKOJeSLGysoqIiHj48CEqzVeX"
        "A5eSkrJ582bUgdryqtjPz+/kyZP40C2xWJyZmfndd9/ht7krD11d3cWLF9+7dw8VHNDW1rZ161a5Wn369OmKigr86t6vv/46Y8YM"
        "Go+sU4Foxd+jhQsX4v+iKelPNmhZK9wLbTFj2t0LCr1ErRUuLi4fDECZmZlOTk4yJaqyIJ0ma2pq6ubm5uTkZGlpaWhoqKenJxQK"
        "a2tr+Xw+l8vl8XgSiYTRu7CwsPD09HR0dDQ3N9fR0Wlubi4vL8/NzS0oKFBqY/X19V1dXZ2dnYcMGWJsbMxms0UiUUNDQ0VFRVFR"
        "UUFBAeHBIopjY2Pj7u5ua2s7cOBAfX19iUTS1NQkEAh4PF5eXl5TU5MmKMXIyMjT03P48OGDBg0yNDRsb2+vrq5+9epVZmYm5iBZ"
        "DI6OjhwOx9bWdsCAAXp6eu3t7XV1daWlpfn5+co+e0+NojUc0LIWAWaMol+/fs3NzYSXbt++7e/vj59Knz59upeXF4PBePr0aXJy"
        "MslBR/UFAQAAAABQHa6urpigPW1vHQsUDAAAAACKwGQyXV1d5T2GY+rUqahLfD4fehUAAAAA+hxsNnv8+PERERHXr1+X5pyUK38l"
        "/uCS0NBQ6GEAAAAA6EOsWLEiOTm5Z/pBoVDo6+tLshLMMfSdnZ2Ud/wBAAAAAKCVrF27FpNnKDw8HL9KYmhoeODAAYxvoYwTmgAA"
        "AAAA0GiMjIwIT0DtIi8vb8OGDc7Ozt033Orq6o4ZMyYqKurt27f4LCCBgYHQyQAAAADQ5wgJCSGZNLmkpITL5ZaVlWHO6+lOYmKi"
        "atKcAAAAAACgccTFxXXSTWlpqaWlJfQtAAAAAPRR2Gw2hVOoMJSXl8s8MQcAAAAAgF6Orq7u4cOHafEt/vzzT2tra+hSAAAAAAAY"
        "DAZjxowZ8h7h1h2BQLBhwwbVnC8NAAAAAIDWwGKx5s+ff/fuXbFYTP5w6bS0tLCwMCMjo17ZJxCeCgAAAAD0MHjwYD8/vwkTJnA4"
        "HHt7+0GDBhkbG+vq6opEosbGxqqqquLi4oKCgoyMjAcPHlRVVUGPAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        "AAAAAAAAAAAAAAAAAACt/B8+Gbolj4zezQAAAABJRU5ErkJggg=="
    ),
    "ZeninElite.png": (
        "iVBORw0KGgoAAAANSUhEUgAAAVcAAAAnCAIAAAA0Bpw6AAApdUlEQVR42rV9fXQV1bX43mdmbnJvcvNJCBDQJCQkoShasKhYRe1T"
        "sKjFn78uFyoLf8/Kz74u2/oTWF2+StF+iG39erLs8+OJ1YItasWPipQHKFBQQUURAgSIfEO+yE1yk9yZOfv3x9yZe2bmzNyb1Dfr"
        "rqybuWfvc84+5+yzv84+ePv5+QAASABAkHlQ+MvdL52HZC+9D9m/D7eKLPj9FcqqIOH9kKqggF5nqrBLEFC6s+gq0jmYYgoCJ6tY"
        "iRYRoZGAUIBAcNCIvfBQydOLnAYivBf/w1X8TwyEvwq0Xwa1lr5uKqF/slMOVQjzJHxFDLML7nlIMvwilVh4/0noPPrI4Xkvfs8M"
        "NtKwq/BTQV5FtlEkARv6Zom03hzxO2Up0z4SeB8iIDK0VzwiovXSKeNiARBYpb/BuXQhh15QyKL1VMGCqURh60dShacLuQwEZlui"
        "0i54vmefrrnNqMDpSnIqSarwsQD/UkfZzB9qF8jHIMgHrgov5TzGw7wplDHLt01PFYSAJBbmssk3tCp87MnDSrmbuBQ6AFk3BN/s"
        "ttY1AgGgTaT0IicfCm8nyNdPkUrgoxIELw/PSFH4nkboqZrnTA3MhUrpLmA4NpKSNLdtGQm5e5vh2aD8NKFsO7+HyNw3V7POU5Kt"
        "CHRzQ/+Kwxy6IJen7JmD/pGScR811zVGBACECAE7RtAooq8A2iSQ4Le2z6FUgQG/on9HyqxNDMGfy26AAnPLLCRyFryHiRMBcgJG"
        "hIiZpgiqko2EMkqGTSVhMXu6YBVAlC1OCl1NZEHZTCBThc12CF3Shr8KkjGdoXchbBSCq8iMAmXpAuQ+0NLViFLY9FrIdMGtjNDQ"
        "uhCw1iRdQDd2mUCdMyclh2EAAEPPsguXg4i8HAuzaykYvpEGEyrHxYmyfwPxU+7ScjB+QvLs4UTWLsE9ShAB58A5cQKTgAQCiqWQ"
        "XNNJ3gXydCGtfgyxC5hmtOSBJXDtHxmZdIijYHeBMIcuDG2gs48yDdl8EaJEyPidvIphzKLgVg7DAhNYI4awALcsYEmxJGdLzmxA"
        "h0W5JAYi+dhgMH3dlLX7bM0ZTh6+QsHDj4I8iRnJnCQj51SRBnB3AbJ3wd78MS3hO3YXZ6ojAgAjMkkmOyACEQKY3OHp1jLMmAbQ"
        "TS8fiWw4Tn6+nXsXMiTKmI7sbQHTRk4OxIaOX9QCQBBKvaNMxIEY5NoFCJ1FnODsAJmcymPI0CGRQ2McRhecUXYvB38XQpqKGDx7"
        "0W551wAZnMpjjKHH4OCzIfjWmiMOksz2EaAfUYC1DVTKmDblDCWp865+B57Koiyq5cpZ3RpOiJrj8BoSlyjmUEu/Tp39jraFZTHI"
        "1zBYkCcToG8QBgzOifJVFlUhX80yIylYpXTa0JsinYPGIB4BRWUBXBkxPb0yVOk3qHeQdA4aQlEey1elFh1h5AUSWbAGB5VBUR46"
        "HQlT5oX5ndSpq5/czbHFPUSpVa4sijEN/ftEFn3EYTgWrxR4knSQ/bPRbioAYVkMYhoSQFc/ffCV3jNIAFCg4YwatTTqzCIM306l"
        "RgHbVuJtflKnrn7BGpC2dcgXjabAyAKrEZAUJmeaeiojgK4B/sFXesJqeQRnVGulUaEV7umPARs9UaCVPbts4t4IVf+OSu7+v7FX"
        "58IrBWHOxEhUDVTqEL1My8ZPAZRD93aXTcK3i3OC3WfM3acN09c898JGAOKEh7rMI2f56V7u2a5L8vGcYtYwQvGzAwilqcFhX7vZ"
        "0mlaE9F5ivKwrkyZUK6oSrrLKoKByOx1QIAGp31t5sEuM+GGLc7D8WVKwwhFYUITXMoDWvUe7AyE1ZiEHQuGTEKAPp3e2JviQ5TF"
        "GcKcpkiBi88iBvsX7Gkt7MyuIcZc6NzvbqrVhjwVP/hKv/La65955hkAuOuuuza999b1DRHLCYOh44gyb2WQ9p4cOqEaRijfqlKT"
        "Ov3VDaggzGnKy1fhg6/0GdKWi/wOCAHKohjVJIsCKExuCrB/o19aSZPU878HsqufOAHZj2EYJkFXP7mrdxnESBDJ0acFUqAyGaL7"
        "SfCf6uVv7Uu19hc88R9PmaYpbZ4DdaKH3mpO7emO3XDrXX9d82Zra+vAwIBpmu3t7du2bVv0wK/6i2rXNKf2d5gQ7L/1tLytj7/Z"
        "nDpJI366+OcffvhhIpHgnCcSie3bt/940b8f0Uve3JfqSBIAMntUFCQNidKw+kkY8RMf7D2L/v2IXrKm2YKVjJ9TbxDsm82ptmR2"
        "v49nZHN8OEFnPwWRSGZtwaFqy/4h6HQ31WpDVz/1DNKzzz5bWVlZWVn5zDPPJAapa4CGij/oVwpYAlmfX/ziF+19HHzNTk/OAd7Z"
        "T4mAllscZ+Nh3fpsOKz/dW+q36BA6SrAD0rB1gFwyeZpkUmFAFdteHCCm9kgeCVKz9xAdHPYIMYvjWrwuE/7Ddp5wjzUZd5yyy2P"
        "PfbYqFGjwjfwlk7zw2PG3Xf/8Ne//nVxcbFYrLy8vLy8/OKLL160aNHy5csXLlyYMsxJlYq8YYTOXnq6l284pN96+7ynnnoqHo87"
        "xeLx+LRp06ZNm3bffffdfffdf1618urxmqqizoFz0gE0BYYEW1nARELlDvud8drIAiZpP9LXY3qSyJiSjR2zcVXKWfLK5TE5YbBO"
        "7hdUg9qfKw/7+h6TEwA6HCf90jRVVe3qp1iceQiEPqMGC/YaBLDsjJ7G0G3qxmA3ZtCKRYnR1xXk4B8Uf+RDwMil+4KYZgrHe/ia"
        "5hSUnrt27dpVq1ZJWYD4nOrl248aTz21fPny5R4WID6Kotxzzz2vvfba5210tJvLZ4Dd0KQO77fqC+7+4YsvviguRZdSUFT0pz/9"
        "6V9/cNf7rcaATiYQIOgEidQQYQ2yq8WkTrnDbmo1Bg3ZABICDXNu79u3DwDylGwrhFBGtjB3AwabgYOe0igWRnDBggVnzpw5c+bM"
        "XXfdFdOwPMak1qDMrkZhO+TXuPJD8JfJWj4ixnJabLJ3QTZUzC4TIQAgEt4+Od+zS4ty3fEE33hY9zCnq2u1qjgjt7mSCNr6eIpn"
        "TCfl+ZiveaWKjiT1C7OzNB8LIlm0cUcvQMC1Lfr0a25cuXJlfn6+9WsqlYpEIp7mjYkrlurw7oHUrJtufemllxzMH3zwwfPPP79r"
        "166BgYHa2tp58+bdcsstzq933333Kyv+84aGSMCURQD4oFUvrTnv448/VtW0JLVp06Zly5a1trbW19ffd999l19+ufVe1/UpU6Z0"
        "HPni/DGgAhgEnx6H0eMvyB2279ie6eekS37QqpfWnD88WO/6ROoepDebU3V1dSFzr7Gxcc2aNYwxAOCcT58+/dAXH11TpzEfyyaC"
        "xCD16wAAeSoW5QNDyeQTrWWO0osASZ36dDI5xDQsjKSDLR38x9yTEBGvrNGqipg1OR3kV9ZoY4uYZUfo8NUCAAMG9aVI51CgYTyC"
        "kuhfJL893VM757yhoSGEaJ2dnSV09rJztGMJvkG2dsbE2TFfy6uK2Jk+3trF93eYHpCGEcqYOCuPYiyCmWbZprHEYHpB5atYlIcK"
        "ZpGw0MMCgABBhUzwM3ocf5hFdxKEDoK9beaOE4ZYJk+B7zVGImqm5S2d5rajrjIqgzlNkaxWeqcik9PkyZMdFvDee+/927/9W0tL"
        "i7SBSZ06knTPPfc4b3/3u98tXLhwVCEbWYAFDPduOzB37bt79ux58MEHrQILFiz4wx/+0JOieCQTAyi45qh7kL7qNp/77W+dpfjq"
        "q6/ecsstYwppRJTt3LT/qr/9bfXq1XPmzAEATdN++9vfzpo5s34EFEUgqcPpHnh5SLCzZp4/SolHsHuQvurm/nqrCqk8FgZbGEGv"
        "D882JV5bp3UkW6Xje6KHn07iyy+/bLEAAHj00Ud3fLR99oSIh6939tOeNuNYN9cFr5TCYHQha6pQKgsZCizAYy1jCJNHqR4zZ1TF"
        "ujJ2XqVq2UcDTYYGfdCqi2/eb9XnNEUAIPdaJlWqiuO0RJLKEd6XRC0tLRPKlaI8BIlDnioK8NxibagtrylhB7u4XARrN/e1mwxh"
        "TlNeTLNiiaizn75sM491m36yT6xQKguZXy2wjzhY2zRlJHgr6hnJZaWj0PMYErIAEIDBoa6uzrGF6LoejZccTXCRRC2d5g9/+EOn"
        "zMaNGw0OoXIlCQYCEmMdjh8//v3vf3/mzJkHDx70D55VrneQACAajR60n4ceemjKGPVfxmuTR6kTRyrfPlebOkZ94oknMtbdhgYA"
        "6E0RZfSrjJmCAA51mg0NDd/5znes8olEYsGCBQ1lMKNa+0alclWtWlcCCxYs6O3ttQpce+21dfX1x7uBAI53gx92QhlcUa1NqmRX"
        "12rjS32wdfWHOk0AOBxQ7xXV2qSRytW1Wl0wrDPLSRxcwpEFrKlC8X+qS1hHkt97773Tpk2zQJubm3/+859fOFotzEMSyLHjhPHO"
        "/lT1BVc898KLBw8eHBwcNAzj6NGjf1n92sXX3PTfh82tR3STZ/iFx1rGCfZ0KgvuuW/Hjh19fX26rh86dOj3Ty7viY1750CqJ0Uh"
        "OunZfjIJDMPwWA2HVMvfDqR6UyROm5zO2ACMK06TrrFCaaxgjRWsMf1drStTIkrY9tkla/mZJP3iF7+w/hUVVXfvuLUOdpww3t6f"
        "qr7gcinZ1x82txzRObd8M+hRHGQB7cgwEzJCmLNphgAIUYxwPKeEtbS0fPzxx+lNXlVnzZp1tJvbPggcNKi9j773ve85IKtWrRpZ"
        "wCyno8cW6AnwsxciEoBhGE888URTU9Pf33r1GyOVkBaWRVm+iuedd16d/aSSPXVlioh/wCBHsgAAaxVpDN0KXsY6eaKHW/ut9axc"
        "ubKnu/P8UapNXJw8Wu3qaPvLX/7ilJkzZ057HwBAey/4YSdXqo6cd8EoCeyJHm4ZRKT1Om8mB8BimMdYInkRwLZjRn3TpF/+8peO"
        "XDpv3rxiNdUwQhEjWN7/Sj+px19//fUNGzbMmzevtrY2EokoijJ27Nibbrpp9erV27dvN+Nj//uQbgZMq5KSkq1btz7yyCNTpkyJ"
        "xWKqqtbU1Nx99927d++ecumVmw7rnL4GLT1rLSb9k3YBO+YLM/Yxgv+Rhwg2faWfyIHs6w/pnKxQR3FLk/oaMhFQVlEUrIOUpTOU"
        "PhNklS/Jw7Iorly50vn9+uuvP9nLeXoroGMJXhiPX3HFFY7u+uqrr9aUMi53bGSiTVGwjcQ0fOSRR+679yf1hf2zJ0QqC5g0nsJq"
        "v6bAnImRGxrFj3Y0YTa3mc1txuenjHUH9d1n+K9+9SsH9s0331QZlET9HloCO97r0ksvdd6uW7euKs6sKCGrnXkMRsfZ2rVrnTKX"
        "XXZZYgBMDolB8MNqSoZH5ykS2M5+Mri8Xi0zehgJgOUkN/16hD6n1MFO83SSrVixwrG2LFu27NOdH18yThUtUrtOGWd5wfvvvy/y"
        "Js9z0UUXbd68mRVVfuJWFR31fvny5VOmTPH/VFBQ8Nprr+UVj9zbZmYN+wn/Jfda0HdEjwfX0p6k4wlufY7ZX453m6f7KJyV/HNM"
        "DYdE9h0nDJIEpKO4wK33DFwLnhxZCHNrsFioplT585//7Kz7WbNmAVNP9nKLYxxN8FmzZjlza+3atV1dnecWM5C7mtEf24AAF49T"
        "LxzJb2iMTBqpsOBtzrFMKQhFeeh8Pjtl7kkUno1Vn43VKGPOn/m/bt+8efOdd95pgR06dOj+++9vGKEo6PFpWToTJVNEBI2NjU5N"
        "X3zxRVmUOWwUCQipPMZ27drllJkwYQIn6OoHKayNPD1aI2SwbX08qF4UIgKl9famKOgwrH/lJHXaecJYvHixs2x279794IMPfnO0"
        "WhjJyJY9g/Rlm/nUU0+df/756VXR3r5w4cIpU6ZMmjTpjjvuOHDgQFpCPOecp59+el+H2ZPyLijG2Ny5c7du3TpnzpympqYrr7xS"
        "3EJKSkp+9KMfHeoyCaAsigzT57IRkSGURTHHEIQca7HnPOS4k+86ZWw4rFufjZmPsa5F/+i4MQxZIKbhk08+WV9fX19f77zknNfb"
        "DwCoOGSy96bIE5rlDt5JzzpG7vXmhPtgtngB/zyqLmEnT57ctGmTQ+LLL7/8aIIjACc42cNnz54tyrRjClmeGryUZQcuoypOKGdO"
        "7FrWoANPQxMDNH/+/AMHDhw4cOCTTz5ZsWLF9OnTLUfDH//4x0suuQT72iaPUvwBC5bQbhljRffkiRMnRB+HFXwa0+DEiRPOyzFj"
        "xgBAXwqksJ5MEAUyWMusFVSvs8ilsP0GSZ2y0mfbUaPxG+cvWbLE+tcwjPnz55dquqULOM+edvP8yRfMmzfPsdFMnTr1D0/+3ji+"
        "K9Kx780/vzh16tTdu3dbv954440XXvjNZtmuvn79+hkzZnz0329Gu1uO7Np82623rlixwvn1uuuu6x6gAZ1iGt7UFLm6RruqRruq"
        "RpvTFIlqQ9hTnVpi3S1HA2rp13NdtqKuHhIyFMIHpD9MKFcmFCR6Tx0STd2WJTJ5+lBJsnVWnXYkwQPJ3iknuyXmkCxhAQmuA2Yf"
        "/ySX057CrIOZg2GI4hmraARHFjKR186ePftYggPAqR4OTP3ud79rve/r63vrrbdqSlmAxSGN3OOzILRO8tnvMQcq5zC4uq4//vjj"
        "DzzwwJkzZ86rVBR57AMCkGWPLSwsdAYpmUzahwYy8RMRBn19fQ64VT4VAEvoks81hn7Y0HqzwFrGOUe+DTgKgQBwoMNsG1BWrFih"
        "aemDIg8//PDnn+68ZJzqMRwc6ebz58933ixatOirr766YJQ6IsZKozi5Uk0kEgsXLnQK3HrrrSd6JHbgBx54YGwhv6pW+8ZI5dJz"
        "1fpy5fe//73zq+XFTBpAAFENq4rY2CI2tojFtKGJ1VYtV9dq3xipTD8nrJYgp9qQtXfhxHeOj8qgrlxpqpDYuZoqlKYKtaKQhZE9"
        "X072kw7Z0SsPEJKzP7Bh6C3pdDnpUGEk+4QAA6gpYa+99loqlXIYUr9O7Uk6luCXXnppWVmZo34P9PedU6ygf48SDthR+uSsfZCe"
        "ANNH4BBch3SzCCzhe6CmaYsWLdq/f/8dd9yx6bDek7LMpJ4oaa96AnbuIMvx4trS0dU46zvnclgROQbAAgTCiiEbQbAYnMbHed+X"
        "op0njfvvv//CCy9MC727dlkuFUcXsBh0X4r6dZoxY4ZoTAGALUdsCblVt+IynALTp09PDJLfSLhjxw5nDgBBZSHbv39/RkiOxQBg"
        "0CAcwrFcybNjx45xxRnrS1AtHsHqn1HgMVsSoSGZOqw50jsIwyN7pmuC5o8ISOgktmBBMUm5dBaJEEicj9UlLNF99t1337X+ra2t"
        "nThx4tGEeSzBRe/An/70p3FFjlHNbbiyvfPW8kLnlFWau7p8GVn5rVPYKlgRw8cffxwRGWPl5eWzZ8/evHmzVTISiTz33HMXTv3W"
        "ZyeNtNUTvTmerAY73jhrDumcRI88Ihg8PbdEv4NlxZDCip2QwkYC6vUwZSmsxiTDSm7WgADbjxnnTf7m/fff78hH8+fPH5FnTChX"
        "UMwcQNCrEwCMHz/ewdbT0+OXjUWpxCqccusEpmnquq4pNusHUhk5+wfIzwQNmQVYtUQU50wnaAz8tZDLQ00QkATNo6v7nyeffLI4"
        "H0Otg0EBzGEGRQTo0/nwyN5vOG4M9J+0tIxS3jmSewI2dDYgzIxXnopj4i6l4MYbb/zitJnUyTEKdHZ2rlu3rqZE8RCehIiF9IIn"
        "L+tETwq/XMQzRIdtXDhanVmnXVWrzahWJ8QSn37w7owZM15//XXHkrRo0aIj3dzgKLNZkuXU9OjeSd17nqIvBVVVVU6ZkydPAkBU"
        "hSBYEqy1fSnyw5bky+t1z1OUwkY1lEbsk60mAMD+DrNjUH3xxRedkKSHHnroyy8+u2Sc6j/vZakYBQUFue+NVryzzkNcbSQ4g7Jr"
        "eEP3wyEiIFKOE8YJTpH4iohaWlpY1+HS/taSZGtJsrU02Vran/40FiS+VaVRWBbAQD02TABBMIZL9kEjsPvpcAIMiIyg4KySTgki"
        "13ey39SUKm+//bazcV1//fUAMHHiRMf4uXr1auTGmCLFMY+jL1WlRxAWgymc9U+hziLrc6qXf3na+PK0sfuM+eUZ81QvH1nAquJs"
        "bBGrL7cCdfBnP/uZA3jFFVdwgu5B8m86BFgQAYawd+/ejJd+8uSOJHdFOhB09vNJkyZlbGl79jCEshigDNYz06WwViIKKazjC0aE"
        "LhlsTEPykUXkHr0p2nnCWLJkiQP7ySefPPzww1PHqDENMwKkrelaEry452RXelXV8rMGbSfWmIanyqJ/SmMnyhYNk6GMe2JJp5kV"
        "NTRxpDJxpNI0UmkakQ64ckKGgs5qYJYGBP5uRVIOg+ymEyogWgLcq071azNOpCll8yxJjx+MK2bbjibfeOON2267DQCmTZtWUVHh"
        "8Q6cU8KQZciLhL2DvDdFBRGM54l7F2a0XgKw8/aFqwNkx0QnBunvBw1xYazbvft7jRG7CgSAMUVss2CVLS8vB4CUKVPfEBCxNIpb"
        "tmxxtJtrrrlmzeuvWnk+rMoNjid7+DXXXOPAbd26NZ4PeREsyiM/rM4hYksrBocTPXyxG7YsylQGZbJ6Uzwt8GMwLAbEfjgS7z+O"
        "Ghd8c+rixYut96lUav78+SOj5vgyTWohtnwTra2tDmG//e1vnzp1KnwJAkBIcpqsxravx9+OWViAO3tseu0MtcpM3sUhto0wDMzy"
        "iw2D7PE8ILSy5NtJ5nw9YjJt31ECA1UV4WSaJ+EiKAzGFmeUAsbY7Nmzb7zxRuvfY8eObdmypbaEOf3VTdh4OPXX5tTfD+lvNKe2"
        "HjFSXIYchzDWFju33D/bt2//wn4qKipaukwhAQYd63YdDuno6AAAjSEiJHU6ZseEnO7lBIBEVXG2Zs0ap/wtt9wSLyn7/JQTFYOf"
        "nzIKikrnzp3rlFmzZs3IQmQMK+IghSWb10lhrRMyo7PUC5/JYKuKmJMrTZpUr7nd7DYif/zjHxUlraA9+OCD+/Z8MW2sKpP+EBEK"
        "IiyiwJYtW5xfJk2a1NLSEu05bEnIJclW6DzcIjwHDx4cE2dRNWS+OmpgUPTHP8sIELOLAyDE26YbhTiEpIKU0XCH3M5stRTmoZzs"
        "vYfTWkkA2Qsj2cnHfCYKEnRzkvKmI91W+J3Z3G42t/HmNt7cZjS3mc1nzLY+DoQ1Jcrf//739vZ2q/yCBQsuvvhi6/srr7ySp5B1"
        "yAQJGcGHRw2t/NzNmzenUqktW7bw4nH/OKILIgDKsrPmZLWw1OkdO3Y4b3/9619/eYavP6TvOmV8cdp8r8U40sMeffRRp8DGjRsV"
        "hNJ8ltTp9T2pDYfSBth1B/XtRwwArC1VDra0OCF68Xj86aefbu6gTYf1L8+Y77fqzR30zDPPFBUVWQXefffdgwdbqkoAgKpKmR92"
        "nw27KQC2upQRgLReC3b3GXPTYb25XQJbW8qEfQnRTnlizbrEIH160njooYeampqsEjt37ly2bFl5jB05y60h3mt/9rSZe9uMtj7O"
        "kMYWKeIxzQcffHD8+PEtnTypk6VPfdVtzpw5s7Oz8/PPP3/nnXd++tOfnuzlRMNfBUEhj0NlBIBh+MFWbTlmkQGOdvO9AnHET0un"
        "aRgwZFcAZu4ycOLuFEUpKChoPct3nTI7+uRkP9jBkzqYBGcDyY5Crkx5qwLsAphh0B4bS11dHZXWnI1Wpz8x61NjfV/boicGeVUR"
        "U8hYvXq1BTVt2jTnaNqqVavOLWEOLRKD1HrWfOmlly677DJN06ZPn/7yyy8f7eY9gyQEOqBotsldIoiqWFnAHnvsMeflnXfeuXHj"
        "xstn3cxHNPKKid/93/M+/vjjmTNnOubfZcuWnVuqqIr3UMrSpUu7+jkhxPPw3BK2aNEix878/e9/f8OGDedfNrO/uO4bl1yzbt26"
        "m2++2ZGuFy9ePLoYYxoAx0KVRhfDkGCrS9KHAsPrnSiDrSlR4pG064J8yYoJYNtRY+q3Lr733nsdAXLp0qXV1dUFlbX2sFafjVV3"
        "Rau77IF+94CeGKTGEco//vGPt99+2wKsqKjYuXPn/1t8f9H4i5LFdVXnffvhR37/xhtvlJaWnnfeedddd11fX9+IGAs354bbel2x"
        "vThMsT+XLddzOsYvP1tLgJfWWGRxfWLVXbHqfX1FHx7XgzasMEMbghUKcfz4cef1L3/5y7xRDanS+o2H9QYZ2e9dfH/R+KlhZGeC"
        "eBKgceC8C/Ik3kmb7XoOV+diir2yJjKuGLcdNSqbLnH8cNazb9++xsbG6+oj5TG0rA8ne/j6Q3oqlXIiVXRdj0QiV4/XRscZElHG"
        "M47+6XIswTcckhzhHl3ELL7fluRrW/THH39CPF8c9PzoRz969g/Lr2+IFETwSDd/v9VwuPKdd9657tUXZlRrhDCQojf3pebdceez"
        "zz4bjvAHP/jBSyueu6yG5amcOCKjAQO2HIKcYZ+/vkFzjl336/TWEOp9/sYGLV8VTIOWi9g2EbT18bUtenNzc/hpef/4XlWrVcWV"
        "7Uf1s0rZtm3bRN+V9Fm/fv3MmTO/fQ5DhI2ywaoqYiGjeVWtVhVn6DP6nOjhGw7phmE4uoyVdwAA5BkxitIHlUOO/VuWJ3H9I9Gx"
        "HhKbnfVZunTpfyxbOqshcrxbkpvjqloNAGQtj4wtYkT06p7Uw7977Mc//rGIs6Wlpb6+/vqGvL1tRveQyD6OjStWMk7KACcMk7JS"
        "280+HBXMmmc1pWzr1q1HjhwRf1q5cmU8D0fE0DE6WBudKLR/+OGH1tZnMWakzN0bOefHz9x7UhFj08dpP/3JT+67774Q++rp06dv"
        "vvnm/3x6+VW1mmX9GjBI9L3v37+/yEpsSRDVcEa19sLzz82dOzeRSEgRJhKJuXPnvvD8c1dUaxEFOIHByTAhosAVQ4BV89VMx6Ma"
        "5gr7X8/NqFYt9pFJf0wuZ/UgB7BPUg9jiL81VmXJjksvvfS9994LKfnCCy/ccMMN9aUwtpgN75yd/wC/GAYSIjIMTxBAy5Ju36hE"
        "ISnKhqV8BLXQ6hFj0FShLF269MsvvxR/raurKy8vb0+a04ZI9nOKrWRiFK7isKxmy+FZdSsLWVSFV155RXy9atWqmhImIi/Kw6o4"
        "u+2227Zu3WoYxpYtW26//fZzillc8+QsHFr14qmJ2lJ2RbX2h/94tKamZuHChevXrz99+rRhGLquHzt27J133rnrrrvq6uo2/u31"
        "a8dHnFx9AzqMHj3a0RQ+++yzUuH0zqhCds14bc2rr9TX1y9ZsuSjjz6yQjh6eno++uijJUuW1NXVvfnaK/8yXhsZY5yTJVJYF5Mw"
        "Vf9ODrDX1mneE5MIlXH2LznCFrKvZygDZoaCcM14rQI6Zs6cefXVV69YsWL//v0DAwNElEgkPv3008cee+yCCy6481//T2OpPnWs"
        "iv/EGWGULLBhRfdljTEjb7g9EuFwGh5C7SzYJo1UCnj3xRdfvGTJkt27dw8ODuq6vm/fvtGjR/cMUu5kbyrRv1Wl5litTyNwc82k"
        "Tq8PJQ0zQ7ipKRLTEBA+P21+dtKbWej6hkjcnWIsZcLmI/pxOx/JuGJ22TjNCikLdA6g0Lw93mTPN7kTpYOd+ftAh3mkm7f1uXrD"
        "EEbHWXUJqy1RxMiqfxwxGi6ZaelgO3funDp16k1NkUJ3yw0Oe2WZyON5WFfGGspVy314un+QMpeiACBURvMMDs3t5kE5rNJoZxMn"
        "33FXADA4Nrcb0nrry5TGCvs+hNBR69P5X9055nMd34kRJ44AANqTtLfNONbDdXdoYGEExxWxiRVKQSStlfT75lJ6sGyOn3U0xXiB"
        "foNe35MyyTv3ACCsFpJMaatAvooArjVveaf6dXh96JnIp1WpQRUBgLTl1qqxDHL7O8wvz5i9wkHMmIZX1WjOYcpwsjdVqLm4BjIO"
        "+RAuYBXo17l4s4JwFEniRXFurbD24rY+LsaNprMM2gcBxIYlBqk3BYWRtC6QhXkJv7kufiCwL03xts35RzcxqfMBgxAhqmKBhors"
        "ltm396X+709/ZqUe+M1vfvPw0vtvbMzzXELoxDX069STsm8HiWC+5qr8dP+gyYHbp7gZwKiCDM1F2HgEQ47K+H+wYHUOmgLxCHpP"
        "2nkvNvIQhBzShW13GDC+BELiKiCCnhRZPgJNwZgGdkdc9Xpv6Yh5+5vUqTNJjlUuU52MrfX77/zQMI1kQPLeaXZS5539GWnRKiAm"
        "0QtJlxiynCyCaAwrC9MYLEBntpdFWUyT0cFqoQ9zTyp9mD2qYTzPittyX81K2JNKu2byXGTPWf4gIEDV879bf0AAimkWjTJ3OmFw"
        "EJd9b06aJCMLGLgOzJA7i5CldSEAxfNQWP8kay1mahd+j6qsKi6mTMhcI0a+E2IIFFEooqDsnrkMZpPD2QG66KKL0hzh7beriphH"
        "QRS/R7V0Fk3/TOUAnBCAOAARMABOwAmYbXaxYCVhJ9kGkQDzNcjXGLquAkXfGAlhYG6CxDQs0EIEwQBO6o65t68lwniew8HFrNQu"
        "DLF0ZxHd18c5zY6pECtCCLx+05Xv2pqZ/rknvrcPnol9Ibvj6BCEXNdneZ+ohlUaBlzTjOLcc4hvfY9qWKUxv4nN00L05QGzlltc"
        "g3j6JijP/Z3pihhScR4W52HAAhcwO2yQMklHnYan5U4izGQmpCBlUjKuJGQttBELl1WTWIDcFkSBfJjJMuhaz17MEo7jqRGBkLxr"
        "gBBCMJNvXbcliRNccsklAHDixInt27ePS9ux0ZNL3xON61knHAiATLLkDlAzsaXEZezEfwmaz0mO7o5LqeH5CQWCkEANb75pCI1+"
        "l6dyEEzqIp39pKaAi1XFZqOn2YJTIJM8OWwQQwgCMswoNht81AgliDR1umiQoqCVKTYvnCBSzAGdAvcN8ejnK3YEsXe+o/vmcgo9"
        "zkBCB4IMr0GaguSKChTvryWUdcad6lpwdMnGlTxNteYiCS5SD2abU1L6slABXVuS19fXV1ZWAsDq1asjjBxDHQk3u6JszXHr+CAB"
        "d5qBEFGRMVAV4CbYurjcKY3B17QLOYTJ/h5IEDELBInXwxCFYhZuGw28ET4cs+tQCKFztzgEtDnoZjCPxycTzOZZhoL0F4g5wKHg"
        "TA95cj0Kc1U4L0my94qObReV/BkeECWbPGCYXQf9DNF30zcFYEYpZlVoq0QaFxV4hlYQLUlFFJRcACtiRinmzElh9HI5O+VoVsyS"
        "NhOSBejHLKTkF3mTC39UxU8PHHCiXM6rzJyutUKyg+6Edp8NSovHeSqoSjr0QdEQTW5dWwY+3YEFXAkjWCPEK+SDJrd3aorU8HAu"
        "ChJzJSOVI2byYRY3n5wmfY6YkQJ3ghBq2KnlKc1gZLPOwxMxBzMNufijFbAMsq1bzAUu3S8xZA2mo3u9+h3JClP4ZiluQKogy6J3"
        "ClCak5G4dTv9C3HFerdzN2ZyreGMupfOIWTPDBLuBQ88Z4EuycbZxDzWAKTAq1JlmOvKWHks0psiBIgoUCHcG4P+y1h8z/5uBBAN"
        "ItFMeUvWECSgCSWW+RSZyDyyuKlpSFd5CW22dj4KgcfAbVnGiIeAmTDwdP2wMWeugA/aY8LIhE465SDMEhYQihnd+WjCD0kKYTwk"
        "LmCSXdSFQpZAuW4uaCLoEXwzrAH95kwAINUzrVyukjQ2O6cQucR4CvIquDVdIo8ELuT0dMYgADOSD7MoR4uYUYpZchxEZPOCJEhu"
        "8wmV5GNJPjp3jTs8UdQo/NIsA799kzJ3Y6FnUQg3zpFbCiffJTnuG+Y9V4UTge/WSFeb005H8hLZRw0vHyeSEz93zK6dVqCnvM0C"
        "GSid0DUEM0lvZc0NMyKFbAnZMCP5eAP5NzgZf8kckc8gQRGzu14Bs3DpvASzh236xDD0b3fO0maiBcnCTARE3uQSsmitzJ2ntpQA"
        "KJzJcBiunY+EXJghBDOIeYTtfDAYgDm9U0g5M0osEZgJqc60LYPZDiRHB3POnpd0Pjd0ie9C1BNlMsMP7YikMEcdihNafgcUSWHZ"
        "QgKIHLLz24lo0imTSEbkIWEOGD435qxERon1K4M5qG25YaYwOnswg6/NIikoHLN8jXjahuhnbOF3P5OI2ckX4l0jIK8u02EERPr/"
        "b3UYaJTugucAAAAASUVORK5CYII="
    ),
}


# ============================================================================
#  SETTINGS
# ============================================================================
def screen_size():
    try:
        return int(user32.GetSystemMetrics(0)), int(user32.GetSystemMetrics(1))
    except Exception:
        return 1920, 1080


def make_area(left, top, right, bottom):
    """Stored as the user sees it: bottom-left X/Y and top-right X/Y."""
    return {"blx": left, "bly": bottom, "trx": right, "try": top}


def default_settings():
    sw, sh = screen_size()
    half = make_area(0, 0, sw // 2 - 1, sh - 1)

    def clamp(l, t, r, b):
        return make_area(max(0, l), max(0, t), min(sw - 1, r), min(sh - 1, b))

    areas = {k: dict(half) for k in IMAGES}
    areas["retry"] = clamp(836, 801, 1035, 927)
    areas["zenin"] = clamp(689, 82, 1038, 195)
    return {
        "areas": areas, "rotation": ["x", "c"], "slots": ["1"], "hr": "", "ct": [], "weapons": [],
        "loops_inf": True, "loops_count": 10, "stop_key": "f6", "log_clear": 10, "scan_full": False, "lock_on": "",
        "screen": "Full Screen", "corner": "Top Left", "resolution": f"{sw}x{sh}",
    }


def load_settings():
    cfg = default_settings()
    try:
        data = json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
        for key, value in data.items():
            if key == "areas" and isinstance(value, dict):
                for name, area in value.items():
                    if name in cfg["areas"] and isinstance(area, dict):
                        cfg["areas"][name].update({k: int(v) for k, v in area.items() if k in cfg["areas"][name]})
            elif key in cfg:
                cfg[key] = value
    except Exception:
        pass
    slots = cfg.get("slots")
    cfg["slots"] = [k for k in SLOT_KEYS if isinstance(slots, list) and k in slots] or ["1"]
    return cfg


def save_settings(cfg):
    try:
        SETTINGS_PATH.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    except Exception as exc:
        print(f"[WARN] could not save settings: {exc}")


def region_of(area):
    """(left, top, right, bottom) from the bottom-left / top-right pair, in any order."""
    left, right = sorted((area["blx"], area["trx"]))
    top, bottom = sorted((area["try"], area["bly"]))
    return left, top, right, bottom


def ensure_images():
    for name, b64 in EMBEDDED.items():
        path = ROOT / name
        if not path.exists():
            path.write_bytes(base64.b64decode(b64))


# ============================================================================
#  SETTINGS WINDOW
# ============================================================================
BG, CARD, CARD2, EDGE = "#0b0c14", "#14162a", "#1d2040", "#2a2e57"
FG, MUTED, DIM = "#eceef9", "#8186ad", "#4a4f78"
ACCENT, RED, GREEN = "#8b5cf6", "#ff3b5c", "#3ddc97"
FONT = "Segoe UI"


class ChipGroup:
    """Row of tick chips. mode: 'single' (pick one), 'optional' (pick one or none), 'multi' (cap)."""

    def __init__(self, parent, options, selected, mode="single", cap=None, columns=6, fmt=str, on_change=None):
        self.options, self.mode, self.cap, self.fmt = list(options), mode, cap, fmt
        self.on_change, self.enabled = on_change, True
        self.sel = [o for o in self.options if o in (selected or [])]
        if mode == "single" and not self.sel:
            self.sel = [self.options[0]]
        self.frame = tk.Frame(parent, bg=CARD)
        self.labels = {}
        for i, option in enumerate(self.options):
            lb = tk.Label(self.frame, padx=10, pady=5, font=(FONT, 9, "bold"), bd=0)
            lb.grid(row=i // columns, column=i % columns, padx=3, pady=3, sticky="w")
            lb.bind("<Button-1>", lambda _e, o=option: self.click(o))
            self.labels[option] = lb
        self.refresh()

    def click(self, option):
        if not self.enabled:
            return
        if self.mode == "multi":
            if option in self.sel:
                self.sel.remove(option)
            elif self.cap is None or len(self.sel) < self.cap:
                self.sel.append(option)
            else:
                return
        elif option in self.sel and self.mode == "optional":
            self.sel = []
        else:
            self.sel = [option]
        self.refresh()
        if self.on_change:
            self.on_change()

    def set_enabled(self, enabled):
        self.enabled = enabled
        self.refresh()

    def clear(self):
        self.sel = []
        self.refresh()

    def refresh(self):
        full = self.mode == "multi" and self.cap is not None and len(self.sel) >= self.cap
        for option, lb in self.labels.items():
            on = option in self.sel
            blocked = (not self.enabled) or (full and not on)
            lb.config(text=("\u2714 " if on else "\u2716 ") + self.fmt(option),
                      bg=ACCENT if on else CARD2,
                      fg="#ffffff" if on else (DIM if blocked else FG),
                      cursor="arrow" if blocked else "hand2")
            if on and not self.enabled:
                lb.config(bg="#4a3a80")


def run_settings(cfg):
    root = tk.Tk()
    root.title(f"{APP_NAME} - Settings")
    root.configure(bg=BG)
    w, h = 1000, 880
    root.geometry(f"{w}x{h}+{max(0, (root.winfo_screenwidth() - w) // 2)}+{max(0, (root.winfo_screenheight() - h) // 2 - 20)}")
    root.minsize(860, 600)
    result = {"cfg": None}

    # ---- fixed footer ---------------------------------------------------------
    footer = tk.Frame(root, bg=CARD, highlightbackground=EDGE, highlightthickness=1)
    footer.pack(side="bottom", fill="x")
    status = tk.Label(footer, text="Set everything up, then press Save & Launch.", bg=CARD, fg=MUTED,
                      font=(FONT, 10), anchor="w")
    status.pack(side="left", padx=18, pady=12)

    def say(text, color=MUTED):
        status.config(text=text, fg=color)

    # ---- header ---------------------------------------------------------------
    head = tk.Frame(root, bg=BG)
    head.pack(fill="x", padx=26, pady=(18, 4))
    tk.Label(head, text="CALAMITY ", bg=BG, fg=FG, font=("Segoe UI Black", 26)).pack(side="left")
    tk.Label(head, text="CLEAVER", bg=BG, fg=RED, font=("Segoe UI Black", 26)).pack(side="left")
    tk.Label(head, text="Jujutsu Zero  \u00b7  Nayoa Calamity auto-raider", bg=BG, fg=MUTED,
             font=(FONT, 11)).pack(side="left", padx=16, pady=(14, 0))

    # ---- scrollable body ------------------------------------------------------
    body = tk.Frame(root, bg=BG)
    body.pack(fill="both", expand=True, padx=(26, 8), pady=(6, 0))
    canvas = tk.Canvas(body, bg=BG, highlightthickness=0)
    sb = tk.Scrollbar(body, orient="vertical", command=canvas.yview)
    inner = tk.Frame(canvas, bg=BG)
    win = canvas.create_window((0, 0), window=inner, anchor="nw")
    inner.bind("<Configure>", lambda _e: canvas.configure(scrollregion=canvas.bbox("all")))
    canvas.bind("<Configure>", lambda e: canvas.itemconfig(win, width=e.width))
    canvas.configure(yscrollcommand=sb.set)
    canvas.pack(side="left", fill="both", expand=True)
    sb.pack(side="right", fill="y")
    root.bind_all("<MouseWheel>", lambda e: canvas.yview_scroll(int(-e.delta / 120), "units"))

    def card(title, sub=""):
        f = tk.Frame(inner, bg=CARD, highlightbackground=EDGE, highlightthickness=1)
        f.pack(fill="x", pady=6, padx=(0, 14))
        tk.Label(f, text=title, bg=CARD, fg=ACCENT, font=(FONT, 11, "bold")).pack(anchor="w", padx=16, pady=(12, 0))
        if sub:
            tk.Label(f, text=sub, bg=CARD, fg=MUTED, font=(FONT, 9)).pack(anchor="w", padx=16)
        b = tk.Frame(f, bg=CARD)
        b.pack(fill="x", padx=14, pady=(6, 12))
        return b

    def entry(parent, var, width=7):
        return tk.Entry(parent, textvariable=var, width=width, bg=CARD2, fg=FG, insertbackground=FG, relief="flat",
                        font=("Consolas", 10), highlightthickness=1, highlightbackground=EDGE,
                        highlightcolor=ACCENT, justify="center")

    def small_button(parent, text, command, bg=CARD2):
        return tk.Button(parent, text=text, command=command, bg=bg, fg=FG, activebackground=ACCENT,
                         activeforeground="#fff", relief="flat", bd=0, padx=10, pady=3, font=(FONT, 9),
                         cursor="hand2")

    # ---- SCAN MODE ------------------------------------------------------------
    SCAN_AREAS, SCAN_FULL = "Use search areas", "Fullscreen scan"
    sm = card("SCAN MODE", "Fullscreen scan searches your whole screen for every image, so you don't need to set any "
                           "X/Y areas. Search areas are faster because they only look in small boxes.")
    scan_mode = ChipGroup(sm, [SCAN_AREAS, SCAN_FULL], [SCAN_FULL if cfg.get("scan_full") else SCAN_AREAS], "single",
                          columns=2)
    scan_mode.frame.pack(anchor="w")
    area_widgets = []

    # ---- IMAGE AREAS ----------------------------------------------------------
    ar = card("SEARCH AREAS", "Each image is only searched inside its rectangle (screen pixels). Smaller boxes scan faster. "
                              "Put Roblox on screen, press GRAB AREA, then hover each corner when asked (3 seconds each).")
    for col, text in enumerate(["Image", "Bottom-left X", "Bottom-left Y", "Top-right X", "Top-right Y"]):
        tk.Label(ar, text=text, bg=CARD, fg=MUTED, font=(FONT, 9)).grid(row=0, column=col, sticky="w", padx=4)
    area_vars = {}

    def grab(xv, yv, what):
        def tick(n):
            if n > 0:
                say(f"Move the mouse to the {what} corner... {n}", ACCENT)
                root.after(1000, lambda: tick(n - 1))
            else:
                pt = wintypes.POINT()
                user32.GetCursorPos(ctypes.byref(pt))
                xv.set(str(pt.x))
                yv.set(str(pt.y))
                say(f"Grabbed {pt.x}, {pt.y}", GREEN)
        tick(3)

    def grab_area(vs, name):
        """Minimises this window, then reads the bottom-left and top-right corners from the mouse."""
        toast = tk.Toplevel(root)
        toast.overrideredirect(True)
        toast.attributes("-topmost", True)
        toast.configure(bg=ACCENT)
        msg = tk.Label(toast, bg=ACCENT, fg="#ffffff", font=(FONT, 16, "bold"), padx=26, pady=12)
        msg.pack()
        toast.geometry(f"+{max(0, root.winfo_screenwidth() // 2 - 330)}+30")
        root.iconify()

        def point(xv, yv, what, then):
            def tick(n):
                if n > 0:
                    msg.config(text=f"{name}: hover the {what} corner ... {n}")
                    root.after(1000, lambda: tick(n - 1))
                else:
                    pt = wintypes.POINT()
                    user32.GetCursorPos(ctypes.byref(pt))
                    xv.set(str(pt.x))
                    yv.set(str(pt.y))
                    msg.config(text=f"{what} corner saved:  {pt.x}, {pt.y}")
                    root.after(900, then)
            tick(3)

        def finish():
            toast.destroy()
            root.deiconify()
            say(f"{name}: area saved", GREEN)

        point(vs["blx"], vs["bly"], "BOTTOM-LEFT",
              lambda: point(vs["trx"], vs["try"], "TOP-RIGHT", finish))

    for row, key in enumerate(IMAGES, start=1):
        a = cfg["areas"][key]
        vs = {n: tk.StringVar(value=str(a[n])) for n in ("blx", "bly", "trx", "try")}
        area_vars[key] = vs
        tk.Label(ar, text=IMAGES[key][1], bg=CARD, fg=FG, font=(FONT, 10)).grid(row=row, column=0, sticky="w", padx=4, pady=4)
        for col_i, n in enumerate(("blx", "bly", "trx", "try"), start=1):
            w_ = entry(ar, vs[n])
            w_.grid(row=row, column=col_i, padx=4)
            area_widgets.append(w_)
        for w_, col_i, pad in (
                (small_button(ar, "GRAB AREA", lambda v=vs, n=IMAGES[key][1]: grab_area(v, n), bg=ACCENT), 5, (12, 4)),
                (small_button(ar, "BL", lambda v=vs: grab(v["blx"], v["bly"], "bottom-left")), 6, 2),
                (small_button(ar, "TR", lambda v=vs: grab(v["trx"], v["try"], "top-right")), 7, 2)):
            w_.grid(row=row, column=col_i, padx=pad)
            area_widgets.append(w_)

    def scan_mode_changed():
        full = scan_mode.sel[0] == SCAN_FULL
        for w_ in area_widgets:
            w_.config(state="disabled" if full else "normal")
        say("Fullscreen scan: the whole screen is searched, no areas needed." if full
            else "Search areas: each image is only searched inside its box.", ACCENT)
    scan_mode.on_change = scan_mode_changed
    for w_ in area_widgets:
        w_.config(state="disabled" if scan_mode.sel[0] == SCAN_FULL else "normal")

    # ---- ATTACK ROTATION ------------------------------------------------------
    rt = card("ATTACK ROTATION", "Keys pressed over and over from the moment the raid starts until it ends.")
    rotation = ChipGroup(rt, ROTATION_KEYS, cfg["rotation"], "multi", columns=8, fmt=str.upper)
    rotation.frame.pack(anchor="w")

    # ---- SLOTS ----------------------------------------------------------------
    sl = card("SLOTS", "Pick slot 1, 2 or both. With both, the macro runs one full attack rotation on a slot, "
                       "swaps to the other slot, runs it again, and keeps alternating.")
    slots = ChipGroup(sl, SLOT_KEYS, cfg["slots"], "multi", columns=2, fmt=lambda k: f"Slot {k}")
    slots.frame.pack(anchor="w")

    # ---- LOCK ON --------------------------------------------------------------
    LOCK_KEYS = set("abcdefghijklmnopqrstuvwxyz0123456789")
    lo = card("LOCK ON", "The key you press in the game to lock on. Press SET KEY, then press that key (A-Z, 0-9) "
                         "or click the middle mouse button. It is pressed once each time Ready is detected, right after the slot key.")
    lock = {"key": cfg.get("lock_on", "") if cfg.get("lock_on", "") in LOCK_KEYS | {"mmb"} else "", "listening": False}
    lo_row = tk.Frame(lo, bg=CARD)
    lo_row.pack(anchor="w")
    keycap = tk.Label(lo_row, width=9, pady=8, font=("Consolas", 16, "bold"), bd=0)
    keycap.pack(side="left", padx=(0, 12))

    def lock_refresh():
        if lock["listening"]:
            keycap.config(text="PRESS...", bg=RED, fg="#ffffff")
        elif lock["key"]:
            keycap.config(text="MMB" if lock["key"] == "mmb" else lock["key"].upper(), bg=ACCENT, fg="#ffffff")
        else:
            keycap.config(text="NONE", bg=CARD2, fg=DIM)

    def lock_stop():
        lock["listening"] = False
        root.unbind_all("<Key>")
        root.unbind_all("<ButtonPress-2>")
        lock_refresh()

    def lock_set(key):
        lock["key"] = key
        lock_stop()
        say(f"Lock On set to {'middle mouse button' if key == 'mmb' else key.upper()}", GREEN)

    def lock_key(e):
        ks = e.keysym
        if ks == "Escape":
            lock_stop()
            say("Lock On unchanged", MUTED)
        elif len(ks) == 1 and ks.lower() in LOCK_KEYS:
            lock_set(ks.lower())
        elif ks not in ("Shift_L", "Shift_R", "Control_L", "Control_R", "Alt_L", "Alt_R", "Caps_Lock"):
            say("Only letters A-Z, numbers 0-9 or the middle mouse button work. Esc cancels.", RED)
        return "break"

    def lock_listen():
        lock["listening"] = True
        lock_refresh()
        say("Press the Lock On key now (or middle click). Esc cancels.", ACCENT)
        root.focus_force()
        root.bind_all("<Key>", lock_key)
        root.bind_all("<ButtonPress-2>", lambda _e: (lock_set("mmb"), "break")[1])

    def lock_clear():
        lock["key"] = ""
        lock_stop()
        say("Lock On cleared - the macro won't press a lock-on key", MUTED)

    lock_refresh()
    small_button(lo_row, "SET KEY", lock_listen, bg=ACCENT).pack(side="left", padx=4, ipady=4)
    small_button(lo_row, "CLEAR", lock_clear).pack(side="left", padx=4, ipady=4)

    # ---- HEAVENLY RESTRICTION / CURSED TECHNIQUE / WEAPONS ---------------------
    hr_card = card("HEAVENLY RESTRICTION", "Pick one, or none to use both a cursed technique and weapons. "
                                           "Physical locks cursed techniques, Sorcerer locks weapons.")
    hr = ChipGroup(hr_card, [SHR, PHR], [cfg["hr"]] if cfg["hr"] else [], "optional", columns=2)
    hr.frame.pack(anchor="w")
    ct_card = card("CURSED TECHNIQUE", f"Up to {SELECT_CAP} can be selected.")
    ct = ChipGroup(ct_card, CURSED_TECHNIQUES, cfg["ct"], "multi", cap=SELECT_CAP, columns=4)
    ct.frame.pack(anchor="w")
    wp_card = card("WEAPON", f"Up to {SELECT_CAP} can be selected.")
    wp = ChipGroup(wp_card, WEAPONS, cfg["weapons"], "multi", cap=SELECT_CAP, columns=4)
    wp.frame.pack(anchor="w")

    def hr_changed():
        choice = hr.sel[0] if hr.sel else ""
        if choice == PHR:
            ct.clear()
        if choice == SHR:
            wp.clear()
        ct.set_enabled(choice != PHR)
        wp.set_enabled(choice != SHR)
    hr.on_change = hr_changed
    hr_changed()

    # ---- LOOPS ----------------------------------------------------------------
    lp = card("LOOPS", "Loops goes up by 1 every time Raid Summary: Successful is seen (a failure does not count).")
    loops_mode = ChipGroup(lp, ["Amount", "Inf"], ["Inf" if cfg["loops_inf"] else "Amount"], "single", columns=2)
    loops_mode.frame.grid(row=0, column=0, sticky="w")
    loops_var = tk.StringVar(value=str(cfg["loops_count"]))
    tk.Label(lp, text="how many:", bg=CARD, fg=MUTED, font=(FONT, 9)).grid(row=0, column=1, padx=(20, 6))
    entry(lp, loops_var, 7).grid(row=0, column=2)

    # ---- STOP / LOG CLEARER ---------------------------------------------------
    sk = card("STOP KEY", "Press it to stop the macro, press it again to restart it.")
    stop = ChipGroup(sk, STOP_KEYS, [cfg["stop_key"]], "single", columns=12, fmt=str.upper)
    stop.frame.pack(anchor="w")
    lc = card("LOG CLEARER", "The console is wiped and redrawn this often.")
    logc = ChipGroup(lc, LOG_CLEAR_MINUTES, [cfg["log_clear"]], "single", columns=6, fmt=lambda m: f"{m} min")
    logc.frame.pack(anchor="w")

    # ---- SCREEN / RESOLUTION --------------------------------------------------
    sc = card("SCREEN", "Window layout of Roblox. Smaller layouts also try smaller copies of the images.")
    screen = ChipGroup(sc, SCREEN_MODES, [cfg["screen"]], "single", columns=3)
    screen.frame.pack(anchor="w")
    corner = ChipGroup(sc, CORNERS, [cfg["corner"]], "single", columns=4)
    corner.frame.pack(anchor="w", pady=(6, 0))

    def screen_changed():
        corner.set_enabled(True)  # corner/side can be picked with any screen mode
    screen.on_change = screen_changed
    screen_changed()
    rs = card("RESOLUTION")
    res = ChipGroup(rs, RESOLUTIONS, [cfg["resolution"]] if cfg["resolution"] in RESOLUTIONS else [RESOLUTIONS[0]],
                    "single", columns=6)
    res.frame.pack(anchor="w")

    # ---- save / quit ----------------------------------------------------------
    def collect():
        out = {"areas": {}}
        if scan_mode.sel[0] == SCAN_FULL:
            sw_, sh_ = screen_size()
            out["areas"] = {k: make_area(0, 0, sw_, sh_) for k in IMAGES}
        else:
          try:
            for key, vs in area_vars.items():
                out["areas"][key] = {n: int(v.get().strip()) for n, v in vs.items()}
                l, t, r, b = region_of(out["areas"][key])
                if min(l, t) < 0 or r - l < 1 or b - t < 1:
                    say(f"{IMAGES[key][1]}: the search area is empty or negative.", RED)
                    return None
          except ValueError:
            say("Search areas must be whole numbers.", RED)
            return None
        if not rotation.sel:
            say("Pick at least one Attack Rotation key.", RED)
            return None
        if not slots.sel:
            say("Pick at least one Slot.", RED)
            return None
        if lock["key"] and (lock["key"] in rotation.sel or lock["key"] in slots.sel):
            say(f"Lock On key {lock['key'].upper()} is already used by the rotation or slots - pick another.", RED)
            return None
        inf = loops_mode.sel[0] == "Inf"
        try:
            count = int(loops_var.get().strip())
        except ValueError:
            count = 0
        if not inf and count < 1:
            say("Loops: enter a whole number of 1 or more, or pick Inf.", RED)
            return None
        out.update({
            "rotation": [k for k in ROTATION_KEYS if k in rotation.sel], "slots": [k for k in SLOT_KEYS if k in slots.sel], "hr": hr.sel[0] if hr.sel else "",
            "ct": list(ct.sel), "weapons": list(wp.sel), "loops_inf": inf, "loops_count": max(count, 1),
            "stop_key": stop.sel[0], "log_clear": logc.sel[0], "screen": screen.sel[0],
            "corner": corner.sel[0], "resolution": res.sel[0], "scan_full": scan_mode.sel[0] == SCAN_FULL, "lock_on": lock["key"],
        })
        return out

    def on_save():
        data = collect()
        if data is None:
            return
        save_settings(data)
        result["cfg"] = data
        root.destroy()

    tk.Button(footer, text="SAVE & LAUNCH", command=on_save, bg=RED, fg="#fff", activebackground="#ff6b85",
              activeforeground="#fff", relief="flat", bd=0, padx=22, pady=8, font=(FONT, 10, "bold"),
              cursor="hand2").pack(side="right", padx=(8, 16), pady=8)
    small_button(footer, "Quit", root.destroy).pack(side="right", pady=8, ipady=4)
    root.mainloop()
    return result["cfg"]


# ============================================================================
#  CONSOLE
# ============================================================================
R, B, D = "\x1b[0m", "\x1b[1m", "\x1b[2m"
C = {"INFO": "\x1b[38;5;75m", "RAID": "\x1b[38;5;141m", "PHASE": "\x1b[38;5;220m", "WIN": "\x1b[38;5;84m",
     "LOSE": "\x1b[38;5;203m", "CLICK": "\x1b[38;5;213m", "STOP": "\x1b[38;5;208m", "RUN": "\x1b[38;5;84m",
     "WARN": "\x1b[38;5;214m", "LOCK": "\x1b[38;5;51m", "DBG": "\x1b[38;5;245m", "ERR": "\x1b[38;5;196m"}
print_lock = threading.Lock()


def enable_console():
    try:
        k = ctypes.windll.kernel32
        out = k.GetStdHandle(-11)
        mode = ctypes.c_ulong()
        k.GetConsoleMode(out, ctypes.byref(mode))
        k.SetConsoleMode(out, mode.value | 0x0004)          # ANSI colours
        inp = k.GetStdHandle(-10)
        k.GetConsoleMode(inp, ctypes.byref(mode))
        k.SetConsoleMode(inp, (mode.value & ~0x0040) | 0x0080)  # clicking the window no longer freezes it
    except Exception:
        pass


def log(tag, msg):
    stamp = time.strftime("%H:%M:%S")
    with print_lock:
        print(f"  {D}{stamp}{R}  {C.get(tag, '')}{B}{tag:<5}{R}  {msg}", flush=True)


def print_header(cfg):
    v, rd = "\x1b[38;5;141m", "\x1b[38;5;203m"
    restriction = cfg["hr"] or "None (cursed technique + weapons)"
    loops = "Infinite" if cfg["loops_inf"] else f"{cfg['loops_count']} raids"
    rows = [("Rotation", " ".join(k.upper() for k in cfg["rotation"])), ("Slots", " + ".join(cfg["slots"])),
            ("Restriction", restriction),
            ("Lock On", ("MMB" if cfg.get("lock_on") == "mmb" else cfg.get("lock_on", "").upper()) or "-"),
            ("Technique", ", ".join(cfg["ct"]) or "-"), ("Weapons", ", ".join(cfg["weapons"]) or "-"),
            ("Loops", loops), ("Stop key", cfg["stop_key"].upper()),
            ("Log clear", f"every {cfg['log_clear']} min"), ("Screen", cfg["screen"]),
            ("Resolution", cfg["resolution"])]
    top, bot, hl = "\u2554" + "\u2550" * 58 + "\u2557", "\u255a" + "\u2550" * 58 + "\u255d", "\u2500" * 60
    side = "\u2551"
    with print_lock:
        os.system("cls" if os.name == "nt" else "clear")
        print()
        print(f"  {v}{top}{R}")
        print(f"  {v}{side}{R}   {B}C A L A M I T Y{R}  {rd}{B}C L E A V E R{R}{' ' * 25}{v}{side}{R}")
        print(f"  {v}{side}{R}   {D}Jujutsu Zero  \u00b7  Nayoa Calamity auto-raider{R}{' ' * 12}{v}{side}{R}")
        print(f"  {v}{bot}{R}")
        for name, value in rows:
            print(f"   {D}{name:<12}{R}{value}")
        print(f"  {D}{hl}{R}", flush=True)


def fmt_time(seconds):
    s = int(seconds)
    return f"{s // 3600:02d}:{s % 3600 // 60:02d}:{s % 60:02d}"


# ============================================================================
#  MACRO
# ============================================================================
IDLE, RAID, WAIT_RETRY = "idle", "raid", "wait_retry"
shutdown, paused, attacking, busy = threading.Event(), threading.Event(), threading.Event(), threading.Event()
lock = threading.Lock()
actions = queue.Queue()
pool = concurrent.futures.ThreadPoolExecutor(max_workers=len(SCAN_KEYS))
cfg_live = {}
regions, templates = {}, {}
S = {"state": IDLE, "loops": 0, "phase2": False, "retry_since": 0.0, "result_block": 0.0, "ready_block": 0.0}
start_time = time.monotonic()


def load_templates(cfg):
    scales = SCALES.get(cfg["screen"], [1.0])
    for key, (name, label, _thr) in IMAGES.items():
        img = cv2.imread(str(ROOT / name), cv2.IMREAD_GRAYSCALE)
        if img is None:
            raise SystemExit(f"Missing or unreadable image: {name} (put it next to this file)")
        templates[key] = []
        for s in scales:
            t = img if s == 1.0 else cv2.resize(img, None, fx=s, fy=s, interpolation=cv2.INTER_AREA)
            small = cv2.resize(t, None, fx=0.5, fy=0.5, interpolation=cv2.INTER_AREA)
            templates[key].append((t, small if min(small.shape) >= 8 else None))
        if cfg.get("scan_full"):
            sw_, sh_ = screen_size()
            regions[key] = (0, 0, sw_, sh_)
        else:
            regions[key] = region_of(cfg["areas"][key])
        l, t_, r, b = regions[key]
        if (r - l) < img.shape[1] * min(scales) or (b - t_) < img.shape[0] * min(scales):
            log("WARN", f"{label}: search area is smaller than the image - it can never match")


def grab_gray(sct, key, cache=None):
    reg = regions[key]
    if cache is not None and reg in cache:  # fullscreen scan: grab the screen once per tick, not once per image
        return cache[reg]
    left, top, right, bottom = reg
    shot = np.asarray(sct.grab({"left": left, "top": top, "width": right - left, "height": bottom - top}))
    gray = cv2.cvtColor(shot, cv2.COLOR_BGRA2GRAY)
    if cache is not None:
        cache[reg] = gray
    return gray


def find(sct, key):
    return match(key, grab_gray(sct, key))


def match(key, gray):
    """Two-stage match: a quick half-size pass finds candidates, a full-size pass confirms them."""
    left, top = regions[key][0], regions[key][1]
    gh, gw = gray.shape
    gray_small = None
    best, pos = 0.0, None
    for t, small in templates[key]:
        th, tw = t.shape
        if th > gh or tw > gw:
            continue
        if small is None or gh < small.shape[0] * 2 or gw < small.shape[1] * 2:
            res = np.nan_to_num(cv2.matchTemplate(gray, t, cv2.TM_CCOEFF_NORMED))
            _, mx, _, loc = cv2.minMaxLoc(res)
            cand = (mx, loc[0], loc[1])
        else:
            if gray_small is None:
                gray_small = cv2.resize(gray, None, fx=0.5, fy=0.5, interpolation=cv2.INTER_AREA)
            res = np.nan_to_num(cv2.matchTemplate(gray_small, small, cv2.TM_CCOEFF_NORMED))
            _, mx, _, loc = cv2.minMaxLoc(res)
            if mx < COARSE_GATE:
                if DEBUG_SCORES:
                    BEST[key] = max(BEST.get(key, 0.0), mx)
                continue
            x0, y0 = max(loc[0] * 2 - 6, 0), max(loc[1] * 2 - 6, 0)
            x1, y1 = min(loc[0] * 2 + tw + 6, gw), min(loc[1] * 2 + th + 6, gh)
            res = np.nan_to_num(cv2.matchTemplate(gray[y0:y1, x0:x1], t, cv2.TM_CCOEFF_NORMED))
            _, mx, _, loc2 = cv2.minMaxLoc(res)
            cand = (mx, x0 + loc2[0], y0 + loc2[1])
        if cand[0] > best:
            best, pos = cand[0], (left + cand[1] + tw // 2, top + cand[2] + th // 2)
    if DEBUG_SCORES:
        BEST[key] = max(BEST.get(key, 0.0), best)
    return (pos[0], pos[1], best) if pos and best >= IMAGES[key][2] else None


# ---- input -----------------------------------------------------------------
# Mouse moves and clicks are sent with SendInput (real input events Roblox sees), not SetCursorPos.
ULONG_PTR = ctypes.c_size_t
MOVE, LEFTDOWN, LEFTUP, ABSOLUTE, VIRTUALDESK = 0x0001, 0x0002, 0x0004, 0x8000, 0x4000
MIDDLEDOWN, MIDDLEUP = 0x0020, 0x0040


class MOUSEINPUT(ctypes.Structure):
    _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG), ("mouseData", wintypes.DWORD),
                ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]


class _InputUnion(ctypes.Union):
    _fields_ = [("mi", MOUSEINPUT)]


class INPUT(ctypes.Structure):
    _fields_ = [("type", wintypes.DWORD), ("u", _InputUnion)]


def send_mouse(flags, dx=0, dy=0):
    inp = INPUT(0, _InputUnion(mi=MOUSEINPUT(dx, dy, 0, flags, 0, 0)))
    user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT))


def cursor_pos():
    pt = wintypes.POINT()
    user32.GetCursorPos(ctypes.byref(pt))
    return pt.x, pt.y


def move_abs(x, y, vs):
    vx, vy, vw, vh = vs
    nx = int(round((x - vx) * 65535 / max(vw - 1, 1)))
    ny = int(round((y - vy) * 65535 / max(vh - 1, 1)))
    send_mouse(MOVE | ABSOLUTE | VIRTUALDESK, nx, ny)


def wait_until(t):
    """Accurate wait: sleep most of it, spin the last couple of milliseconds."""
    while True:
        remaining = t - time.perf_counter()
        if remaining <= 0:
            return
        time.sleep(remaining - 0.002 if remaining > 0.004 else 0)


def glide_to(tx, ty):
    """Curved, eased move at about 200 steps per second. Returns False if it was interrupted."""
    vs = tuple(user32.GetSystemMetrics(i) for i in (76, 77, 78, 79))
    tx, ty = int(tx), int(ty)
    sx, sy = cursor_pos()
    dx, dy = tx - sx, ty - sy
    dist = math.hypot(dx, dy)
    if dist >= 2:
        dur = min(1.3, 0.30 + dist / 2000.0)
        nx, ny = -dy / dist, dx / dist
        bend = random.uniform(-0.08, 0.08) * min(dist, 600)
        c1 = (sx + dx * 0.30 + nx * bend, sy + dy * 0.30 + ny * bend)
        c2 = (sx + dx * 0.70 + nx * bend * 0.5, sy + dy * 0.70 + ny * bend * 0.5)
        steps = max(30, int(dur * 200))
        t0 = time.perf_counter()
        for i in range(1, steps + 1):
            if paused.is_set() or shutdown.is_set():
                return False
            t = i / steps
            e = t * t * t * (t * (6 * t - 15) + 10)  # smootherstep easing
            u = 1 - e
            x = u**3 * sx + 3 * u * u * e * c1[0] + 3 * u * e * e * c2[0] + e**3 * tx
            y = u**3 * sy + 3 * u * u * e * c1[1] + 3 * u * e * e * c2[1] + e**3 * ty
            move_abs(int(round(x)), int(round(y)), vs)
            wait_until(t0 + dur * t)
    time.sleep(0.08)
    move_abs(tx + 3, ty, vs)   # small wiggle so Roblox registers the cursor arriving / hovering
    time.sleep(0.05)
    move_abs(tx - 3, ty, vs)
    time.sleep(0.03)
    move_abs(tx, ty, vs)
    time.sleep(0.08)
    if cursor_pos() != (tx, ty):  # absolute coordinates can be 1 px off, snap to the exact pixel
        user32.SetCursorPos(tx, ty)
        time.sleep(0.03)
    return True


def click():
    send_mouse(LEFTDOWN)
    time.sleep(0.07 + random.uniform(0, 0.03))  # held long enough for Roblox to register it
    send_mouse(LEFTUP)


def tap(key, hold=0.04):
    try:
        pydirectinput.keyDown(key)
        time.sleep(hold)
        pydirectinput.keyUp(key)
    except Exception:
        pass


def focus_roblox():
    """Bring the Roblox window to the front so clicks and keys land in the game. Silent if it can't."""
    try:
        found = []
        proto = ctypes.WINDOWFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

        def each(hwnd, _lp):
            if user32.IsWindowVisible(hwnd):
                buf = ctypes.create_unicode_buffer(64)
                user32.GetWindowTextW(hwnd, buf, 64)
                rc = wintypes.RECT()
                user32.GetWindowRect(hwnd, ctypes.byref(rc))
                if buf.value == "Roblox" and rc.right - rc.left > 300 and rc.bottom - rc.top > 300:
                    found.append(hwnd)
            return True
        user32.EnumWindows(proto(each), 0)
        if found and user32.GetForegroundWindow() != found[0]:
            if user32.IsIconic(found[0]):
                user32.ShowWindow(found[0], 9)
            user32.SetForegroundWindow(found[0])
            time.sleep(0.15)
    except Exception:
        pass


def lock_on_press():
    key = cfg_live.get("lock_on", "")
    if not key:
        return
    if key == "mmb":
        send_mouse(MIDDLEDOWN)
        time.sleep(0.05)
        send_mouse(MIDDLEUP)
    else:
        tap(key, 0.05)
    log("LOCK", f"Lock On pressed ({'MMB' if key == 'mmb' else key.upper()})")
    time.sleep(0.1)


def boost_thread():
    """Give the calling thread high priority so image matching can't make the mouse stutter."""
    try:
        k = ctypes.windll.kernel32
        k.GetCurrentThread.restype = wintypes.HANDLE
        k.SetThreadPriority.argtypes = [wintypes.HANDLE, ctypes.c_int]
        k.SetThreadPriority(k.GetCurrentThread(), 2)
    except Exception:
        pass


def actor():
    boost_thread()
    while not shutdown.is_set():
        try:
            kind, x, y = actions.get(timeout=0.2)
        except queue.Empty:
            continue
        try:
            focus_roblox()
            if paused.is_set() or not glide_to(x, y):
                continue
            count = 3 if kind == "ready" else 5
            for _ in range(count):
                if paused.is_set() or shutdown.is_set():
                    break
                click()
                time.sleep(0.16 + random.uniform(0, 0.06))
            if paused.is_set() or shutdown.is_set():
                continue
            if kind == "ready":
                for k in cfg_live["slots"]:  # the slot(s) picked in settings: 1, 2, or 1 then 2
                    tap(k)
                    time.sleep(0.15)
                lock_on_press()  # Lock On key, once, right after the slot key(s)
            now = time.monotonic()
            with lock:
                S["ready_block"] = now + READY_COOLDOWN
                if kind == "retry":
                    S["state"], S["result_block"] = IDLE, now + RESULT_COOLDOWN
            if kind == "ready":
                log("CLICK", f"Ready clicked {count}x, pressed slot {' + '.join(cfg_live['slots'])}")
            else:
                log("CLICK", f"Retry clicked {count}x")
        except Exception as exc:
            log("ERR", f"click failed: {exc}")
        finally:
            busy.clear()


# ---- attack rotation -------------------------------------------------------
def rotation_worker():
    """One full pass through the rotation keys per slot; with both slots it swaps after every pass."""
    keys, slots = cfg_live["rotation"], cfg_live["slots"]
    idx, was_attacking = 0, False
    while not shutdown.is_set():
        if not attacking.is_set() or paused.is_set():
            was_attacking = False
            time.sleep(0.02)
            continue
        if not was_attacking:  # attack just started: equip the first slot
            was_attacking, idx = True, 0
            tap(slots[0])
            time.sleep(SLOT_SWAP_DELAY)
        finished = True
        for k in keys:
            if not attacking.is_set() or paused.is_set() or shutdown.is_set():
                finished = False
                break
            tap(k, 0.03)
            time.sleep(KEY_GAP)
        if finished and len(slots) > 1 and attacking.is_set() and not paused.is_set():
            idx = (idx + 1) % len(slots)
            tap(slots[idx])
            time.sleep(SLOT_SWAP_DELAY)


def release_keys():
    for k in cfg_live.get("rotation", []):
        try:
            pydirectinput.keyUp(k)
        except Exception:
            pass


# ---- scanner / state machine -----------------------------------------------
def on_result(win):
    cfg = cfg_live
    with lock:
        S["state"], S["phase2"], S["retry_since"] = WAIT_RETRY, False, time.monotonic()
        if win:
            S["loops"] += 1
        loops = S["loops"]
    attacking.clear()
    if win:
        log("WIN", f"Raid beaten  |  Loops: {loops}")
        if not cfg["loops_inf"] and loops >= cfg["loops_count"]:
            log("INFO", f"Reached {cfg['loops_count']} loops - stopping")
            shutdown.set()
    else:
        log("LOSE", f"Raid failed - heading to Retry  |  Loops stay at {loops}")


def tick(sct):
    now = time.monotonic()
    cache = {}
    grays = {k: grab_gray(sct, k, cache) for k in SCAN_KEYS}    # screen grabs on this thread
    jobs = {k: pool.submit(match, k, grays[k]) for k in SCAN_KEYS}  # matching runs in parallel
    hits = {k: jobs[k].result() for k in SCAN_KEYS}
    with lock:
        state, block, ready_block = S["state"], S["result_block"], S["ready_block"]
    if state != WAIT_RETRY and now >= block:
        s, f = hits["success"], hits["failed"]
        if s and (not f or s[2] >= f[2]):
            return on_result(True)
        if f:
            return on_result(False)
    if state == WAIT_RETRY:
        if now - S["retry_since"] > RETRY_TIMEOUT:
            with lock:
                S["state"] = IDLE
            return log("WARN", "Retry never showed up - going back to normal scanning")
        if not busy.is_set():
            r = match("retry", grab_gray(sct, "retry", cache))
            if r:
                busy.set()
                actions.put(("retry", r[0], r[1]))
        return
    if busy.is_set():
        return
    if hits["ready"] and now >= ready_block:
        with lock:
            S["state"], S["phase2"] = IDLE, False
        attacking.clear()
        busy.set()
        log("RAID", "Ready found - raid starting")
        actions.put(("ready", hits["ready"][0], hits["ready"][1]))
        return
    if hits["zenin"] and state == IDLE:
        with lock:
            S["state"] = RAID
        log("RAID", "Zen'in Elite found - raid started, attacking")
        attacking.set()
    if hits["chase"]:
        with lock:
            first = not S["phase2"]
            S["phase2"] = True
            if S["state"] == IDLE:
                S["state"] = RAID
        if first:
            log("PHASE", "Chase took too long - phase 2 started")
            attacking.set()


def scanner():
    last_dbg = time.monotonic()
    with (mss.MSS() if hasattr(mss, "MSS") else mss.mss()) as sct:
        while not shutdown.is_set():
            if DEBUG_SCORES and time.monotonic() - last_dbg >= DEBUG_EVERY:
                last_dbg = time.monotonic()
                log("DBG", "best scores  " + "  ".join(
                    f"{k}={BEST.get(k, 0.0):.2f}/{IMAGES[k][2]:.2f}" for k in SCAN_KEYS))
                BEST.clear()
            t0 = time.monotonic()
            if paused.is_set():
                time.sleep(0.1)
                continue
            if busy.is_set():  # mouse is moving/clicking: leave the CPU to it so it stays smooth
                time.sleep(0.01)
                continue
            try:
                tick(sct)
            except Exception as exc:
                log("ERR", f"scan error: {exc}")
                time.sleep(0.5)
            time.sleep(max(0.0, SCAN_DELAY - (time.monotonic() - t0)))


# ---- stop key / log clearer ------------------------------------------------
def toggle_pause():
    if paused.is_set():
        with lock:
            S.update(state=IDLE, phase2=False, result_block=0.0, ready_block=0.0)
        paused.clear()
        log("RUN", "Restarted - scanning again")
    else:
        paused.set()
        attacking.clear()
        busy.clear()
        while not actions.empty():
            try:
                actions.get_nowait()
            except queue.Empty:
                break
        release_keys()
        log("STOP", f"Macro stopped - press {cfg_live['stop_key'].upper()} again to restart")


def hotkey_watcher():
    vk = 0x6F + int(cfg_live["stop_key"][1:])  # F1 = 0x70
    was = False
    while not shutdown.is_set():
        down = bool(user32.GetAsyncKeyState(vk) & 0x8000)
        if down and not was:
            toggle_pause()
        was = down
        time.sleep(0.02)


def log_clearer():
    every = cfg_live["log_clear"] * 60
    last = time.monotonic()
    while not shutdown.is_set():
        time.sleep(1.0)
        if time.monotonic() - last >= every:
            last = time.monotonic()
            print_header(cfg_live)
            log("INFO", f"Console cleared (every {cfg_live['log_clear']} min)  |  Loops: {S['loops']}  "
                        f"|  Time: {fmt_time(time.monotonic() - start_time)}")


# ---- stats window ----------------------------------------------------------
def run_stats_window():
    root = tk.Tk()
    root.title(APP_NAME)
    root.configure(bg=BG)
    root.attributes("-topmost", True)
    root.resizable(False, False)
    root.geometry(f"260x150+{max(0, root.winfo_screenwidth() - 290)}+40")
    tk.Label(root, text="CALAMITY CLEAVER", bg=BG, fg=RED, font=("Segoe UI Black", 11)).pack(pady=(10, 4))
    loops_lb = tk.Label(root, bg=BG, fg=FG, font=(FONT, 14, "bold"))
    time_lb = tk.Label(root, bg=BG, fg=FG, font=(FONT, 14, "bold"))
    state_lb = tk.Label(root, bg=BG, fg=GREEN, font=(FONT, 9, "bold"))
    loops_lb.pack()
    time_lb.pack()
    state_lb.pack(pady=(4, 0))

    def update():
        elapsed = fmt_time(time.monotonic() - start_time)
        loops_lb.config(text=f"Loops  {S['loops']}")
        time_lb.config(text=f"Time  {elapsed}")
        state_lb.config(text="STOPPED" if paused.is_set() else "RUNNING", fg=RED if paused.is_set() else GREEN)
        try:
            ctypes.windll.kernel32.SetConsoleTitleW(f"{APP_NAME} | Loops {S['loops']} | {elapsed}")
        except Exception:
            pass
        if shutdown.is_set():
            root.destroy()
        else:
            root.after(250, update)

    def on_close():
        shutdown.set()
        root.destroy()
    root.protocol("WM_DELETE_WINDOW", on_close)
    update()
    root.mainloop()


def main():
    global start_time
    ensure_images()
    cfg = run_settings(load_settings()) if tk else None
    gc.collect()  # destroy leftover Tk objects here, on the main thread (stops Tcl_AsyncDelete crash)
    if cfg is None:
        return
    cfg_live.update(cfg)
    enable_console()
    load_templates(cfg)
    print_header(cfg)
    log("INFO", "Settings saved - macro launched")
    start_time = time.monotonic()
    try:
        with (mss.MSS() if hasattr(mss, "MSS") else mss.mss()) as _s:
            for _k, (_l, _t, _r, _b) in regions.items():
                _img = np.asarray(_s.grab({"left": _l, "top": _t, "width": _r - _l, "height": _b - _t}))
                cv2.imwrite(str(ROOT / f"debug_area_{_k}.png"), _img[:, :, :3])
        log("INFO", "Saved debug_area_*.png (what each search box sees) next to this file")
    except Exception as exc:
        log("WARN", f"could not save debug screenshots: {exc}")
    for target in (scanner, actor, rotation_worker, hotkey_watcher, log_clearer):
        threading.Thread(target=target, daemon=True).start()
    log("RUN", f"Scanning every {int(SCAN_DELAY * 1000)} ms  |  {cfg['stop_key'].upper()} stops / restarts")
    try:
        gc.disable()  # worker threads must never trigger cleanup of Tk objects
        run_stats_window()
        gc.enable()
        gc.collect()
        while not shutdown.is_set():
            time.sleep(0.25)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown.set()
        attacking.clear()
        time.sleep(0.2)
        release_keys()
        log("INFO", f"Stopped  |  Loops: {S['loops']}  |  Time: {fmt_time(time.monotonic() - start_time)}")


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception:
        traceback.print_exc()
        sys.exit(1)
